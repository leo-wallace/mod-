# AMR suppressed AP5 + Pacifier stun, 450/225 (0.1.1)

See README.zh-CN.md for installation and testing.

- Retains the supplied AMR package's suppressed flag, suppressed-large AI noise and AP5.
- Keeps normal/durable damage at 450/225, removing the old durable450 edit.
- Adds exactly the supplied Pacifier package's StunLarge (39), strength5, to AMR damage type206.
- Uses the original AMR projectile226 and its original ballistics.
- Replaces the original AMR addon; do not enable both. Uses the same module/manager identity.
- Target build25480438; use the working Bingus Shared Loader v17/API1 setup.
- Offline validation only. Stun strength is not a fixed duration or a guarantee against every target.

Log: `%LOCALAPPDATA%/CowboyBingus/Helldivers2/Logs/AmrSuppressedStun.log`.
