针剂补给6 / Stim Refill 6 v1.0.0

单独修改针剂的补给恢复数量：2 -> 6。
使用已由用户确认生效的 Resupply 10-6 针剂逻辑原样拆分。
携带上限保持现状：例如0/4补到4/4，0/6补到6/6。
本包不包含手雷修改，不依赖HD2Runtime，不改治疗量、持续时间、血量或回血。

安装：
1. 退出游戏，禁用旧的 Resupply 10-6 混合包。
2. 保留 Bingus Shared Loader（沿用当前已能运行针剂的版本）。
3. 导入本ZIP，启用并部署，再启动游戏。
4. 避免同时启用其他修改针剂补给量的mod。

日志：
%LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\StimRefill6.log

兼容：沿用原包的游戏文件指纹、字段布局和写入前校验。
适用参考版本 Steam build 25480438 / exe 1.8.46015.0。
游戏更新导致校验不匹配时会停止写入，需重新适配。
停用：退出游戏后禁用本mod、重新部署并重启游戏。

验证：针剂核心与用户实测成功的混合包完全一致；本拆分包经过语法、结构和重新构建检查，尚未单独游戏实测。

参考与鸣谢：ponyomaz / HDRM Health Rework；包内Onyx Numbers Editor生成代码；参考包标注的CowboyBingus / ConsistentVaulting Windows读取及哈希辅助代码。
Source目录附完整源码及Python标准库重建脚本。
