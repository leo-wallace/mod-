from pathlib import Path
import struct,zipfile
root=Path(__file__).resolve().parent.parent
body=(root/'Source/addon.lua').read_bytes()
def hash64(s):
 d=s.encode();m=0xc6a4a7935bd1e995;mask=2**64-1;h=len(d)*m&mask
 for i in range(0,len(d)//8*8,8):
  k=int.from_bytes(d[i:i+8],'little');k=k*m&mask;k^=k>>47;k=k*m&mask;h^=k;h=h*m&mask
 tail=d[len(d)//8*8:]
 if tail:h^=int.from_bytes(tail,'little');h=h*m&mask
 h^=h>>47;h=h*m&mask;h^=h>>47
 return h

name='mods/leo_wallace/stim_refill_6'
payload=struct.pack('<II',len(body),2)+body
size=(192+len(payload)+15)&~15
b=bytearray(size)
struct.pack_into('<III20sQQ24s',b,0,0xF0000011,1,1,b'',size,0,b'')
struct.pack_into('<IIQIIII',b,72,0,0,0xA14E8DFA2CD117E2,1,0,16,16)
struct.pack_into('<7Q6I',b,104,hash64(name),0xA14E8DFA2CD117E2,192,0,0,0,0,len(payload),0,0,16,16,0)
b[192:192+len(payload)]=payload
out=root/'Stim-Refill-6-rebuilt.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
 z.writestr('Addon/9ba626afa44a3aa3.patch_0',b)
 for suffix in ['.gpu_resources','.stream']:z.writestr('Addon/9ba626afa44a3aa3.patch_0'+suffix,b'')
 for p in ['manifest.json','README.txt','Source/addon.lua','Source/rebuild.py']:z.write(root/p,p)
print(out)
