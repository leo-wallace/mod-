-- HD2-Addon: mods/leo_wallace/stim_refill_6
-- Stim Refill 6 v1.0.0. See README for scope, evidence and credits.
local KEY='LeoWallaceStimRefill6_v100'
if rawget(_G,KEY) then return rawget(_G,KEY) end
local loader=assert(rawget(_G,'CowboyBingusModLoader'),'Bingus Shared Loader required')
assert(loader.api>=1,'Loader API 1 required')
local logfile=loader.open_log and loader.open_log('StimRefill6.log')
local function log(s)
    print('[StimRefill6] '..tostring(s))
    if logfile then logfile:write(tostring(s)..'\n');logfile:flush() end
end
local state={}
rawset(_G,KEY,state)
local function start_stims()
local EDITS={{["owner_offset"]=15805440,["header"]='\059\180\218\138\076\068\076\068\001\000\000\000\059\180\218\138\176\059\000\000\001\000\000\000\000\000\000\000',["slot"]=111,["identity_offset"]=1776,["identity"]='\151\250\077\041\077\051\028\077\010\000\000\000',["offset"]=4244,["before"]=string.char(2,0,0,0),["after"]=string.char(6,0,0,0),["label"]='\080\108\097\121\101\114\032\067\108\111\110\101\032\040\065\118\097\116\097\114\041\032\082\101\102\105\108\108\032\065\109\111\117\110\116\032\083\116\105\109\115',["original"]='\002\000\000\000'}}
local BUILD={["steam_build"]=25480438,["exe_version"]='\049\046\056\046\052\054\048\049\053\046\048',["game_hashes"]={["bin/helldivers2.exe"]='\102\053\102\101\101\048\051\100\099\102\100\098\050\101\053\053\051\097\052\055\053\050\099\050\056\051\053\057\048\057\053\048\097\099\049\051\051\049\054\098\051\055\054\100\056\049\057\054\097\097\053\053\054\102\102\048\052\048\048\100\053\102\048\054',["data/game/game.dll"]='\050\101\050\099\051\098\055\099\050\053\048\048\054\052\054\100\097\100\100\053\102\050\098\052\099\054\101\048\053\048\052\100\098\098\055\101\055\056\057\054\049\051\057\102\054\052\099\100\100\099\048\100\049\056\049\051\099\055\049\056\102\053\049\101'},["owner_global"]=54968216,["health_owner_offset"]=15805304,["health_map_size"]=16032,["health_map_slot"]=443,["health_record_index"]=76,["verified_read_only_against_running_game"]=true}
local PATCH=(function()
-- Validates all targets before any write; restores completed writes on failure.
local M={}
function M.apply(api,game,owner_offset,edits)
 local jobs={}
 for _,e in ipairs(edits) do
  local p,guards=nil,{}
  local function read_guard(a,n)
   local b=api.read(a,n)
   if b then guards[#guards+1]={a=a,b=b} end
   return b
  end
  if e.kind=='global' then
   p=game
   assert(read_guard(game+e.code_offset,#e.code)==e.code,'Native consumer changed: '..e.label)
  elseif e.kind=='section' then
   local root=api.pointer(read_guard(game+e.global_rva,8))
   if not root then return 'Waiting for settings data' end
   if e.root_pointer_offset then
    root=api.pointer(read_guard(root+e.root_pointer_offset,8))
    if not root then return 'Waiting for settings collection' end
   end
   assert(read_guard(root+e.header_offset,#e.header)==e.header,'Settings layout changed: '..e.label)
   p=root+e.header_offset+24
  elseif e.kind=='array' then
   local root=api.pointer(read_guard(game+e.global_rva,8))
   if not root then return 'Waiting for settings data' end
   assert(read_guard(root+e.header_offset,#e.header)==e.header,'Settings layout changed: '..e.label)
   assert(read_guard(root+e.descriptor_offset+8,8)==e.count_bytes,'Settings count changed: '..e.label)
   p=api.pointer(read_guard(root+e.descriptor_offset,8))
   if not p then return 'Waiting for settings array' end
  else
   local owner=api.pointer(read_guard(game+owner_offset,8))
   if not owner then return 'Waiting for game data' end
   p=api.pointer(read_guard(owner+e.owner_offset,8))
   if not p then return 'Waiting for table data' end
   assert(read_guard(p-28,28)==e.header,'Table layout changed: '..e.label)
  end
  assert(read_guard(p+(e.identity_offset or e.slot*16),#e.identity)==e.identity,'Resource mapping changed: '..e.label)
  if e.guard then assert(read_guard(p+e.guard_offset,#e.guard)==e.guard,'Field identity changed: '..e.label) end
  local a=p+e.offset
  assert(#e.before==#e.after and #e.after>0,'Invalid patch width: '..e.label)
  local current=assert(api.read(a,#e.after),'Value unavailable')
  assert(current==e.before or current==e.after or (e.original and current==e.original),'Conflicting value: '..e.label)
  jobs[#jobs+1]={a=a,before=current,after=e.after,module_data=e.kind=='global',guards=guards,label=e.label}
 end
 -- Different locators can still resolve to the same live allocation.
 local ordered={}
 for i,j in ipairs(jobs)do ordered[i]=j end
 table.sort(ordered,function(a,b)return a.a<b.a end)
 for i=2,#ordered do
  assert(ordered[i].a>=ordered[i-1].a+#ordered[i-1].after,'Overlapping patch targets: '..ordered[i].label)
 end
 local function check_guards(j)
  for _,g in ipairs(j.guards)do assert(api.read(g.a,#g.b)==g.b,'Target changed during validation: '..j.label) end
 end
 local written={}
 local ok,err=pcall(function()
  for _,j in ipairs(jobs)do check_guards(j) end
  for _,j in ipairs(jobs) do
   check_guards(j)
   assert(api.read(j.a,#j.before)==j.before,'Value changed during validation')
   if j.before~=j.after then
    -- A native write can succeed before its protection-restoration step throws.
    written[#written+1]=j
    assert(api.replace_data(j.a,j.before,j.after,j.module_data),'Write failed')
    assert(api.read(j.a,#j.after)==j.after,'Read-back failed')
   end
  end
 end)
 if not ok then
  local restored=true
  for i=#written,1,-1 do
   local j=written[i]
   local rollback_ok,result=pcall(function()
    check_guards(j)
    local current=api.read(j.a,#j.before)
    if current==j.before then return true end
    if current~=j.after then return false end
    api.replace_data(j.a,j.after,j.before,j.module_data)
    return api.read(j.a,#j.before)==j.before
   end)
   if not rollback_ok or not result then restored=false end
  end
  error(tostring(err)..(restored and ' (rolled back)' or ' (restart game: rollback incomplete)'))
 end
 return 'Active: '..#edits..' number changes'
end
return M

end)()
local make_api=(function()
-- Adapted Windows read/hash helpers from CowboyBingus/ConsistentVaulting.
return function()
    local ffi = require('ffi')
    assert(ffi.abi('64bit'), 'Windows x64 is required')
    ffi.cdef [[
        void *GetModuleHandleA(const char *name);
        uint32_t GetModuleFileNameW(void *module, uint16_t *path, uint32_t capacity);
        void *GetCurrentProcess(void);
        uint64_t GetTickCount64(void);
        int ReadProcessMemory(void *process, const void *address, void *buffer, size_t size, size_t *read);
        int WriteProcessMemory(void *process, void *address, const void *buffer, size_t size, size_t *written);
        typedef struct {
            void *base; void *allocation_base; uint32_t allocation_protection;
            uint16_t partition; uint16_t reserved; size_t size;
            uint32_t state; uint32_t protection; uint32_t type;
        } LeoResupplyMemoryRegion_v010;
        size_t VirtualQuery(const void *address, void *region, size_t size);
        void *CreateFileW(const uint16_t *path, uint32_t access, uint32_t share, void *security,
                          uint32_t disposition, uint32_t flags, void *template_file);
        int ReadFile(void *file, void *buffer, uint32_t size, uint32_t *read, void *overlapped);
        int CloseHandle(void *handle);
        int32_t BCryptOpenAlgorithmProvider(void **algorithm, const uint16_t *name,
                                            const uint16_t *provider, uint32_t flags);
        int32_t BCryptCloseAlgorithmProvider(void *algorithm, uint32_t flags);
        int32_t BCryptCreateHash(void *algorithm, void **hash, void *object, uint32_t object_size,
                                 const void *secret, uint32_t secret_size, uint32_t flags);
        int32_t BCryptHashData(void *hash, const void *data, uint32_t size, uint32_t flags);
        int32_t BCryptFinishHash(void *hash, void *digest, uint32_t size, uint32_t flags);
        int32_t BCryptDestroyHash(void *hash);
    ]]
    local kernel, bcrypt = ffi.load('kernel32'), ffi.load('bcrypt')
    -- LuaJIT retains the first function declaration in the shared VM. Use an
    -- opaque buffer when declaring first so another mod's equivalent struct is
    -- accepted. Cast our own call as well for a typed declaration loaded first.
    local query_region = ffi.cast('size_t (*)(const void *, void *, size_t)', kernel.VirtualQuery)
    local process = kernel.GetCurrentProcess()
    local api = {}
    function api.time() return tonumber(kernel.GetTickCount64()) / 1000 end

    function api.module(name)
        local handle = kernel.GetModuleHandleA(name)
        if handle == nil then return nil end
        return ffi.cast('uint8_t *', handle)
    end

    function api.read(address, size)
        local buffer, count = ffi.new('uint8_t[?]', size), ffi.new('size_t[1]')
        if kernel.ReadProcessMemory(process, address, buffer, size, count) == 0 or count[0] ~= size then
            return nil
        end
        return ffi.string(buffer, size)
    end

    function api.write(address, bytes)
        if not api.writable_data(address, #bytes) then return false end
        local count = ffi.new('size_t[1]')
        return kernel.WriteProcessMemory(process, address, bytes, #bytes, count) ~= 0 and count[0] == #bytes
    end

    function api.pointer(bytes, offset)
        offset = offset or 0
        if not bytes or offset < 0 or offset + 8 > #bytes then return nil end
        local value = ffi.new('uintptr_t[1]')
        ffi.copy(value, bytes:sub(offset + 1, offset + 8), 8)
        if value[0] < 0x10000 or value[0] >= 0x800000000000 then return nil end
        return ffi.cast('uint8_t *', value[0])
    end

    function api.distance(first, second)
        return tonumber(ffi.cast('intptr_t', first) - ffi.cast('intptr_t', second))
    end

    function api.writable_data(address, size)
        if size <= 0 then return false end
        local cursor = ffi.cast('uint8_t *', address)
        local remaining = size
        local region = ffi.new('LeoResupplyMemoryRegion_v010[1]')
        while remaining > 0 do
            if query_region(cursor, region, ffi.sizeof(region[0])) ~= ffi.sizeof(region[0]) then return false end
            -- Settings must already be writable private data, never executable or mapped module pages.
            if region[0].state ~= 0x1000 or region[0].type ~= 0x20000 or region[0].protection ~= 4 then return false end
            local available = tonumber(region[0].size) - api.distance(cursor, region[0].base)
            if available <= 0 then return false end
            local count = math.min(available, remaining)
            cursor, remaining = cursor + count, remaining - count
        end
        return true
    end

    function api.module_hash(module)
        local path = ffi.new('uint16_t[32768]')
        local length = kernel.GetModuleFileNameW(module, path, 32768)
        assert(length > 0 and length < 32768, 'Cannot resolve module file')
        local file = kernel.CreateFileW(path, 0x80000000, 7, nil, 3, 0x08000000, nil)
        assert(file ~= ffi.cast('void *', -1), 'Cannot read module file')
        local algorithm, hash = ffi.new('void *[1]'), ffi.new('void *[1]')
        local ok, result = pcall(function()
            local name = ffi.new('uint16_t[7]', {83, 72, 65, 50, 53, 54, 0})
            assert(bcrypt.BCryptOpenAlgorithmProvider(algorithm, name, nil, 0) == 0, 'SHA256 unavailable')
            assert(bcrypt.BCryptCreateHash(algorithm[0], hash, nil, 0, nil, 0, 0) == 0, 'SHA256 creation failed')
            local buffer, count = ffi.new('uint8_t[1048576]'), ffi.new('uint32_t[1]')
            while true do
                assert(kernel.ReadFile(file, buffer, 1048576, count, nil) ~= 0, 'Module file read failed')
                if count[0] == 0 then break end
                assert(bcrypt.BCryptHashData(hash[0], buffer, count[0], 0) == 0, 'SHA256 update failed')
            end
            local digest, hex = ffi.new('uint8_t[32]'), {}
            assert(bcrypt.BCryptFinishHash(hash[0], digest, 32, 0) == 0, 'SHA256 finish failed')
            for i = 0, 31 do hex[#hex + 1] = string.format('%02X', digest[i]) end
            return table.concat(hex)
        end)
        if hash[0] ~= nil then bcrypt.BCryptDestroyHash(hash[0]) end
        if algorithm[0] ~= nil then bcrypt.BCryptCloseAlgorithmProvider(algorithm[0], 0) end
        kernel.CloseHandle(file)
        if not ok then error(result) end
        return result
    end

    ffi.cdef [[
        int VirtualProtect(void *address, size_t size, uint32_t protection, uint32_t *old);
    ]]
    function api.replace_data(address,before,after,allow_image_data)
        assert(#before==#after and #before>=1 and #before<=22096,'Invalid write extent')
        local region=ffi.new('LeoResupplyMemoryRegion_v010[1]')
        if query_region(address,region,ffi.sizeof(region[0]))~=ffi.sizeof(region[0]) then return false end
        local r=region[0]
        -- Private data by default. Explicitly guarded tunables may use writable image data; never executable pages.
        local permitted=r.type==0x20000 or (allow_image_data==true and r.type==0x1000000 and r.protection==4)
        if r.state~=0x1000 or not permitted or (r.protection~=2 and r.protection~=4) then return false end
        if api.distance(address,r.base)<0 or api.distance(address,r.base)+#after>tonumber(r.size) then return false end
        if api.read(address,#before)~=before then return false end
        local old=ffi.new('uint32_t[1]')
        if kernel.VirtualProtect(address,#after,4,old)==0 then return false end
        local ok,result=pcall(function()
            if api.read(address,#before)~=before then return false end
            local n=ffi.new('size_t[1]')
            local written=kernel.WriteProcessMemory(process,address,after,#after,n)~=0 and n[0]==#after
            if not written or api.read(address,#after)~=after then
                kernel.WriteProcessMemory(process,address,before,#before,n)
                return false
            end
            return true
        end)
        local ignored=ffi.new('uint32_t[1]')
        local restored=kernel.VirtualProtect(address,#after,old[0],ignored)~=0
        if not restored then error('Could not restore health data page protection') end
        if not ok then error(result) end
        return result
    end
    return api
end

end)()


local api=make_api()
local game=assert(api.module('game.dll'),'game.dll unavailable')
assert(api.module_hash(game)==BUILD.game_hashes['data/game/game.dll']:upper(),'Game DLL changed: stim refill disabled')
assert(api.module_hash(api.module('helldivers2.exe'))==BUILD.game_hashes['bin/helldivers2.exe']:upper(),'Game executable changed: stim refill disabled')
state.stims={next_check=0}
local previous=rawget(_G,'update')
function update(...)
    local s=state.stims
    if not s.failed and api.time()>=s.next_check then
        s.next_check=api.time()+1
        local ok,result=pcall(PATCH.apply,api,game,BUILD.owner_global,EDITS)
        if not ok then s.failed=true;result='Stim refill disabled: '..tostring(result) end
        if result~=s.status then s.status=result;log('Stims: '..result) end
    end
    if type(previous)=='function' then return previous(...) end
end
log('Stim refill module registered: 6; build hashes verified')
end
local stim_ok,stim_error=pcall(start_stims)
if not stim_ok then log('Stim module disabled: '..tostring(stim_error)) end
return state
