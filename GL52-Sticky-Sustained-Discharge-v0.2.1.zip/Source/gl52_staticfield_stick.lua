-- HD2-Addon: mods/codex/gl52_staticfield_stick
-- Experimental GL-52 sticky anchor with repeated native blast/arc requests.
-- No HD2Runtime dependency. All writes are exact-build, compare/write/readback guarded.
local VERSION = '0.2.1-shot-window-discovery'
local GAME_SHA256 = '2e2c3b7c2500646dadd5f2b4c6e0504dbb7e7896139f64cddc0d1813c718f51e'
local EXE_SHA256 = 'f5fee03dcfdb2e553a4752c283590950ac13316b376d8196aa556ff0400d5f06'
local MODULE_NAME = 'GL52StaticFieldStick'
local LOG_NAME = 'GL52StaticFieldStick.log'
local function unhex(s)
    return (s:gsub('%x%x', function(pair) return string.char(tonumber(pair, 16)) end))
end
local PROJECTILE_EXPECTED = unhex('de00000022225c14310bcbf2faea4de2f5c84b7d5898656a00002042010000000000c842000048429a99993f0000803f010000000000000000000000200000000000803e000000000000000000000000000000000000000000000000000000004e69ee05e61d45e900000000000000000000000000000000000000000000000067655b18908acda60000a042010000002900000000000000000000000000000000008040cdcccc3d1000000003000000010000000000a0420000a041cdcc4c3e0000404000007041000000006504e030a8a8cb74949268b2000080bf0000000000000000000000000200000000000000370000000000000018953d390000000000000000000000000000000000000000')
local EXPLOSION_EXPECTED = unhex('290000006e01000000000000000000000000803f000040400000804000000000000096420000000050080100000000000100000000000000dc47e9183d46d675b65c9186000000001e0000000000000000000000000000000e000000020000000000000000000000000000000000000000000000050000000f00000002000000000000000000000000000042030000000000000000000000')
local SHAKE_ASSETS_EXPECTED = unhex('c7dd1f79e0b350be')

-- Same-build native dispatch tables from the supplied runtime bindings.
-- The slots are indexed by settings TYPE, not the DataLibrary file row index.
local PROJECTILE_TABLE_RVA = 0x37c7670
local EXPLOSION_TABLE_RVA = 0x37cc920
local PROJECTILE_TYPE = 222
local EXPLOSION_TYPE = 41
local PROJECTILE_RECORD_SIZE = 0x110
local EXPLOSION_RECORD_SIZE = 0x98
-- rawExplosionInfo.ShakeAssets is a DLArray: offset/pointer at +0x28,
-- count at +0x30. Only this documented pointer changes on relocation.
local SHAKE_ASSETS_POINTER_OFFSET = 0x28
local SHAKE_ASSETS_COUNT_OFFSET = 0x30
local PROJECTILE_FLAGS1_OFFSET = 0xf0
local PROJECTILE_AUTO_REMOVE_MASK = 0x10
local PROJECTILE_FLAGS2_OFFSET = 0xfc
local PROJECTILE_AUTO_ATTACH_MASK = 0x02
local STATUS_VOLUME_OFFSET = 100
local STATUS_VOLUME_TIME_OFFSET = 104
local STATIC_FIELD_TYPE = 15
local STATIC_FIELD_SECONDS = 15.0

local existing = rawget(_G, MODULE_NAME)
if existing then return existing end
local public = {version = VERSION, status = 'initializing'}
rawset(_G, MODULE_NAME, public)

local loader = rawget(_G, 'CowboyBingusModLoader')
local log
if type(loader) == 'table' and type(loader.open_log) == 'function' then
    local ok, handle = pcall(loader.open_log, LOG_NAME)
    if ok then log = handle end
end
local function emit(message)
    local line = '[' .. MODULE_NAME .. '] ' .. message
    pcall(print, line)
    if log then pcall(function() log:write(line .. '\n'); log:flush() end) end
end
local function finish(status)
    if status:find('APPLIED_READBACK_OK',1,true)==1 then
        public.data_applied=true
        public.status='running'
        emit(status)
        return
    end
    public.status = status
    emit(status)
    if log then pcall(function() log:close() end); log = nil end
end
if type(loader) ~= 'table' or loader.api ~= 1 or type(loader.open_log) ~= 'function' then
    finish('disabled: Bingus Shared Loader v17+ API 1 required')
    return public
end
if type(rawget(_G, 'update')) ~= 'function' then
    finish('disabled: update callback unavailable')
    return public
end

local ok_ffi, ffi = pcall(require, 'ffi')
if not ok_ffi or ffi.os ~= 'Windows' or not ffi.abi('64bit') then
    finish('disabled: Windows x64 LuaJIT FFI required')
    return public
end
ffi.cdef [[
    void *GetModuleHandleA(const char *);
    uint32_t GetModuleFileNameW(void *, uint16_t *, uint32_t);
    void *GetCurrentProcess(void);
    int ReadProcessMemory(void *, const void *, void *, size_t, size_t *);
    int WriteProcessMemory(void *, void *, const void *, size_t, size_t *);
    size_t VirtualQuery(const void *, void *, size_t);
    int VirtualProtect(void *, size_t, uint32_t, uint32_t *);
    uint32_t GetLastError(void);
    uint64_t GetTickCount64(void);
    void *CreateFileW(const uint16_t *, uint32_t, uint32_t, void *, uint32_t, uint32_t, void *);
    int ReadFile(void *, void *, uint32_t, uint32_t *, void *);
    int CloseHandle(void *);
    int32_t BCryptOpenAlgorithmProvider(void **, const uint16_t *, const uint16_t *, uint32_t);
    int32_t BCryptCreateHash(void *, void **, void *, uint32_t, const void *, uint32_t, uint32_t);
    int32_t BCryptHashData(void *, const void *, uint32_t, uint32_t);
    int32_t BCryptFinishHash(void *, void *, uint32_t, uint32_t);
    int32_t BCryptDestroyHash(void *);
    int32_t BCryptCloseAlgorithmProvider(void *, uint32_t);
]]
local k, bcrypt = ffi.load('kernel32'), ffi.load('bcrypt')
local process = k.GetCurrentProcess()

local function read(address, length)
    if type(address) ~= 'number' or address < 65536 or address + length >= 0x800000000000
        or length < 1 or length > 1024 * 1024 then return nil end
    local out, count = ffi.new('uint8_t[?]', length), ffi.new('size_t[1]')
    if k.ReadProcessMemory(process, ffi.cast('const void *', address), out, length, count) == 0
        or tonumber(count[0]) ~= length then return nil end
    return ffi.string(out, length)
end
local function u32(bytes, offset)
    local a, b, c, d = bytes:byte(offset + 1, offset + 4)
    if not d then return nil end
    return a + b * 256 + c * 65536 + d * 16777216
end
local function u64at(bytes, offset)
    local p = ffi.new('uint64_t[1]')
    ffi.copy(p, bytes:sub(offset + 1, offset + 8), 8)
    return tonumber(p[0])
end
local function replace_bytes(bytes, offset, replacement)
    return bytes:sub(1, offset) .. replacement .. bytes:sub(offset + #replacement + 1)
end

local function sha256_of_module(module)
    local path = ffi.new('uint16_t[32768]')
    local n = tonumber(k.GetModuleFileNameW(ffi.cast('void *', module), path, 32768))
    assert(n > 0 and n < 32768, 'module_path_unavailable')
    local file = k.CreateFileW(path, 0x80000000, 7, nil, 3, 0x08000000, nil)
    assert(file ~= ffi.cast('void *', -1), 'module_file_unavailable')
    local algorithm, hash = ffi.new('void *[1]'), ffi.new('void *[1]')
    local ok, result = pcall(function()
        local name = ffi.new('uint16_t[7]', {83, 72, 65, 50, 53, 54, 0})
        assert(bcrypt.BCryptOpenAlgorithmProvider(algorithm, name, nil, 0) == 0, 'sha256_provider')
        assert(bcrypt.BCryptCreateHash(algorithm[0], hash, nil, 0, nil, 0, 0) == 0, 'sha256_create')
        local chunk, count = ffi.new('uint8_t[65536]'), ffi.new('uint32_t[1]')
        local total = 0
        while true do
            assert(k.ReadFile(file, chunk, 65536, count, nil) ~= 0, 'module_file_read')
            if count[0] == 0 then break end
            total = total + tonumber(count[0])
            assert(total <= 64 * 1024 * 1024, 'module_file_size_limit')
            assert(bcrypt.BCryptHashData(hash[0], chunk, count[0], 0) == 0, 'sha256_update')
        end
        local digest, parts = ffi.new('uint8_t[32]'), {}
        assert(bcrypt.BCryptFinishHash(hash[0], digest, 32, 0) == 0, 'sha256_finish')
        for i = 0, 31 do parts[#parts + 1] = string.format('%02x', digest[i]) end
        return table.concat(parts)
    end)
    if hash[0] ~= nil then bcrypt.BCryptDestroyHash(hash[0]) end
    if algorithm[0] ~= nil then bcrypt.BCryptCloseAlgorithmProvider(algorithm[0], 0) end
    k.CloseHandle(file)
    assert(ok, result)
    return result
end

local function region(address)
    local info = ffi.new('uint8_t[48]')
    if tonumber(k.VirtualQuery(ffi.cast('const void *', address), info, 48)) ~= 48 then
        return nil
    end
    local bytes = ffi.string(info, 48)
    return u64at(bytes, 0), u64at(bytes, 24), u32(bytes, 32), u32(bytes, 36), u32(bytes, 40)
end

-- Query only the page of the field being written. Read-only data pages are
-- made writable for this tiny transaction and restored before returning.
-- Never change execute/guard/no-access pages or an uncommitted region.
local function write(address, bytes, expected)
    if #bytes ~= 1 and #bytes ~= 2 and #bytes ~= 4 then return false end
    local base, length, state, protection = region(address)
    if not base or state ~= 0x1000 or address < base or address + #bytes > base + length
        or (protection ~= 0x02 and protection ~= 0x04) then
        emit('write_page_rejected address=' .. string.format('%#x', address))
        return false
    end
    local before = read(address, #bytes)
    if not before or (expected and before ~= expected) then return false end
    local at, old, unused = ffi.cast('void *', address), ffi.new('uint32_t[1]'), ffi.new('uint32_t[1]')
    local changed = protection == 0x02
    if changed and k.VirtualProtect(at, #bytes, 0x04, old) == 0 then
        emit('write_make_writable_failed error=' .. tonumber(k.GetLastError()))
        return false
    end
    -- No logging or file calls while the page has temporary permissions.
    local call_ok, result = pcall(function()
        if changed and tonumber(old[0]) ~= protection then return false end
        if read(address, #bytes) ~= before then return false end
        local count = ffi.new('size_t[1]')
        return k.WriteProcessMemory(process, at, bytes, #bytes, count) ~= 0
            and tonumber(count[0]) == #bytes and read(address, #bytes) == bytes
    end)
    local restored = true
    if changed then
        restored = k.VirtualProtect(at, #bytes, old[0], unused) ~= 0
        if not restored then restored = k.VirtualProtect(at, #bytes, old[0], unused) ~= 0 end
    end
    if not restored then emit('PAGE_PROTECTION_RESTORE_FAILED address=' .. string.format('%#x', address)) end
    if not call_ok then emit('write_exception=' .. tostring(result)) end
    return call_ok and result and restored
end

local function pointer(address)
    local bytes = read(address, 8)
    if not bytes then return nil end
    local value = u64at(bytes, 0)
    -- Packed DataLibrary records can be 4-byte aligned (file row start 0x2c).
    if value >= 65536 and value < 0x800000000000 and value % 4 == 0 then return value end
end
local function now() return tonumber(k.GetTickCount64()) / 1000 end

local game = k.GetModuleHandleA('game.dll')
if game == nil then finish('disabled: game.dll unavailable'); return public end
game = tonumber(ffi.cast('uintptr_t', game))
local game_ok, game_hash = pcall(sha256_of_module, game)
if not game_ok then finish('disabled: game.dll hash failed: ' .. tostring(game_hash)); return public end
if game_hash ~= GAME_SHA256 then finish('disabled: unsupported game.dll sha256=' .. game_hash); return public end
local exe_ok, exe_hash = pcall(sha256_of_module, k.GetModuleHandleA(nil))
if not exe_ok then finish('disabled: exe hash failed: ' .. tostring(exe_hash)); return public end
if exe_hash ~= EXE_SHA256 then finish('disabled: unsupported exe sha256=' .. exe_hash); return public end
emit('startup version=' .. VERSION .. ' BSL_API=' .. tostring(loader.api)
    .. ' loader_version=' .. tostring(loader.version) .. ' game_build=25480438')
emit('game_dll_hash_verified=' .. game_hash .. ' exe_hash_verified=' .. exe_hash .. ' HD2Runtime=NOT_REQUIRED')
emit('locator=DIRECT_TYPE_POINTER_SLOTS global_region_scan=OFF projectile_table_rva=0x37c7670 explosion_table_rva=0x37cc920')
emit('record_validation=RELOCATION_AWARE shake_assets_pointer_offset=0x28 pointee_content_guard=ON')

local projectile_ricochet0 = replace_bytes(PROJECTILE_EXPECTED, 0xb0, string.char(0, 0, 0, 0))
local projectile_expected_rows = {PROJECTILE_EXPECTED, projectile_ricochet0}
local function projectile_with_adhesion(baseline)
    local flags1 = baseline:sub(PROJECTILE_FLAGS1_OFFSET + 1, PROJECTILE_FLAGS1_OFFSET + 2)
    local lo, hi = flags1:byte(1, 2)
    local value = lo + hi * 256
    if math.floor(value / PROJECTILE_AUTO_REMOVE_MASK) % 2 == 1 then
        value = value - PROJECTILE_AUTO_REMOVE_MASK
    end
    local cleared = string.char(value % 256, math.floor(value / 256))
    local flags2_set = replace_bytes(baseline, PROJECTILE_FLAGS2_OFFSET, string.char(PROJECTILE_AUTO_ATTACH_MASK))
    return replace_bytes(flags2_set, PROJECTILE_FLAGS1_OFFSET, cleared)
end
local legacy_explosion_status = string.char(15, 0, 0, 0, 0, 0, 0x70, 0x41)
local explosion_row_legacy = replace_bytes(EXPLOSION_EXPECTED, STATUS_VOLUME_OFFSET, legacy_explosion_status)
local explosion_status_after = string.rep('\0',8)
local explosion_row_after = replace_bytes(EXPLOSION_EXPECTED, STATUS_VOLUME_OFFSET, explosion_status_after)

local function normalize_explosion_pointer(row)
    return replace_bytes(row, SHAKE_ASSETS_POINTER_OFFSET,
        EXPLOSION_EXPECTED:sub(SHAKE_ASSETS_POINTER_OFFSET + 1, SHAKE_ASSETS_POINTER_OFFSET + 8))
end
local function valid_explosion_row(row)
    if not row or #row ~= EXPLOSION_RECORD_SIZE then return false, 'record_unreadable' end
    local normalized = normalize_explosion_pointer(row)
    if normalized ~= EXPLOSION_EXPECTED and normalized ~= explosion_row_legacy then
        return false, 'nonpointer_field_mismatch'
    end
    local count = u32(row, SHAKE_ASSETS_COUNT_OFFSET)
    if count ~= #SHAKE_ASSETS_EXPECTED / 8 then return false, 'shake_assets_count_mismatch' end
    local address = u64at(row, SHAKE_ASSETS_POINTER_OFFSET)
    if address == u64at(EXPLOSION_EXPECTED, SHAKE_ASSETS_POINTER_OFFSET) then
        return false, 'serialized_array_offset_not_relocated'
    end
    if address < 65536 or address >= 0x800000000000 or address % 4 ~= 0 then
        return false, 'invalid_shake_assets_pointer'
    end
    -- One 8-byte asset ID, verified against both the same-build binary and JSON.
    -- The pointer bytes are never written by this addon.
    if read(address, #SHAKE_ASSETS_EXPECTED) ~= SHAKE_ASSETS_EXPECTED then
        return false, 'shake_assets_pointee_mismatch_or_unreadable'
    end
    return true, 'shake_assets_verified', address
end

local function valid_projectile_row(row)
    for _, baseline in ipairs(projectile_expected_rows) do
        if row == baseline then return true, baseline, false end
        local after = projectile_with_adhesion(baseline)
        if row == after then return true, baseline, true end
    end
    return false
end
local function matches_status_ref(type_id, duration_hex)
    local address = pointer(game + EXPLOSION_TABLE_RVA + type_id * 8)
    local row = address and read(address, EXPLOSION_RECORD_SIZE)
    if not row then return false end
    return u32(row, 0) == type_id
        and row:sub(STATUS_VOLUME_OFFSET + 1, STATUS_VOLUME_OFFSET + 4) == string.char(15, 0, 0, 0)
        and row:sub(STATUS_VOLUME_TIME_OFFSET + 1, STATUS_VOLUME_TIME_OFFSET + 4) == duration_hex
end
local function valid_explosion_references()
    if not matches_status_ref(180, string.char(0, 0, 0xe0, 0x40)) then return false end
    if not matches_status_ref(188, string.char(0, 0, 0x70, 0x41)) then return false end
    if not matches_status_ref(23, string.char(0, 0, 0xa0, 0x41)) then return false end
    if not matches_status_ref(55, string.char(0, 0, 0x70, 0x41)) then return false end
    return true
end

local function rollback(writes)
    local failed = {}
    for i = #writes, 1, -1 do
        local item = writes[i]
        local current = read(item.address, #item.after)
        if current == item.before then
            -- already restored
        elseif current == item.after then
            if not write(item.address, item.before, item.after) or read(item.address, #item.before) ~= item.before then
                failed[#failed + 1] = string.format('%#x', item.address)
            end
        else
            failed[#failed + 1] = string.format('%#x:changed_by_other_writer', item.address)
        end
    end
    return #failed == 0, table.concat(failed, ',')
end
local function guarded_write(writes, address, before, after, label)
    local current = read(address, #before)
    if current == after then return true, 'already_applied' end
    if current ~= before then return false, label .. ':compare_failed' end
    writes[#writes + 1] = {address = address, before = before, after = after}
    if not write(address, after, before) or read(address, #after) ~= after then
        return false, label .. ':write_or_readback_failed'
    end
    emit('write_readback_ok field=' .. label .. ' address=' .. string.format('%#x', address))
    return true, 'written'
end
local function apply_records(projectile_address, explosion_address, writes)
    writes = writes or {}
    if pointer(game + PROJECTILE_TABLE_RVA + PROJECTILE_TYPE * 8) ~= projectile_address
        or pointer(game + EXPLOSION_TABLE_RVA + EXPLOSION_TYPE * 8) ~= explosion_address then
        finish('disabled: settings slot changed before write; NO_WRITE')
        return
    end
    local projectile_row = read(projectile_address, PROJECTILE_RECORD_SIZE)
    local explosion_row = read(explosion_address, EXPLOSION_RECORD_SIZE)
    local projectile_ok, projectile_baseline, already_attached = valid_projectile_row(projectile_row or '')
    if not projectile_ok then finish('disabled: GL52 projectile row changed outside supported baseline') return end
    local explosion_ok, explosion_reason = valid_explosion_row(explosion_row)
    if not explosion_ok then
        finish('disabled: GL52 explosion row changed outside supported baseline reason=' .. explosion_reason)
        return
    end
    if u32(projectile_row, 0) ~= 222 or u32(projectile_row, 0x90) ~= 41 then
        finish('disabled: projectile identity guard failed')
        return
    end
    if u32(explosion_row, 0) ~= 41 or u32(explosion_row, 120) ~= 15 then
        finish('disabled: explosion identity/arc guard failed')
        return
    end

    local flags1_before = projectile_row:sub(PROJECTILE_FLAGS1_OFFSET + 1, PROJECTILE_FLAGS1_OFFSET + 2)
    local flags1_lo, flags1_hi = flags1_before:byte(1, 2)
    local flags1_value = flags1_lo + flags1_hi * 256
    local flags1_after_value = flags1_value
    if math.floor(flags1_after_value / PROJECTILE_AUTO_REMOVE_MASK) % 2 == 1 then
        flags1_after_value = flags1_after_value - PROJECTILE_AUTO_REMOVE_MASK
    end
    local flags1_after = string.char(flags1_after_value % 256, math.floor(flags1_after_value / 256))
    local flags2_before = projectile_row:sub(PROJECTILE_FLAGS2_OFFSET + 1, PROJECTILE_FLAGS2_OFFSET + 1)
    local flags2_value = flags2_before:byte(1)
    local flags2_after_value = flags2_value
    if math.floor(flags2_after_value / PROJECTILE_AUTO_ATTACH_MASK) % 2 == 0 then
        flags2_after_value = flags2_after_value + PROJECTILE_AUTO_ATTACH_MASK
    end
    local flags2_after = string.char(flags2_after_value)
    local ok, reason = guarded_write(writes, projectile_address + PROJECTILE_FLAGS1_OFFSET,
        flags1_before, flags1_after, 'ProjectileInfo.type222.projectile_unit_auto_remove=0')
    if ok then
        ok, reason = guarded_write(writes, projectile_address + PROJECTILE_FLAGS2_OFFSET,
            flags2_before, flags2_after, 'ProjectileInfo.type222.projectile_auto_attach=1')
    end
    if not ok then
        local restored, details = rollback(writes)
        finish('disabled: ' .. reason .. '; rollback=' .. (restored and 'complete' or 'INCOMPLETE:' .. details))
        return
    end

    local volume_now = read(explosion_address + STATUS_VOLUME_OFFSET, 4)
    local time_now = read(explosion_address + STATUS_VOLUME_TIME_OFFSET, 4)
    if not volume_now or not time_now then
        local restored, details = rollback(writes)
        finish('disabled: explosion field unreadable; rollback=' .. (restored and 'complete' or 'INCOMPLETE:' .. details))
        return
    end
    local wanted_volume, wanted_time = string.rep('\0',4), string.rep('\0',4)
    ok, reason = guarded_write(writes, explosion_address + STATUS_VOLUME_OFFSET,
        volume_now, wanted_volume, 'ExplosionInfo.type41.persistent_status_volume')
    if ok then
        ok, reason = guarded_write(writes, explosion_address + STATUS_VOLUME_TIME_OFFSET,
            time_now, wanted_time, 'ExplosionInfo.type41.status_volume_effect_time')
    end
    if not ok then
        local restored, details = rollback(writes)
        finish('disabled: ' .. reason .. '; rollback=' .. (restored and 'complete' or 'INCOMPLETE:' .. details))
        return
    end

    local final_projectile = read(projectile_address, PROJECTILE_RECORD_SIZE)
    local expected_final = projectile_with_adhesion(projectile_baseline)
    local final_explosion = read(explosion_address, EXPLOSION_RECORD_SIZE)
    -- Compare against the runtime snapshot, retaining its original relocated
    -- array pointer, and revalidate the array contents after the field writes.
    local expected_final_explosion = replace_bytes(explosion_row, STATUS_VOLUME_OFFSET, explosion_status_after)
    if final_projectile ~= expected_final or final_explosion ~= expected_final_explosion
        or not valid_explosion_row(final_explosion) then
        local restored, details = rollback(writes)
        finish('disabled: final record verification failed; rollback=' .. (restored and 'complete' or 'INCOMPLETE:' .. details))
        return
    end
    local adhesion_state = already_attached and 'already_present' or 'fields_set_test_pending'
    finish('APPLIED_READBACK_OK projectile_type=222 projectile_auto_attach=1 projectile_unit_auto_remove=0 state='
        .. adhesion_state .. ' explosion_type=41 StaticField=OFF discharge_timer=ON interval=0.50 duration=8.0s arc_type=15 one_shot_arc=preserved '
        .. 'periodic_explosion_request=ON gameplay=UNVERIFIED')
end

local next_check, wait_started, attempts, last_wait = 0, now(), 0, nil
local function mismatch_offsets(actual, expected)
    local parts = {}
    for i = 1, #expected do
        if actual:byte(i) ~= expected:byte(i) then
            parts[#parts + 1] = string.format('0x%x:%02x/%02x', i - 1, actual:byte(i), expected:byte(i))
            if #parts == 8 then break end
        end
    end
    return table.concat(parts, ',')
end
local function locate_step()
    local time = now()
    if time < next_check then return end
    next_check = time + 1.0
    attempts = attempts + 1
    local pj = pointer(game + PROJECTILE_TABLE_RVA + PROJECTILE_TYPE * 8)
    local ex = pointer(game + EXPLOSION_TABLE_RVA + EXPLOSION_TYPE * 8)
    local pj_row = pj and read(pj, PROJECTILE_RECORD_SIZE)
    local ex_row = ex and read(ex, EXPLOSION_RECORD_SIZE)
    local ex_valid, ex_reason, shake_address = valid_explosion_row(ex_row)
    local reason
    if not pj_row or not ex_row then
        reason = 'settings_not_resident projectile=' .. tostring(pj ~= nil and pj_row ~= nil)
            .. ' explosion=' .. tostring(ex ~= nil and ex_row ~= nil)
    elseif not valid_projectile_row(pj_row) then
        emit('RECORD_MISMATCH type=222 actual_type=' .. tostring(u32(pj_row, 0))
            .. ' differences_actual_expected=' .. mismatch_offsets(pj_row, PROJECTILE_EXPECTED))
        finish('disabled: GL52 projectile record differs from supported baseline; NO_WRITE')
        return
    elseif not ex_valid then
        emit('RECORD_MISMATCH type=41 actual_type=' .. tostring(u32(ex_row, 0))
            .. ' validation=' .. ex_reason .. ' nonpointer_differences_actual_expected='
            .. mismatch_offsets(normalize_explosion_pointer(ex_row), EXPLOSION_EXPECTED))
        finish('disabled: GL52 explosion record differs from supported baseline; NO_WRITE')
        return
    elseif not valid_explosion_references() then
        reason = 'staticfield_reference_records_not_ready_or_changed'
    else
        emit('RELOCATED_ARRAY_VERIFIED field=ExplosionInfo.type41.shake_assets offset=0x28 count=1 pointer='
            .. string.format('%#x', shake_address) .. ' expected_asset_hash=0xbe50b3e0791fddc7')
        emit('SETTINGS_SLOTS_VALIDATED projectile_type=222 record=' .. string.format('%#x', pj)
            .. ' explosion_type=41 record=' .. string.format('%#x', ex) .. ' attempts=' .. attempts)
        local writes = {}
        local applied_ok, why = pcall(apply_records, pj, ex, writes)
        if not applied_ok then
            local restored, details = rollback(writes)
            finish('disabled: apply exception=' .. tostring(why) .. '; rollback='
                .. (restored and 'complete' or 'INCOMPLETE:' .. details))
        end
        return
    end
    if time - wait_started >= 120 then
        finish('disabled: direct settings lookup timeout reason=' .. reason .. '; attempts=' .. attempts .. '; NO_WRITE')
        return
    end
    if reason ~= last_wait then emit('WAITING_FOR_SETTINGS reason=' .. reason); last_wait = reason end
end

-- Small, private adapter. No external Runtime module or lifecycle.
local ArcTimer = (function()
-- Pure scheduling: all engine/native operations are supplied by the adapter.
local M = {}
function M.new(api, config)
    local self = {world=nil, waiting={}, active={}, seen=setmetatable({}, {__mode='k'}),
        serial=0, next_poll=0, times={}, reported={}, api=api, config=config, stopped=false}
    local function emit(s) api.emit(s) end
    local function report(key, s)
        if not self.reported[key] then self.reported[key]=true;emit(s) end
    end
    local function release(track, why)
        self.waiting[track.unit]=nil
        for i=#self.active,1,-1 do if self.active[i]==track then table.remove(self.active,i) end end
        emit('ANCHOR_RELEASED id='..track.id..' reason='..why..' discharges='..track.pulses)
    end
    local function clear(why)
        if next(self.waiting) or #self.active>0 then emit('ARC_TRACKS_CLEARED reason='..why) end
        self.waiting={};self.active={};self.seen=setmetatable({}, {__mode='k'});self.times={};self.reported={}
    end
    local function activate(track, now, reason)
        if #self.active>=config.max_active then release(self.active[1],'replaced_by_new_anchor') end
        self.waiting[track.unit]=nil
        track.started=now;track.ends=now+config.duration;track.due=now
        self.active[#self.active+1]=track
        emit(('ANCHOR_ACTIVATED id=%d detection=%s position=(%.2f,%.2f,%.2f) interval=%.2f duration=%.1f')
            :format(track.id,reason,track.pos.x,track.pos.y,track.pos.z,config.interval,config.duration))
    end
    function self:tick(now)
        if self.stopped then return end
        if now<self.next_poll then return end
        self.next_poll=now+config.poll
        local context,why=api.context()
        if not context then
            if self.world then
                if why=='not_in_mission' or why=='world_unavailable' or why=='not_host' then
                    clear(why);self.world=nil
                else
                    -- Respawn must not re-arm old, already seen grenade models.
                    self.waiting={};self.active={};self.times={}
                end
            end
            report(why or 'context_unavailable','ARC_WAIT reason='..tostring(why))
            return
        end
        if self.world~=context.world then clear('world_changed');self.world=context.world end
        local units,reason=api.list_units(context.world)
        if type(units)=='table' then
            local new=0
            for i=#units,1,-1 do
                local unit=units[i]
                if not self.seen[unit] and new<config.max_discovery then
                    new=new+1
                    if api.alive(unit) and api.resource(unit)==config.resource then
                        local pos=api.position(unit)
                        if pos then
                            self.seen[unit]=true
                            self.serial=self.serial+1
                            local track={id=self.serial,unit=unit,born=now,pos=pos,last=now,slow=0,pulses=0,
                                source=context.source,peer_lo=context.peer_lo,peer_hi=context.peer_hi}
                            self.waiting[unit]=track
                            emit(('ANCHOR_SEEN id=%d resource=%s position=(%.2f,%.2f,%.2f)')
                                :format(track.id,config.resource,pos.x,pos.y,pos.z))
                        end
                    end
                end
            end
            if #units==0 then report('empty','GL52_UNIT_LOOKUP_EMPTY resource='..config.resource) end
        else report(reason or 'lookup_failed','ARC_UNIT_LOOKUP_FAILED reason='..tostring(reason)) end
        for unit,track in pairs(self.waiting) do
            if not api.alive(unit) then release(track,'unit_deleted')
            elseif now-track.born>config.flight_timeout then release(track,'flight_not_settled')
            else
                local pos=api.position(unit)
                if not pos then release(track,'position_unavailable')
                elseif now>track.last then
                    local dx,dy,dz=pos.x-track.pos.x,pos.y-track.pos.y,pos.z-track.pos.z
                    local speed=math.sqrt(dx*dx+dy*dy+dz*dz)/(now-track.last)
                    local lp=api.local_position and api.local_position(unit)
                    local linked=lp and ((lp.x-pos.x)^2+(lp.y-pos.y)^2+(lp.z-pos.z)^2)>0.01
                    track.pos=pos;track.last=now
                    if speed<=config.settle_speed then track.slow=track.slow+1 else track.slow=0 end
                    if now-track.born>=config.min_age then
                        if linked and speed<=config.linked_speed then activate(track,now,'linked_pose_approximation')
                        elseif track.slow>=config.settle_samples then activate(track,now,'settled_motion_approximation') end
                    end
                end
            end
        end
        local kept={}
        for _,at in ipairs(self.times) do if now-at<1 then kept[#kept+1]=at end end
        self.times=kept
        local i=1
        while i<=#self.active do
            local track=self.active[i]
            if now>=track.ends then release(track,'duration_complete')
            elseif not api.alive(track.unit) then release(track,'unit_deleted')
            elseif context.source~=track.source or not api.source_exists(track.source) then release(track,'source_changed_or_deleted')
            else
                local pos=api.position(track.unit)
                if not pos then release(track,'position_unavailable')
                elseif (pos.x-track.pos.x)^2+(pos.y-track.pos.y)^2+(pos.z-track.pos.z)^2>config.max_jump^2 then
                    release(track,'implausible_position_jump')
                else
                    track.pos=pos
                    if now>=track.due and #self.times<config.max_per_second then
                        local ok,error=api.explode(context,track,pos)
                        if ok then
                            track.pulses=track.pulses+1
                            self.times[#self.times+1]=now
                            track.due=now+config.interval -- no burst catch-up after a frame stall
                            if track.pulses==1 or track.pulses%4==0 then
                                emit(('ARC_REQUESTED id=%d discharge=%d explosion_type=41 position=(%.2f,%.2f,%.2f)')
                                    :format(track.id,track.pulses,pos.x,pos.y,pos.z))
                            end
                        else
                            track.due=now+config.poll
                            report(error or 'native_refused','ARC_REQUEST_REFUSED reason='..tostring(error))
                        end
                    end
                    i=i+1
                end
            end
        end
    end
    function self:shutdown() self.stopped=true;clear('shutdown');self.world=nil end
    return self
end
return M

end)()
local ShotDiscovery=(function()
-- Bounded engine-unit discovery, armed by the local GL-52 equipped/shot signal.
-- No component-manager census, memory-region scan, or transform offset guessing.
local M={}
function M.new(api,config)
    local self={world=nil,player=nil,gl52=nil,total=nil,held=false,found={},snapshot=nil,
        cursor=0,checked=0,matches=0,pending=false,next_snapshot=0,next_stats=0,
        next_equipped=0,reported={},stopped=false}
    local function report(key,message)
        if not self.reported[key] then self.reported[key]=true;api.emit(message) end
    end
    local function arm(now,reason,delta)
        self.pending=true
        api.emit(('GL52_SCAN_ARMED signal=%s shots_delta=%d chunk=%d'):format(reason,delta or 0,config.chunk))
    end
    local function reset(world)
        self.world=world;self.player=nil;self.gl52=nil;self.total=nil;self.held=false
        self.found={};self.snapshot=nil;self.pending=false;self.cursor=0
        self.next_stats=0;self.next_snapshot=0;self.next_equipped=0;self.reported={};self.held_reason=nil
    end
    function self:step(now,context,context_reason)
        if self.stopped then return end
        if not context then
            if context_reason=='not_in_mission' or context_reason=='not_host' or context_reason=='world_unavailable' then reset(nil)
            else self.snapshot=nil;self.pending=false end
            return
        end
        if self.world~=context.world then reset(context.world) end
        if now>=self.next_stats then
            self.next_stats=now+config.stats_poll
            local counts,why=api.shot_counts(context)
            local holding,held_reason=api.holding_gl52(context)
            holding=holding==true
            if held_reason and held_reason~=self.held_reason then
                self.held_reason=held_reason
                api.emit('GL52_EQUIPPED_STATE holding='..tostring(holding)..' reason='..held_reason)
            end
            if holding and not self.held and now>=self.next_equipped then
                self.next_equipped=now+config.equip_min_interval
                arm(now,'verified_equipped_bootstrap',0)
            end
            self.held=holding
            if counts then
                if self.player~=context.player_entity or self.gl52==nil then
                    self.player=context.player_entity;self.gl52=counts.gl52;self.total=counts.total
                    api.emit(('GL52_SHOT_BASELINE gl52=%d total=%d holding=%s'):format(counts.gl52,counts.total,tostring(holding)))
                    -- A late first readable stat may already include the first shot.
                    if counts.gl52>0 then arm(now,'first_readable_gl52_counter',math.min(counts.gl52,4)) end
                else
                    local specific=counts.gl52-self.gl52
                    local generic=counts.total-self.total
                    self.gl52=counts.gl52;self.total=counts.total
                    if specific>0 then arm(now,'gl52_source_stat',math.min(specific,4))
                    elseif generic>0 and holding then arm(now,'fired_stat_while_gl52_equipped',math.min(generic,4)) end
                end
            else report(why or 'stat_unavailable','GL52_SHOT_STAT_WAIT reason='..tostring(why)) end
        end
        if not self.snapshot and self.pending and now>=self.next_snapshot then
            self.pending=false;self.next_snapshot=now+config.snapshot_min_interval
            local list,why=api.snapshot_units(context.world)
            if type(list)~='table' then
                report(why or 'snapshot_unavailable','GL52_SNAPSHOT_REFUSED reason='..tostring(why))
            else
                local n=#list
                if n==0 and next(list)~=nil then
                    local dense={}
                    for _,unit in pairs(list) do
                        dense[#dense+1]=unit
                        if #dense>config.max_snapshot then break end
                    end
                    list=dense;n=#dense
                end
                if n>config.max_snapshot then
                    api.emit(('GL52_SNAPSHOT_REFUSED reason=unit_cap units=%d cap=%d'):format(n,config.max_snapshot))
                else
                    self.snapshot=list;self.cursor=n;self.checked=0;self.matches=0
                    api.emit(('GL52_SNAPSHOT_STARTED units=%d chunk=%d resource=%s'):format(n,config.chunk,config.resource))
                end
            end
        end
        if self.snapshot then
            local stop=math.max(1,self.cursor-config.chunk+1)
            -- Check the end first; newly spawned objects commonly appear there.
            -- Correctness does not depend on that ordering: the bounded snapshot is completed.
            for i=self.cursor,stop,-1 do
                local unit=self.snapshot[i]
                self.checked=self.checked+1
                if unit and api.alive(unit) and api.resource(unit)==config.resource then
                    if not self.found[unit] then self.matches=self.matches+1 end
                    self.found[unit]=true
                end
            end
            self.cursor=stop-1
            if self.cursor==0 then
                api.emit(('GL52_SNAPSHOT_DONE checked=%d new_matches=%d resource=%s'):format(self.checked,self.matches,config.resource))
                self.snapshot=nil
            end
        end
    end
    function self:units(world,preferred)
        local list,added={},{}
        if self.world~=world then return preferred or {} end
        if type(preferred)=='table' then
            for _,unit in ipairs(preferred) do
                if api.alive(unit) and api.resource(unit)==config.resource then self.found[unit]=true end
            end
        end
        for unit in pairs(self.found) do
            if api.alive(unit) and api.resource(unit)==config.resource then
                if not added[unit] then list[#list+1]=unit;added[unit]=true end
            else self.found[unit]=nil end
        end
        return list
    end
    function self:shutdown()self.stopped=true;reset(nil)end
    return self
end
return M

end)()
local CONFIG = {resource='a6cd8a90185b6567',interval=0.5,duration=8.0,poll=0.25,
    max_active=4,max_per_second=8,max_discovery=128,flight_timeout=5.0,min_age=0.15,
    settle_speed=10.0,linked_speed=30.0,settle_samples=2,max_jump=25.0}
local EXPLOSION_REQUEST_RVA=0x13c0a80
local EXPLOSION_REQUEST_PROLOGUE=unhex('40534883ec308b41204c8bda488bd93d000100000f8369020000')
local EXPLOSION_QUEUE_RVA=0x346d558
local exe=tonumber(ffi.cast('uintptr_t',k.GetModuleHandleA(nil)))
local timer,discovery,arc_context,arc_context_reason,arc_failed,next_setup=nil,nil,nil,nil,false,0
local function word(address)
    local bytes=read(address,4)
    return bytes and u32(bytes,0)
end
local function source_exists(id)
    if type(id)~='number' or id<=0 or id>=4294967296 or id%1~=0 then return false end
    local manager=pointer(exe+0x1b135b8)
    local count=manager and word(manager+128)
    local generations=manager and pointer(manager+136)
    local index,generation=id%4194304,math.floor(id/4194304)%256
    if not count or count>4194304 or index>=count or not generations then return false end
    local byte=read(generations+index,1)
    return byte and byte:byte()==generation
end
local function mul32(a,b)
    return (a*(b%65536)+((a*math.floor(b/65536))%65536)*65536)%4294967296
end
local function network_entity(id)
    if not id or id==32767 then return nil end
    local manager=pointer(game+0x346bf98)
    local header=manager and read(manager+0xf22ec8,20)
    if not header then return nil end
    local slots=u64at(header,0)
    local capacity,empty,mult=u32(header,8),u32(header,12),u32(header,16)
    if slots<65536 or slots>=0x800000000000 or not capacity or capacity<1 or capacity>1048576 then return nil end
    local n=capacity
    while n>1 do if n%2~=0 then return nil end;n=n/2 end
    local start=mul32(id,mult)
    -- Only a known avatar's hash lookup; never enumerate entity/component maps.
    for probe=0,math.min(capacity,64)-1 do
        local entry=read(slots+((start+probe)%capacity)*8,8)
        if not entry then return nil end
        local key=u32(entry,0)
        if key==id then
            local index=u32(entry,4)
            if index>=1048576 then return nil end
            return word(manager+0xf32f20+index*24)
        end
        if key==empty then return nil end
    end
end
local function local_source()
    local user=pointer(game+0x347cef0)
    local peer=user and read(user+0xb398,8)
    local manager=pointer(game+0x3326468)
    local count=manager and word(manager+132)
    if not peer or not count or count<1 or count>4 then return nil end
    local lo,hi=u32(peer,0),u32(peer,4)
    for slot=0,count-1 do
        local entry=read(manager+712+slot*56,8)
        if entry and u32(entry,0)==lo and u32(entry,4)==hi then
            local id=word(manager+936+slot*32)
            local avatar=network_entity(id)
            if avatar and source_exists(avatar) then
                local descriptor=pointer(manager+232+slot*8)
                local player=descriptor and word(descriptor+8)
                return avatar,lo,hi,player
            end
        end
    end
end
local function hash_lookup(address,key,stride)
    if not key then return nil end
    local header=read(address,20)
    if not header then return nil end
    local slots=u64at(header,0)
    local cap,empty,mult=u32(header,8),u32(header,12),u32(header,16)
    if cap==0 then return false end
    if slots<65536 or slots>=0x800000000000 or cap>65536 then return nil end
    local n=cap
    while n>1 do if n%2~=0 then return nil end;n=n/2 end
    local first=mul32(key,mult)
    for probe=0,math.min(cap,128)-1 do
        local bytes=read(slots+((first+probe)%cap)*stride,8)
        if not bytes then return nil end
        local found=u32(bytes,0)
        if found==key then return u32(bytes,4) end
        if found==empty then return false end
    end
end
local function holding_gl52(context)
    local wielder=pointer(game+53634080)
    if not wielder then return false,'wielder_manager_unavailable' end
    local instance=wielder and hash_lookup(wielder+48,context.source,8)
    if not instance or instance>=65536 then return false,'local_wielder_index_unavailable' end
    local slots=instance and instance<65536 and pointer(wielder+96)
    local held=slots and word(slots+instance*464)
    if not held or held==0 or held==context.source or not source_exists(held) then return false,'held_entity_empty_or_stale' end
    local entities=pointer(game+54968216)
    local index=entities and hash_lookup(entities+15838896,held,8)
    if not index or index>=1048576 then return false,'held_type_map_unavailable' end
    local descriptor=read(entities+15937304+index*24,12)
    if not descriptor or u32(descriptor,8)~=held then return false,'held_descriptor_identity_mismatch' end
    local lo,hi=u32(descriptor,0),u32(descriptor,4)
    if lo==0xcfa63f9b and hi==0xfe3b29b2 then return true,'verified_gl52_type' end
    return false,string.format('different_weapon_type_%08x%08x',hi,lo)
end
local FIRED_KEY=1448579290
local function shot_counts(context)
    if not context.player_entity then return nil,'local_player_descriptor_unavailable' end
    local score=pointer(game+53635808)
    local index=score and hash_lookup(score+228696,context.player_entity,8)
    if not index or index>=4 then return nil,'local_stats_index_unavailable' end
    local at=score+228760+index*40
    local record=read(at,40)
    if not record then return nil,'local_stats_record_unavailable' end
    local main=hash_lookup(at,FIRED_KEY,20)
    if main==nil then return nil,'local_stats_main_unavailable' end
    main=main or 0
    if main>=2147483648 then return nil,'local_stats_counter_invalid' end
    local result={gl52=0,total=main}
    local sources=u64at(record,24)
    if sources==0 then return result end
    local blocks=read(sources,64*328)
    if not blocks then return nil,'local_stats_source_blocks_unavailable' end
    -- Fixed source blocks of this one local player, not an ECS/global entity scan.
    for block=0,63 do
        local base=block*328
        local lo,hi=u32(blocks,base),u32(blocks,base+4)
        if lo~=0 or hi~=0 then
            local is_gl52=(lo==0xcfa63f9b and hi==0xfe3b29b2) or (lo==0x4f560c02 and hi==0x2f67bf9c)
            for entry=0,15 do
                local off=base+8+entry*20
                local key=u32(blocks,off)
                if key==0 then break end
                if key==FIRED_KEY then
                    local value=u32(blocks,off+4)
                    if value>=2147483648 then return nil,'local_stats_counter_invalid' end
                    result.total=result.total+value
                    if is_gl52 then result.gl52=result.gl52+value end
                end
            end
        end
    end
    return result
end
local function mission_host()
    local state=pointer(game+0x3326340)
    if not state or word(state+0xac21c)~=4 then return false,'not_in_mission' end
    local mode=pointer(game+0x33266a0)
    if not mode or word(mode+8)~=1 then return false,'game_mode_unavailable' end
    local descriptor=pointer(mode+56)
    local flags=descriptor and word(descriptor+20)
    if not flags or flags%2~=1 then return false,'not_host' end
    return true
end
local function callable(object,name)
    return type(object)=='table' and type(rawget(object,name))=='function'
end
local function call(object,name,...)
    if not callable(object,name) then return nil end
    local ok,value=pcall(rawget(object,name),...)
    return ok and value or nil
end
local function position_vector(value)
    if not value then return nil end
    local x,y,z=tostring(value):match('^Vector3%(([^,]+),%s*([^,]+),%s*([^%)]+)%)')
    x,y,z=tonumber(x),tonumber(y),tonumber(z)
    if not x or not y or not z or x~=x or y~=y or z~=z
        or math.abs(x)>100000 or math.abs(y)>100000 or math.abs(z)>100000 then return nil end
    return {x=x,y=y,z=z}
end
local function setup_arc_timer()
    local sr=rawget(_G,'stingray')
    local App=sr and rawget(sr,'Application')
    local World=sr and rawget(sr,'World')
    local Unit=sr and rawget(sr,'Unit')
    local Id64=sr and rawget(sr,'IdString64')
    if not callable(App,'main_world') or not callable(World,'units_by_resource')
        or not callable(Unit,'alive') or not callable(Unit,'world_position') or not callable(Id64,'from_hex') then
        return nil,'engine_unit_API_unavailable'
    end
    if read(game+EXPLOSION_REQUEST_RVA,#EXPLOSION_REQUEST_PROLOGUE)~=EXPLOSION_REQUEST_PROLOGUE then
        return false,'native_explosion_prologue_mismatch'
    end
    local resource=call(Id64,'from_hex',CONFIG.resource)
    if not resource then return nil,'resource_id_conversion_unavailable' end
    local request=ffi.cast('void (*)(void *, const float *, uint32_t, uint32_t, uint32_t, uint64_t, uint32_t, '
        ..'const float *, uint8_t, uint32_t, const uint32_t *, const float *, const float *, uint8_t, uint32_t)',
        game+EXPLOSION_REQUEST_RVA)
    local api={emit=emit,source_exists=source_exists}
    function api.context()
        local ready,reason=mission_host()
        if not ready then arc_context=nil;arc_context_reason=reason;return nil,reason end
        local world=call(App,'main_world')
        if not world then arc_context=nil;arc_context_reason='world_unavailable';return nil,arc_context_reason end
        local source,lo,hi,player=local_source()
        if not source then arc_context=nil;arc_context_reason='local_avatar_unavailable';return nil,arc_context_reason end
        arc_context={world=world,source=source,peer_lo=lo,peer_hi=hi,player_entity=player}
        arc_context_reason=nil
        return arc_context
    end
    function api.list_units(world)
        local units=call(World,'units_by_resource',world,resource)
        return discovery:units(world,units)
    end
    function api.alive(unit) return call(Unit,'alive',unit)==true end
    function api.resource(unit)
        return tostring(unit):match('#ID%[([0-9a-fA-F]+)%]') and
            tostring(unit):match('#ID%[([0-9a-fA-F]+)%]'):lower() or nil
    end
    function api.position(unit)
        if not api.alive(unit) then return nil end
        return position_vector(call(Unit,'world_position',unit,1))
    end
    function api.local_position(unit)
        if not api.alive(unit) or not callable(Unit,'local_position') then return nil end
        return position_vector(call(Unit,'local_position',unit,1))
    end
    api.shot_counts=shot_counts
    api.holding_gl52=holding_gl52
    function api.snapshot_units(world)
        local units=call(World,'units',world)
        if type(units)~='table' then return nil,'World.units_unavailable' end
        return units
    end
    function api.explode(context,track,pos)
        if not source_exists(track.source) then return false,'source_deleted' end
        if read(game+EXPLOSION_REQUEST_RVA,#EXPLOSION_REQUEST_PROLOGUE)~=EXPLOSION_REQUEST_PROLOGUE then
            return false,'native_explosion_code_changed'
        end
        local address=pointer(game+EXPLOSION_TABLE_RVA+41*8)
        local row=address and read(address,EXPLOSION_RECORD_SIZE)
        if not valid_explosion_row(row) or u32(row,100)~=0 or u32(row,104)~=0 then
            return false,'explosion_settings_changed'
        end
        local queue=pointer(game+EXPLOSION_QUEUE_RVA)
        local count=queue and word(queue+32)
        if not count or count>=240 then return false,'explosion_queue_unavailable_or_full' end
        local at=ffi.new('float[3]',pos.x,pos.y,pos.z)
        local peer=ffi.new('uint64_t',track.peer_hi)*4294967296+track.peer_lo
        -- Exact defaults used by the supplied reviewed native adapter.
        request(ffi.cast('void *',queue),at,41,track.source,track.source,peer,0,nil,1,0,nil,nil,nil,0,0)
        return true
    end
    discovery=ShotDiscovery.new(api,{resource=CONFIG.resource,chunk=128,max_snapshot=65536,
        stats_poll=0.25,snapshot_min_interval=1.5,equip_min_interval=10.0})
    timer=ArcTimer.new(api,CONFIG)
    emit('ARC_TIMER_READY source=RESOURCE_QUERY_PLUS_LOCAL_GL52_SHOT_SNAPSHOT position=Unit.world_position native_explosion_rva=0x13c0a80 '
        ..'interval=0.50 duration=8.0 max_active=4 max_per_second=8 HOST_ONLY=ON DAMAGE_TRIGGER=OFF '
        ..'BLAST_AND_ARC=REPEATED ATTACH_DETECTION=POSE_OR_SLOW_MOTION_APPROXIMATION '
        ..'SNAPSHOT_CHUNK=128 SNAPSHOT_MIN_INTERVAL=1.50 SNAPSHOT_TRIGGER=VERIFIED_GL52_EQUIPPED_OR_FIRED')
    return true
end
local setup_reason
local function arc_step()
    if arc_failed then return end
    if not timer and now()>=next_setup then
        next_setup=now()+2
        local ready,why=setup_arc_timer()
        if ready==false then arc_failed=true;emit('ARC_DISABLED reason='..why);return end
        if not ready and why~=setup_reason then setup_reason=why;emit('ARC_SETUP_WAIT reason='..tostring(why)) end
    end
    if timer then
        local time=now()
        timer:tick(time)
        discovery:step(time,arc_context,arc_context_reason)
    end
end
local previous_shutdown=rawget(_G,'shutdown')
rawset(_G,'shutdown',function(...)
    arc_failed=true
    if timer then timer:shutdown() end
    if discovery then discovery:shutdown() end
    if log then pcall(function() log:close() end);log=nil end
    if type(previous_shutdown)=='function' then return previous_shutdown(...) end
end)


local original_update = rawget(_G, 'update')
local wrapper
wrapper = function(...)
    if public.status == 'initializing' then
        local ok, why = pcall(locate_step)
        if not ok then finish('disabled: runtime error: ' .. tostring(why)) end
    end
    if public.data_applied and not arc_failed then
        local ok,why=pcall(arc_step)
        if not ok then
            arc_failed=true
            if timer then timer:shutdown() end
            emit('ARC_DISABLED reason=runtime_error details='..tostring(why))
        end
    end
    return original_update(...)
end
rawset(_G, 'update', wrapper)
return public
