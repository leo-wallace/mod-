-- Pure scheduling: all engine/native operations are supplied by the adapter.
local M = {}
function M.new(api, config)
    local self = {world=nil, waiting={}, active={}, seen=setmetatable({}, {__mode='k'}),
        serial=0, next_poll=0, times={}, reported={}, api=api, config=config, stopped=false}
    local function emit(s) api.emit(s) end
    local function report(key, s)
        if not self.reported[key] then self.reported[key]=true;emit(s) end
    end
    local function release(track, why)
        self.waiting[track.unit]=nil
        for i=#self.active,1,-1 do if self.active[i]==track then table.remove(self.active,i) end end
        emit('ANCHOR_RELEASED id='..track.id..' reason='..why..' discharges='..track.pulses)
    end
    local function clear(why)
        if next(self.waiting) or #self.active>0 then emit('ARC_TRACKS_CLEARED reason='..why) end
        self.waiting={};self.active={};self.seen=setmetatable({}, {__mode='k'});self.times={};self.reported={}
    end
    local function activate(track, now, reason)
        if #self.active>=config.max_active then release(self.active[1],'replaced_by_new_anchor') end
        self.waiting[track.unit]=nil
        track.started=now;track.ends=now+config.duration;track.due=now
        self.active[#self.active+1]=track
        emit(('ANCHOR_ACTIVATED id=%d detection=%s position=(%.2f,%.2f,%.2f) interval=%.2f duration=%.1f')
            :format(track.id,reason,track.pos.x,track.pos.y,track.pos.z,config.interval,config.duration))
    end
    function self:tick(now)
        if self.stopped then return end
        if now<self.next_poll then return end
        self.next_poll=now+config.poll
        local context,why=api.context()
        if not context then
            if self.world then
                if why=='not_in_mission' or why=='world_unavailable' or why=='not_host' then
                    clear(why);self.world=nil
                else
                    -- Respawn must not re-arm old, already seen grenade models.
                    self.waiting={};self.active={};self.times={}
                end
            end
            report(why or 'context_unavailable','ARC_WAIT reason='..tostring(why))
            return
        end
        if self.world~=context.world then clear('world_changed');self.world=context.world end
        local units,reason=api.list_units(context.world)
        if type(units)=='table' then
            local new=0
            for i=#units,1,-1 do
                local unit=units[i]
                if not self.seen[unit] and new<config.max_discovery then
                    new=new+1
                    if api.alive(unit) and api.resource(unit)==config.resource then
                        local pos=api.position(unit)
                        if pos then
                            self.seen[unit]=true
                            self.serial=self.serial+1
                            local track={id=self.serial,unit=unit,born=now,pos=pos,last=now,slow=0,pulses=0,
                                source=context.source,peer_lo=context.peer_lo,peer_hi=context.peer_hi}
                            self.waiting[unit]=track
                            emit(('ANCHOR_SEEN id=%d resource=%s position=(%.2f,%.2f,%.2f)')
                                :format(track.id,config.resource,pos.x,pos.y,pos.z))
                        end
                    end
                end
            end
            if #units==0 then report('empty','GL52_UNIT_LOOKUP_EMPTY resource='..config.resource) end
        else report(reason or 'lookup_failed','ARC_UNIT_LOOKUP_FAILED reason='..tostring(reason)) end
        for unit,track in pairs(self.waiting) do
            if not api.alive(unit) then release(track,'unit_deleted')
            elseif now-track.born>config.flight_timeout then release(track,'flight_not_settled')
            else
                local pos=api.position(unit)
                if not pos then release(track,'position_unavailable')
                elseif now>track.last then
                    local dx,dy,dz=pos.x-track.pos.x,pos.y-track.pos.y,pos.z-track.pos.z
                    local speed=math.sqrt(dx*dx+dy*dy+dz*dz)/(now-track.last)
                    local lp=api.local_position and api.local_position(unit)
                    local linked=lp and ((lp.x-pos.x)^2+(lp.y-pos.y)^2+(lp.z-pos.z)^2)>0.01
                    track.pos=pos;track.last=now
                    if speed<=config.settle_speed then track.slow=track.slow+1 else track.slow=0 end
                    if now-track.born>=config.min_age then
                        if linked and speed<=config.linked_speed then activate(track,now,'linked_pose_approximation')
                        elseif track.slow>=config.settle_samples then activate(track,now,'settled_motion_approximation') end
                    end
                end
            end
        end
        local kept={}
        for _,at in ipairs(self.times) do if now-at<1 then kept[#kept+1]=at end end
        self.times=kept
        local i=1
        while i<=#self.active do
            local track=self.active[i]
            if now>=track.ends then release(track,'duration_complete')
            elseif not api.alive(track.unit) then release(track,'unit_deleted')
            elseif context.source~=track.source or not api.source_exists(track.source) then release(track,'source_changed_or_deleted')
            else
                local pos=api.position(track.unit)
                if not pos then release(track,'position_unavailable')
                elseif (pos.x-track.pos.x)^2+(pos.y-track.pos.y)^2+(pos.z-track.pos.z)^2>config.max_jump^2 then
                    release(track,'implausible_position_jump')
                else
                    track.pos=pos
                    if now>=track.due and #self.times<config.max_per_second then
                        local ok,error=api.explode(context,track,pos)
                        if ok then
                            track.pulses=track.pulses+1
                            self.times[#self.times+1]=now
                            track.due=now+config.interval -- no burst catch-up after a frame stall
                            if track.pulses==1 or track.pulses%4==0 then
                                emit(('ARC_REQUESTED id=%d discharge=%d explosion_type=41 position=(%.2f,%.2f,%.2f)')
                                    :format(track.id,track.pulses,pos.x,pos.y,pos.z))
                            end
                        else
                            track.due=now+config.poll
                            report(error or 'native_refused','ARC_REQUEST_REFUSED reason='..tostring(error))
                        end
                    end
                    i=i+1
                end
            end
        end
    end
    function self:shutdown() self.stopped=true;clear('shutdown');self.world=nil end
    return self
end
return M
