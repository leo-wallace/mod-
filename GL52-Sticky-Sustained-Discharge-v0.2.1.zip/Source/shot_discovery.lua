-- Bounded engine-unit discovery, armed by the local GL-52 equipped/shot signal.
-- No component-manager census, memory-region scan, or transform offset guessing.
local M={}
function M.new(api,config)
    local self={world=nil,player=nil,gl52=nil,total=nil,held=false,found={},snapshot=nil,
        cursor=0,checked=0,matches=0,pending=false,next_snapshot=0,next_stats=0,
        next_equipped=0,reported={},stopped=false}
    local function report(key,message)
        if not self.reported[key] then self.reported[key]=true;api.emit(message) end
    end
    local function arm(now,reason,delta)
        self.pending=true
        api.emit(('GL52_SCAN_ARMED signal=%s shots_delta=%d chunk=%d'):format(reason,delta or 0,config.chunk))
    end
    local function reset(world)
        self.world=world;self.player=nil;self.gl52=nil;self.total=nil;self.held=false
        self.found={};self.snapshot=nil;self.pending=false;self.cursor=0
        self.next_stats=0;self.next_snapshot=0;self.next_equipped=0;self.reported={};self.held_reason=nil
    end
    function self:step(now,context,context_reason)
        if self.stopped then return end
        if not context then
            if context_reason=='not_in_mission' or context_reason=='not_host' or context_reason=='world_unavailable' then reset(nil)
            else self.snapshot=nil;self.pending=false end
            return
        end
        if self.world~=context.world then reset(context.world) end
        if now>=self.next_stats then
            self.next_stats=now+config.stats_poll
            local counts,why=api.shot_counts(context)
            local holding,held_reason=api.holding_gl52(context)
            holding=holding==true
            if held_reason and held_reason~=self.held_reason then
                self.held_reason=held_reason
                api.emit('GL52_EQUIPPED_STATE holding='..tostring(holding)..' reason='..held_reason)
            end
            if holding and not self.held and now>=self.next_equipped then
                self.next_equipped=now+config.equip_min_interval
                arm(now,'verified_equipped_bootstrap',0)
            end
            self.held=holding
            if counts then
                if self.player~=context.player_entity or self.gl52==nil then
                    self.player=context.player_entity;self.gl52=counts.gl52;self.total=counts.total
                    api.emit(('GL52_SHOT_BASELINE gl52=%d total=%d holding=%s'):format(counts.gl52,counts.total,tostring(holding)))
                    -- A late first readable stat may already include the first shot.
                    if counts.gl52>0 then arm(now,'first_readable_gl52_counter',math.min(counts.gl52,4)) end
                else
                    local specific=counts.gl52-self.gl52
                    local generic=counts.total-self.total
                    self.gl52=counts.gl52;self.total=counts.total
                    if specific>0 then arm(now,'gl52_source_stat',math.min(specific,4))
                    elseif generic>0 and holding then arm(now,'fired_stat_while_gl52_equipped',math.min(generic,4)) end
                end
            else report(why or 'stat_unavailable','GL52_SHOT_STAT_WAIT reason='..tostring(why)) end
        end
        if not self.snapshot and self.pending and now>=self.next_snapshot then
            self.pending=false;self.next_snapshot=now+config.snapshot_min_interval
            local list,why=api.snapshot_units(context.world)
            if type(list)~='table' then
                report(why or 'snapshot_unavailable','GL52_SNAPSHOT_REFUSED reason='..tostring(why))
            else
                local n=#list
                if n==0 and next(list)~=nil then
                    local dense={}
                    for _,unit in pairs(list) do
                        dense[#dense+1]=unit
                        if #dense>config.max_snapshot then break end
                    end
                    list=dense;n=#dense
                end
                if n>config.max_snapshot then
                    api.emit(('GL52_SNAPSHOT_REFUSED reason=unit_cap units=%d cap=%d'):format(n,config.max_snapshot))
                else
                    self.snapshot=list;self.cursor=n;self.checked=0;self.matches=0
                    api.emit(('GL52_SNAPSHOT_STARTED units=%d chunk=%d resource=%s'):format(n,config.chunk,config.resource))
                end
            end
        end
        if self.snapshot then
            local stop=math.max(1,self.cursor-config.chunk+1)
            -- Check the end first; newly spawned objects commonly appear there.
            -- Correctness does not depend on that ordering: the bounded snapshot is completed.
            for i=self.cursor,stop,-1 do
                local unit=self.snapshot[i]
                self.checked=self.checked+1
                if unit and api.alive(unit) and api.resource(unit)==config.resource then
                    if not self.found[unit] then self.matches=self.matches+1 end
                    self.found[unit]=true
                end
            end
            self.cursor=stop-1
            if self.cursor==0 then
                api.emit(('GL52_SNAPSHOT_DONE checked=%d new_matches=%d resource=%s'):format(self.checked,self.matches,config.resource))
                self.snapshot=nil
            end
        end
    end
    function self:units(world,preferred)
        local list,added={},{}
        if self.world~=world then return preferred or {} end
        if type(preferred)=='table' then
            for _,unit in ipairs(preferred) do
                if api.alive(unit) and api.resource(unit)==config.resource then self.found[unit]=true end
            end
        end
        for unit in pairs(self.found) do
            if api.alive(unit) and api.resource(unit)==config.resource then
                if not added[unit] then list[#list+1]=unit;added[unit]=true end
            else self.found[unit]=nil end
        end
        return list
    end
    function self:shutdown()self.stopped=true;reset(nil)end
    return self
end
return M
