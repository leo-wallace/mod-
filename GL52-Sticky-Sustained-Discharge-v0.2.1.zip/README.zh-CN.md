# GL-52 黏附持续放电 v0.2.1（游戏实测待确认）

## v0.2.1 修复点

你的 GL52StaticFieldStick(4).log 已通过黏附写入和原生接口入口检查，但资源查询两次返回空，未出现 ANCHOR_SEEN / ANCHOR_ACTIVATED / ARC_REQUESTED。因此 v0.2.0 没有发出任何重复放电请求；不能据此说原生电弧请求本身失败。

现有参考包明确记载：units_by_resource 能找到炮台，却对护卫犬等动态单位返回空，作者以 World.units 分帧核对补充。本版增加同类补充，但只由本地 GL-52 发射计数增加、或经过存活和类型校验的 GL-52 装备切入信号启动。不会根据敌人受伤触发。

一次取世界单位快照，随后每帧最多检查128个存活/资源标识；只把资源哈希等于 a6cd8a90185b6567 的单位送入原有计时器。最少间隔1.5秒才可开始下一个快照，连续射击合并待处理信号，快照数量上限65536。刚进入GL-52装备时会补查一次，之后闲置不反复扫描。

此方式有一次世界单位列表分配和分帧读取成本；不是全局 ECS 或内存扫描。GL-52 是否出现在 World.units 中，仍需这次真实日志确认，不宣称已经验证。

## 这版实际做什么

保留 v0.1.3 已回读成功、你已肉眼看到黏附的 GL-52 type222 弹体设置。删除上一版没有达到预期的 StaticField 15秒设置，恢复其 type41 爆炸的这两个字段为原版0/0。

这版不再把静电眩晕区当作持续电弧：在检测到弹体落地/黏附后，用原生 RequestExplosion 接口在弹体当前位置重复请求 GL-52 原有 type41 爆炸（其 ArcType=15）。每0.50秒一次，最多持续8秒，同一房主最多4个生效弹体、每秒最多8次请求。没有“先伤到敌人”的启动条件；可以打在地面上等敌人靠近。原版电弧仍按自己的范围寻找目标，空地没有可连接的敌人时不一定能看见电弧线。

**目前调用的是完整原版爆炸，所以原版爆炸伤害与电弧一起重复，尚非仅电弧版。** 不修改基础单次伤害数值，也不使用 G-109 周期脉冲组件。弹体删除、世界切换、超时、房主死亡导致来源失效或脚本 shutdown 后停止。

## 安装

1. 完全退出游戏。替换旧 GL52StaticFieldStick v0.1.x / v0.2.0，只启用一个版本；不要同时加载多个。
2. 保留 Bingus Shared Loader v17 / API1。无需安装 HD2Runtime，本包不导入或启动它。
3. 由你做房主/单人开始任务后测试。客机仍可能具有黏附设置，但本包不会由客机请求重复爆炸。
4. 第一轮暂时关闭其他修改 GL-52 type222 弹体或 type41 爆炸的包。兼容仅把 type222 ricochet count 1改0的已知安全引信移除版本。

## 测试顺序

- 先对平坦地面射一发，再让小型敌人进入落点附近，观察8秒内是否反复放电/受伤。
- 再射在大型移动敌人身上，观察后续放电是否跟随弹体，而不是停留在第一次命中位置。
- 最后连续发射超过4发，确认旧的放电点会停止，性能没有明显异常。

## 日志

`%LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\GL52StaticFieldStick.log`

启动：`version=0.2.1-shot-window-discovery`。

| 日志 | 意义 |
|---|---|
| APPLIED_READBACK_OK | 黏附设置已应用、旧 StaticField 字段已恢复；只证明数据写入 |
| ARC_TIMER_READY | 引擎 Unit API、原生爆炸函数入口检查通过 |
| ARC_WAIT reason=not_host | 当前是客机，不执行本包的重复放电 |
| ARC_WAIT reason=local_avatar_unavailable | 当前没有可校验的本地角色来源（如死亡/复活阶段） |
| GL52_UNIT_LOOKUP_EMPTY | 该资源过滤查询暂未找到 GL-52 弹体 |
| GL52_SCAN_ARMED | 已核对本地GL-52装备或发射信号，启动补充查找 |
| GL52_EQUIPPED_STATE | 装备类型或映射状态发生变化时记录；verified_gl52_type才表示已核对GL-52 |
| GL52_SHOT_BASELINE | 读取到本地发射统计基线，不要求命中/造成伤害 |
| GL52_SHOT_STAT_WAIT | 统计暂不可读；仍可由已核对的装备切入信号补查一次 |
| GL52_SNAPSHOT_STARTED | 取到一次世界单位快照，开始每帧128个核对 |
| GL52_SNAPSHOT_DONE new_matches=... | 本次快照找到的新增GL-52模型数；0表示此次仍未发现 |
| GL52_SNAPSHOT_REFUSED | API不可用或数量超过65536上限，停止本次补查 |
| ANCHOR_SEEN | 找到了活着的 GL-52 模型和可读世界坐标 |
| ANCHOR_ACTIVATED | 姿态/低速样本判为已落地或黏附，开始8秒计时 |
| ARC_REQUESTED | 已调用原生爆炸请求；第一发及每第四发记一次，不能单凭这行认定实际伤害成功 |
| ANCHOR_RELEASED | 弹体删除/超时/角色变化等，已停止 |
| ARC_REQUEST_REFUSED / ARC_DISABLED | 原生调用守卫拒绝，记录具体原因 |

如果仍只有黏附没有后续电弧，请提供这次启动并完成射击后的该日志。通过上述链条能区分“没有找到模型”“落地判断没触发”“原生请求拒绝”及“原生请求已发但游戏无效果”。

## 数据来源与限制

- GL-52 模型资源：`a6cd8a90185b6567`，来自同版本 ProjectileSettings type222 的 `projectile_unit_path=12019415332010288487`。
- 优先 `stingray.World.units_by_resource(world, IdString64.from_hex(...))` 查询这个资源，同时添加GL-52装备/发射信号触发的 `World.units` 分帧补查。用 `Unit.alive` 校验生命周期、`Unit.world_position(unit,1)` 读取世界坐标。参考项目里已提供的 Super Laser Sights/Target Lock 源码；GL-52 弹体可见性仍需本次日志确认。
- 不猜 transform 偏移，不枚举全局 ECS/component manager，不扫描虚拟内存区域，不增加 health/status 探针。
- 落地/黏附判断不是直接读取 StickyComponent：local/world translation 不同且低速，或连续两次低速样本，为近似判据。地面弹可能约0.5秒后开始；移动敌人上的连接姿态需实测。
- 原生爆炸 ABI、RVA、队列以及本地角色/房主、wielder/实体类型、本地玩家统计映射字段来自用户给过的同版本 HD2Runtime 0.28.1 源码及 bindings。构建逐项核对46个结构字段；本包只独立写了必要的小接口，未打包它的生命周期/配置加载/武器覆盖系统。
- 精确 EXE/DLL SHA256 守卫：Steam build25480438。每次原生请求重新核对函数入口、完整爆炸记录和队列余量。设置写入仍采用 compare/write/readback及失败回滚。
- 未可靠取得每发弹体的发射者，所以房主会处理它看见的所有该资源弹体，追加爆炸记在房主当前角色名下。死亡/复活后旧弹体不会被重新启用。
- 尚不能声称游戏中持续电弧已成功。本包静态验证和模拟测试通过，真实 GL-52 资源查询、落地判据及原生重复爆炸效果等待游戏测试。

## 离线验证

`Source/*-TESTS.json` 记录生产调度器、数据守卫/升级/回滚，以及原生接口适配器的模拟检查。Lua解析、ZIP完整性、内外源码一致性也在构建中检查。模拟不执行真实游戏 EXE。
