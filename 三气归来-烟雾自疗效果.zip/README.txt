Healing Smoke v1.0 BETA3

Experimental Helldivers 2 runtime addon.

What changed from BETA2:
- Keeps Smoke_Covered in StatusEffectTemplateType_Smoke.
- Adds Stim_Pistol_Heal to slot 1.
- ALSO sets no_susceptibility_required on Stim_Pistol_Heal at runtime.
- Finds the StatusEffectSettings flags field by a multi-record fingerprint rather than a hardcoded offset.

Requires Bingus Shared Loader v15+ / API 1.
Import ZIP into Arsenal/HD2MM, remove/disable BETA2, then Purge + Deploy.

Log:
%LOCALAPPDATA%\Hd2HealingSmoke\HealingSmoke.log

Expected successful BETA3 log lines:
StatusEffectSettings found: ... flags_off=0x...
APPLIED: Stim_Pistol_Heal 28 flags 0x0 -> 0x2 (no_susceptibility_required=1)

WARNING: Experimental. The status flag is global for Stim_Pistol_Heal while the mod is active.
Because Smoke is shared, any actor affected by that template may receive the heal, not only players.
