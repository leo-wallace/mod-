-- HD2-Addon: mods/heal/healing_smoke
-- Healing Smoke (BETA3)
--
-- Adds Stim_Pistol_Heal to the shared Smoke status-effect template while
-- preserving the normal Smoke_Covered effect. Any persistent volume that uses
-- StatusEffectTemplateType_Smoke will inherit the heal.
--
-- Target layout (generated_status_effect_settings.dl_bin, game data 1.007.100):
--   StatusEffectTemplate record = 40 bytes
--     u32 template_type @0
--     4x { u32 status_type, f32 value_per_second } @4..35
--     u8 needs_to_hit_valid_actor @36 (+3 padding)
--   Smoke template type 14 currently has:
--     slot0 Smoke_Covered (48), value 1.0
--     slots1..3 None (0)
--   This addon changes only slot1 -> Stim_Pistol_Heal (28), keeping slot0.
--
-- Runtime memory patch. Requires Bingus Shared Loader / LuaJIT FFI.
-- Fingerprint checks refuse to edit an unexpected future layout.

local state = rawget(_G, "HealingSmoke")
if state then return end

local REVISION = "healing-smoke-v1-beta3"
state = {
    revision = REVISION,
    frames = 0,
    applied = false,
    template_applied = false,
    flags_applied = false,
    status = "starting",
}
rawset(_G, "HealingSmoke", state)

-- ------------------------------------------------------------------ config --
local REC_SIZE          = 40
local SETTINGS_REC_SIZE = 152       -- StatusEffectSettings record, 1.007.100
local SETTINGS_COUNT    = 71        -- exported records in 1.007.100
local NO_SUSC_FLAG      = 2         -- bit 1: no_susceptibility_required
local TYPE_TEMPLATES    = 0xDE8193C0 -- DLHash("StatusEffectTemplates")
local SMOKE_TEMPLATE    = 14         -- StatusEffectTemplateType_Smoke
local SMOKE_COVERED     = 48         -- StatusEffectType_Smoke_Covered
local HEAL_STATUS       = 28         -- StatusEffectType_Stim_Pistol_Heal
local HEAL_RATE         = 1.0        -- value_per_second written into slot1

-- record offsets
local OFF_TYPE          = 0
local OFF_S0_TYPE       = 4
local OFF_S0_VAL        = 8
local OFF_S1_TYPE       = 12
local OFF_S1_VAL        = 16
local OFF_S2_TYPE       = 20
local OFF_S2_VAL        = 24
local OFF_S3_TYPE       = 28
local OFF_S3_VAL        = 32
local OFF_NEEDS_HIT     = 36

local VERIFY_EVERY      = 300
local SCAN_BUDGET       = 0.008
local CHUNK             = 262144
local OVERLAP           = 2048

local function read_overrides()
    local base = os.getenv("LOCALAPPDATA")
    if not base then return end
    local ok, f = pcall(io.open, base .. "/Hd2HealingSmoke/healing_smoke.cfg", "r")
    if not ok or not f then return end
    for line in f:lines() do
        local k, v = line:match("^%s*(%a+)%s*=%s*([%d%.]+)")
        if k == "rate" and v then
            local n = tonumber(v)
            if n and n >= 0 and n <= 100 then HEAL_RATE = n end
        end
    end
    f:close()
end

-- --------------------------------------------------------------------- ffi --
local ok_ffi, ffi = pcall(require, "ffi")
if not ok_ffi or not ffi then
    state.status = "no_ffi"
    print("[HealingSmoke] FFI unavailable")
    return
end

ffi.cdef [[
    void *GetCurrentProcess(void);
    int ReadProcessMemory(void *process, const void *address, void *buffer, size_t size, size_t *read);
    int WriteProcessMemory(void *process, void *address, const void *buffer, size_t size, size_t *written);
    int VirtualProtect(void *address, size_t size, uint32_t protection, uint32_t *previous);
    typedef struct {
        void *base; void *allocation_base; uint32_t allocation_protection;
        uint16_t partition; uint16_t reserved; size_t size;
        uint32_t state; uint32_t protection; uint32_t type;
    } HsMemRegion;
    size_t VirtualQuery(const void *address, void *region, size_t size);
    int CreateDirectoryA(const char *path, void *security);
    uint32_t GetLastError(void);
]]

local kernel = ffi.load("kernel32")
local process = kernel.GetCurrentProcess()

-- ------------------------------------------------------------------ logging --
local out_dir = nil
do
    local base = os.getenv("LOCALAPPDATA")
    if base then
        local candidate = base .. "/Hd2HealingSmoke"
        if kernel.CreateDirectoryA(candidate, nil) ~= 0 or kernel.GetLastError() == 183 then
            out_dir = candidate
        end
    end
end

local NL = string.char(10)
local log_started = false
local function log(line)
    print("[HealingSmoke] " .. line)
    if not out_dir then return end
    local mode = log_started and "a" or "w"
    log_started = true
    local ok, f = pcall(io.open, out_dir .. "/HealingSmoke.log", mode)
    if ok and f then
        pcall(f.write, f, line .. NL)
        pcall(f.close, f)
    end
end

-- ------------------------------------------------------------------ memory --
local scratch = ffi.new("uint8_t[1048576]")
local read_count = ffi.new("size_t[1]")
local written = ffi.new("size_t[1]")

local function read_at(address, size)
    if not address or size <= 0 or size > 1048576 then return nil end
    if kernel.ReadProcessMemory(process, ffi.cast("const void *", address), scratch, size, read_count) == 0 then return nil end
    if read_count[0] ~= size then return nil end
    return ffi.string(scratch, size)
end

local region = ffi.new("HsMemRegion[1]")
local region_size = ffi.sizeof(region[0])

local function region_info(address)
    if kernel.VirtualQuery(ffi.cast("const void *", address), ffi.cast("void *", region), region_size) ~= region_size then
        return nil
    end
    return {
        base = tonumber(ffi.cast("uintptr_t", region[0].base)),
        allocation_base = tonumber(ffi.cast("uintptr_t", region[0].allocation_base)),
        size = tonumber(region[0].size),
        state = tonumber(region[0].state),
        protection = tonumber(region[0].protection),
        type = tonumber(region[0].type),
    }
end

local function write_bytes(address, bytes)
    local n = #bytes
    local r = region_info(address)
    if not r or r.state ~= 4096 then return false end
    if r.type ~= 131072 and r.type ~= 262144 then return false end
    if not (r.base <= address and address + n <= r.base + r.size) then return false end

    local writable = (r.protection == 4 or r.protection == 8 or r.protection == 64 or r.protection == 128)
    if writable then
        if kernel.WriteProcessMemory(process, ffi.cast("void *", address), bytes, n, written) == 0 then return false end
        return written[0] == n
    end

    local previous = ffi.new("uint32_t[1]")
    if kernel.VirtualProtect(ffi.cast("void *", address), n, 4, previous) == 0 then return false end
    local ok = kernel.WriteProcessMemory(process, ffi.cast("void *", address), bytes, n, written) ~= 0
        and written[0] == n
    local discarded = ffi.new("uint32_t[1]")
    kernel.VirtualProtect(ffi.cast("void *", address), n, previous[0], discarded)
    return ok
end

local function u32_at(s, i)
    local a, b, c, d = s:byte(i, i + 3)
    if not d then return nil end
    return a + b * 256 + c * 65536 + d * 16777216
end

local function u64_at(s, i)
    local lo = u32_at(s, i)
    local hi = u32_at(s, i + 4)
    if not lo or not hi then return nil end
    return lo + hi * 4294967296
end

local u32_scratch = ffi.new("uint32_t[1]")
local f32_view = ffi.cast("float *", u32_scratch)

local function f32_at(s, i)
    local a, b, c, d = s:byte(i, i + 3)
    if not d then return nil end
    u32_scratch[0] = a + b * 256 + c * 65536 + d * 16777216
    return tonumber(f32_view[0])
end

local function put_u32(s, i, v)
    return s:sub(1, i - 1)
        .. string.char(v % 256, math.floor(v / 256) % 256,
            math.floor(v / 65536) % 256, math.floor(v / 16777216) % 256)
        .. s:sub(i + 4)
end

local function put_f32(s, i, v)
    u32_scratch[0] = 0
    f32_view[0] = v
    return put_u32(s, i, tonumber(u32_scratch[0]))
end

local function approx(a, b)
    return a and b and math.abs(a - b) < 0.0005
end

-- ------------------------------------------------------- locate the table ---
local SIGNATURE = string.char(0x4C, 0x44, 0x4C, 0x44, 1, 0, 0, 0,
    TYPE_TEMPLATES % 256, math.floor(TYPE_TEMPLATES / 256) % 256,
    math.floor(TYPE_TEMPLATES / 65536) % 256, math.floor(TYPE_TEMPLATES / 16777216) % 256)

local self_anchor = nil
do
    local ok, p = pcall(function()
        return tonumber(ffi.cast("uintptr_t", ffi.cast("const char *", SIGNATURE)))
    end)
    if ok and p and p > 0 then self_anchor = p end
end

local table_info = nil -- StatusEffectTemplates
local settings_info = nil -- StatusEffectSettings: {records,count,target,flags_offset,magic}
local status_scan_finished = false
local status_regions = nil
local status_region_index = 1
local status_region_offset = 0
local status_previous = ""

local function target_index_in_blob(blob, count)
    for i = 0, count - 1 do
        local p = i * REC_SIZE + 1
        if u32_at(blob, p + OFF_TYPE) == SMOKE_TEMPLATE then return i end
    end
    return nil
end

local function record_fingerprint(rec, allow_healed)
    if not rec or #rec ~= REC_SIZE then return false end
    if u32_at(rec, OFF_TYPE + 1) ~= SMOKE_TEMPLATE then return false end
    if u32_at(rec, OFF_S0_TYPE + 1) ~= SMOKE_COVERED then return false end
    if not approx(f32_at(rec, OFF_S0_VAL + 1), 1.0) then return false end

    local s1 = u32_at(rec, OFF_S1_TYPE + 1)
    if s1 ~= 0 and not (allow_healed and s1 == HEAL_STATUS) then return false end
    if u32_at(rec, OFF_S2_TYPE + 1) ~= 0 then return false end
    if u32_at(rec, OFF_S3_TYPE + 1) ~= 0 then return false end
    if rec:byte(OFF_NEEDS_HIT + 1) ~= 0 then return false end
    return true
end

local function try_records_base(magic_abs, count, records)
    if not records or records < 65536 or records >= 2 ^ 47 then return nil end
    local total = count * REC_SIZE
    if total <= 0 or total > 1048576 then return nil end
    local blob = read_at(records, total)
    if not blob or #blob ~= total then return nil end
    local idx = target_index_in_blob(blob, count)
    if idx == nil then return nil end
    local p = idx * REC_SIZE + 1
    local rec = blob:sub(p, p + REC_SIZE - 1)
    if not record_fingerprint(rec, true) then return nil end
    return { records = records, count = count, target = idx, magic = magic_abs }
end

local function probe_block(magic_abs)
    local hdr = read_at(magic_abs, 40)
    if not hdr or #hdr ~= 40 then return nil end
    if hdr:sub(1, 4) ~= "LDLD" then return nil end
    if u32_at(hdr, 5) ~= 1 or u32_at(hdr, 9) ~= TYPE_TEMPLATES then return nil end

    local declared_size = u32_at(hdr, 13)
    local count = u32_at(hdr, 33)
    if not count or count < 10 or count > 256 then return nil end
    if declared_size and declared_size ~= 0 and declared_size ~= 16 + count * REC_SIZE then
        -- Some loaders/builds expose a different bookkeeping size. Keep going,
        -- but only if the actual record fingerprint later validates perfectly.
    end

    local descriptor = u64_at(hdr, 25)
    local candidates = {}
    local seen = {}
    local function add(v)
        if v and v >= 65536 and v < 2 ^ 47 and not seen[v] then
            seen[v] = true
            candidates[#candidates + 1] = v
        end
    end

    -- Current DataLibrary dumps may store either an absolute pointer or a small
    -- relative offset in the descriptor. The fixed inline base is also tried.
    if descriptor then
        if descriptor < 1048576 then add(magic_abs + 24 + descriptor) end
        add(descriptor)
    end
    add(magic_abs + 40)

    for _, base in ipairs(candidates) do
        local info = try_records_base(magic_abs, count, base)
        if info then return info end
    end
    return nil
end

local region_list = nil
local region_index = 1
local region_offset = 0
local previous = ""
local scan_finished = false
local scanned_bytes = 0

local function is_readable(protection)
    return protection == 2 or protection == 4 or protection == 8
        or protection == 32 or protection == 64 or protection == 128
end

local function collect_regions()
    local list = {}
    local address = 65536
    while address < 2 ^ 47 do
        local r = region_info(address)
        if not r or not r.size or r.size <= 0 then break end
        if r.state == 4096 and is_readable(r.protection)
            and (r.type == 131072 or r.type == 262144) and r.size >= 65536 then
            if not (self_anchor and r.base <= self_anchor and self_anchor < r.base + r.size) then
                list[#list + 1] = { base = r.base, size = r.size, allocation_base = r.allocation_base }
            end
        end
        local next_address = r.base + r.size
        if next_address <= address then break end
        address = next_address
    end
    table.sort(list, function(a, b) return a.size > b.size end)
    return list
end

local function examine(window_base, window)
    local from = 1
    while true do
        local i = string.find(window, SIGNATURE, from, true)
        if not i then break end
        local abs = window_base + i - 1
        local skip = false
        if self_anchor then
            local d = abs - self_anchor
            if d > -4096 and d < 4096 then skip = true end
        end
        if not skip then
            local info = probe_block(abs)
            if info then
                table_info = info
                log(string.format("StatusEffectTemplates found: magic=0x%X records=0x%X count=%d smoke_record=%d",
                    info.magic, info.records, info.count, info.target))
                return true
            end
        end
        from = i + 1
    end
    return false
end

local function scan_step()
    if scan_finished or table_info then return end
    if not region_list then
        region_list = collect_regions()
        log("candidate regions=" .. tostring(#region_list))
        return
    end
    local deadline = os.clock() + SCAN_BUDGET
    while os.clock() < deadline do
        local r = region_list[region_index]
        if not r then
            scan_finished = true
            state.status = "table_not_found"
            log(string.format("scan finished without StatusEffectTemplates (%d MB searched)",
                math.floor(scanned_bytes / 1048576)))
            return
        end
        local remaining = r.size - region_offset
        if remaining <= 0 then
            region_index = region_index + 1
            region_offset = 0
            previous = ""
        else
            local want = CHUNK
            if want > remaining then want = remaining end
            local buf = read_at(r.base + region_offset, want)
            scanned_bytes = scanned_bytes + want
            if buf then
                local window_base = r.base + region_offset - #previous
                local window = previous .. buf
                if examine(window_base, window) then return end
                previous = buf:sub(-OVERLAP)
            else
                previous = ""
            end
            region_offset = region_offset + want
        end
    end
end

-- ------------------------------------------- locate StatusEffectSettings ---
-- BETA2 proved that adding status 28 to the Smoke template alone is not enough.
-- Current 1.007.100 data marks Smoke_Covered with no_susceptibility_required,
-- while Stim_Pistol_Heal does not have that bit.  BETA3 locates the 152-byte
-- StatusEffectSettings table in the SAME DataLibrary allocation and turns on
-- that one bit for status 28.  The flags offset is discovered from a multi-row
-- fingerprint instead of being hardcoded.

local EXPECTED_FLAGS = {
    [1] = 0,   -- Blind
    [2] = 3,   -- Bleed
    [8] = 8,   -- Slowed
    [28] = 0,  -- Stim_Pistol_Heal (stock)
    [47] = 3,  -- Flashlighted
    [48] = 2,  -- Smoke_Covered
    [49] = 2,  -- Backpack_Chemicals
    [50] = 2,  -- Intense_Heat
    [52] = 10, -- Tremor
    [53] = 2,  -- Sandstorm
    [54] = 2,  -- Blizzard
}

local function settings_type_map(blob, count)
    local map = {}
    for i = 0, count - 1 do
        local t = u32_at(blob, i * SETTINGS_REC_SIZE + 1)
        if t and t > 0 and t < 4096 and not map[t] then map[t] = i end
    end
    return map
end

local function discover_flags_offset(blob, map)
    local matches = {}
    for off = 4, SETTINGS_REC_SIZE - 4, 4 do
        local good = true
        for t, expected in pairs(EXPECTED_FLAGS) do
            local idx = map[t]
            if idx == nil then good = false break end
            local got = u32_at(blob, idx * SETTINGS_REC_SIZE + off + 1)
            if got ~= expected then good = false break end
        end
        if good then matches[#matches + 1] = off end
    end
    if #matches == 1 then return matches[1] end
    return nil
end

local function try_settings_records_base(magic_abs, count, records)
    if not records or records < 65536 or records >= 2 ^ 47 then return nil end
    if count ~= SETTINGS_COUNT then return nil end
    local total = count * SETTINGS_REC_SIZE
    if total <= 0 or total > 1048576 then return nil end
    local blob = read_at(records, total)
    if not blob or #blob ~= total then return nil end
    local map = settings_type_map(blob, count)
    -- Strong table identity fingerprint. These types must all exist.
    for _, t in ipairs({1,2,3,4,5,6,7,8,27,28,47,48,49,50,52,53,54}) do
        if map[t] == nil then return nil end
    end
    local flags_off = discover_flags_offset(blob, map)
    if not flags_off then return nil end
    return {
        records = records,
        count = count,
        target = map[HEAL_STATUS],
        flags_offset = flags_off,
        magic = magic_abs,
    }
end

local function probe_settings_block(magic_abs)
    local hdr = read_at(magic_abs, 40)
    if not hdr or #hdr ~= 40 then return nil end
    if hdr:sub(1, 4) ~= "LDLD" or u32_at(hdr, 5) ~= 1 then return nil end
    local count = u32_at(hdr, 33)
    if count ~= SETTINGS_COUNT then return nil end

    local descriptor = u64_at(hdr, 25)
    local candidates, seen = {}, {}
    local function add(v)
        if v and v >= 65536 and v < 2 ^ 47 and not seen[v] then
            seen[v] = true
            candidates[#candidates + 1] = v
        end
    end
    if descriptor then
        if descriptor < 1048576 then add(magic_abs + 24 + descriptor) end
        add(descriptor)
    end
    add(magic_abs + 40)

    for _, base in ipairs(candidates) do
        local info = try_settings_records_base(magic_abs, count, base)
        if info then return info end
    end
    return nil
end

local function prepare_status_regions()
    if status_regions or not table_info then return end
    status_regions = {}
    local tr = region_info(table_info.magic)
    local allocation = tr and tr.allocation_base or nil
    if allocation and region_list then
        for _, r in ipairs(region_list) do
            if r.allocation_base == allocation then
                status_regions[#status_regions + 1] = r
            end
        end
    end
    -- Defensive fallback: if allocation grouping is unavailable, search the
    -- already-collected readable regions. The table fingerprint is strict.
    if #status_regions == 0 and region_list then
        for _, r in ipairs(region_list) do status_regions[#status_regions + 1] = r end
    end
    table.sort(status_regions, function(a, b) return a.base < b.base end)
    log(string.format("StatusEffectSettings search regions=%d allocation=%s",
        #status_regions, allocation and string.format("0x%X", allocation) or "unknown"))
end

local function examine_status(window_base, window)
    local from = 1
    while true do
        local i = string.find(window, "LDLD", from, true)
        if not i then break end
        local abs = window_base + i - 1
        if not table_info or abs ~= table_info.magic then
            local info = probe_settings_block(abs)
            if info then
                settings_info = info
                log(string.format("StatusEffectSettings found: magic=0x%X records=0x%X count=%d heal_record=%d flags_off=0x%X",
                    info.magic, info.records, info.count, info.target, info.flags_offset))
                return true
            end
        end
        from = i + 1
    end
    return false
end

local function scan_status_step()
    if status_scan_finished or settings_info or not table_info then return end
    prepare_status_regions()
    local deadline = os.clock() + SCAN_BUDGET
    while os.clock() < deadline do
        local r = status_regions[status_region_index]
        if not r then
            status_scan_finished = true
            state.status = "status_settings_not_found"
            log("StatusEffectSettings scan finished without a validated table")
            return
        end
        local remaining = r.size - status_region_offset
        if remaining <= 0 then
            status_region_index = status_region_index + 1
            status_region_offset = 0
            status_previous = ""
        else
            local want = CHUNK
            if want > remaining then want = remaining end
            local buf = read_at(r.base + status_region_offset, want)
            if buf then
                local window_base = r.base + status_region_offset - #status_previous
                local window = status_previous .. buf
                if examine_status(window_base, window) then return end
                status_previous = buf:sub(-OVERLAP)
            else
                status_previous = ""
            end
            status_region_offset = status_region_offset + want
        end
    end
end

local function heal_flags_address()
    if not settings_info then return nil end
    return settings_info.records
        + settings_info.target * SETTINGS_REC_SIZE
        + settings_info.flags_offset
end

local function heal_flags_ok()
    local address = heal_flags_address()
    if not address then return false end
    local rec = read_at(settings_info.records + settings_info.target * SETTINGS_REC_SIZE, SETTINGS_REC_SIZE)
    if not rec or #rec ~= SETTINGS_REC_SIZE then return false end
    if u32_at(rec, 1) ~= HEAL_STATUS then return false end
    local flags = u32_at(rec, settings_info.flags_offset + 1)
    if not flags then return false end
    return math.floor(flags / NO_SUSC_FLAG) % 2 == 1
end

local function apply_heal_flags()
    if not settings_info then return end
    local rec_addr = settings_info.records + settings_info.target * SETTINGS_REC_SIZE
    local rec = read_at(rec_addr, SETTINGS_REC_SIZE)
    if not rec or #rec ~= SETTINGS_REC_SIZE or u32_at(rec, 1) ~= HEAL_STATUS then
        state.status = "heal_record_read_failed"
        return
    end
    local off = settings_info.flags_offset
    local old = u32_at(rec, off + 1)
    if not old or old > 255 then
        state.status = "heal_flags_fingerprint_mismatch"
        log("refusing flags edit: unexpected Stim_Pistol_Heal flags " .. tostring(old))
        return
    end
    if math.floor(old / NO_SUSC_FLAG) % 2 == 1 then
        state.flags_applied = true
        return
    end
    local new = old + NO_SUSC_FLAG
    local bytes = string.char(new % 256, math.floor(new / 256) % 256,
        math.floor(new / 65536) % 256, math.floor(new / 16777216) % 256)
    local address = rec_addr + off
    if not write_bytes(address, bytes) then
        state.status = "heal_flags_write_failed"
        log(string.format("write Stim_Pistol_Heal flags at 0x%X failed", address))
        return
    end
    local check = read_at(address, 4)
    local got = check and u32_at(check, 1) or nil
    if got == new then
        state.flags_applied = true
        log(string.format("APPLIED: Stim_Pistol_Heal %d flags 0x%X -> 0x%X (no_susceptibility_required=1)",
            HEAL_STATUS, old, new))
    else
        state.status = "heal_flags_verify_failed"
        log("Stim_Pistol_Heal flags write verification failed")
    end
end

-- ------------------------------------------------------------------ apply ---
local function smoke_record()
    if not table_info then return nil, nil end
    local address = table_info.records + table_info.target * REC_SIZE
    local rec = read_at(address, REC_SIZE)
    if not rec or #rec ~= REC_SIZE then return nil, nil end
    return address, rec
end

local function build_payload(rec)
    local out = rec
    out = put_u32(out, OFF_S1_TYPE + 1, HEAL_STATUS)
    out = put_f32(out, OFF_S1_VAL + 1, HEAL_RATE)
    return out
end

local function apply_template()
    if not table_info then return end
    local address, rec = smoke_record()
    if not rec then
        state.status = "record_read_failed"
        return
    end

    if not record_fingerprint(rec, true) then
        state.status = "fingerprint_mismatch"
        log(string.format("refusing edit: Smoke template fingerprint changed at 0x%X", address))
        return
    end

    local s1 = u32_at(rec, OFF_S1_TYPE + 1)
    local v1 = f32_at(rec, OFF_S1_VAL + 1)
    if s1 == HEAL_STATUS and approx(v1, HEAL_RATE) then
        state.template_applied = true
        state.status = "template_already_applied"
        return
    end
    if s1 ~= 0 and s1 ~= HEAL_STATUS then
        state.status = "slot1_occupied"
        log("refusing edit: Smoke template slot1 is already used by status " .. tostring(s1))
        return
    end

    local payload = build_payload(rec)
    if #payload ~= REC_SIZE then
        state.status = "payload_size_error"
        return
    end
    if not write_bytes(address, payload) then
        state.status = "write_failed"
        log(string.format("write to 0x%X failed", address))
        return
    end

    local check = read_at(address, REC_SIZE)
    if check and check == payload then
        state.template_applied = true
        state.status = "template_applied"
        log(string.format("APPLIED: Smoke template %d keeps Smoke_Covered %d and adds Stim_Pistol_Heal %d rate %.3f",
            SMOKE_TEMPLATE, SMOKE_COVERED, HEAL_STATUS, HEAL_RATE))
        log(string.format("  record=0x%X slot1 %d/%.3f -> %d/%.3f",
            address, s1 or -1, v1 or 0, HEAL_STATUS, HEAL_RATE))
    else
        state.status = "verify_failed"
        log("write verification failed")
    end
end

local function apply()
    if not state.template_applied then apply_template() end
    if settings_info and not state.flags_applied then apply_heal_flags() end
    state.applied = state.template_applied and state.flags_applied
    if state.applied then
        state.status = "ready"
    end
end

local function reset_scan(reason)
    table_info = nil
    settings_info = nil
    status_scan_finished = false
    status_regions = nil
    status_region_index = 1
    status_region_offset = 0
    status_previous = ""
    region_list = nil
    region_index = 1
    region_offset = 0
    previous = ""
    scan_finished = false
    scanned_bytes = 0
    state.applied = false
    state.template_applied = false
    state.flags_applied = false
    state.status = "rescanning"
    if reason then log(reason .. "; rescanning") end
end

local function verify()
    if not state.applied then return end
    local _, rec = smoke_record()
    if not rec then
        reset_scan("Smoke template memory moved")
        return
    end
    if not record_fingerprint(rec, true) then
        reset_scan("Smoke template fingerprint changed")
        return
    end
    local s1 = u32_at(rec, OFF_S1_TYPE + 1)
    local v1 = f32_at(rec, OFF_S1_VAL + 1)
    if s1 ~= HEAL_STATUS or not approx(v1, HEAL_RATE) then
        log("Smoke template reverted (map/load transition?); re-applying")
        state.template_applied = false
        state.applied = false
        apply()
        return
    end
    if not heal_flags_ok() then
        log("Stim_Pistol_Heal susceptibility flag reverted/moved; re-applying")
        state.flags_applied = false
        state.applied = false
        apply_heal_flags()
        state.applied = state.template_applied and state.flags_applied
    end
end

-- ------------------------------------------------------------------ drive ---
local original_update = update
if type(original_update) == "function" then
    function update(...)
        state.frames = state.frames + 1
        if state.frames >= 120 then
            if not table_info and not scan_finished then
                if (state.frames % 2) == 0 then
                    local ok, err = pcall(scan_step)
                    if not ok then
                        scan_finished = true
                        state.status = "scan_error"
                        log("scan error: " .. tostring(err))
                    end
                end
            elseif table_info then
                if not state.template_applied then
                    local ok, err = pcall(apply_template)
                    if not ok then
                        state.status = "template_apply_error"
                        log("template apply error: " .. tostring(err))
                    end
                end
                if not settings_info and not status_scan_finished then
                    local ok, err = pcall(scan_status_step)
                    if not ok then
                        status_scan_finished = true
                        state.status = "status_scan_error"
                        log("StatusEffectSettings scan error: " .. tostring(err))
                    end
                elseif settings_info and not state.flags_applied then
                    local ok, err = pcall(apply_heal_flags)
                    if not ok then
                        state.status = "flags_apply_error"
                        log("flags apply error: " .. tostring(err))
                    end
                end
                state.applied = state.template_applied and state.flags_applied
                if state.applied then state.status = "ready" end
                if state.applied and (state.frames % VERIFY_EVERY) == 0 then
                    pcall(verify)
                end
            end
        end
        return original_update(...)
    end

    read_overrides()
    log(string.format("%s loaded; Smoke template=%d add status=%d rate=%.3f + no_susceptibility patch",
        REVISION, SMOKE_TEMPLATE, HEAL_STATUS, HEAL_RATE))
    state.status = "hooked"
else
    state.status = "no_update"
    log("global update unavailable")
end

return { revision = REVISION, state = state }
