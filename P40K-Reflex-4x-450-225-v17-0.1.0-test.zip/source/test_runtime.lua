local function fixture(which, mode)
    local lib=dofile('bolt_scope_010/source/test_spec.lua')
    local s=lib.SPEC.components[which]
    s.game=0x10000000;s.owner_rva=lib.SPEC.owner_rva
    local owner,tab=0x20000000,0x30000000
    local row=s.direct and tab or tab+#s.hashmap+s.record_index*s.record_size
    local slot,data=tab,s.original
    local allowed,expected={},s.original
    for _,e in ipairs(s.edits)do
        allowed[row+e.offset]=#e.replacement
        expected=expected:sub(1,e.offset)..e.replacement..expected:sub(e.offset+#e.replacement+1)
    end
    if mode=='conflict' then data=data:sub(1,4)..'\255'..data:sub(6)end
    if mode=='preexisting' then data=expected end
    local writes,logs={},{}
    local fail=mode=='partial'
    local api={}
    function api.pointer(bytes)if bytes then return string.unpack('<I8',bytes)end end
    function api.read(at,n)
        if not s.direct and at==s.game+s.owner_rva and n==8 then return string.pack('<I8',owner)end
        if at==(s.direct and s.game or owner)+s.candidate_slot and n==8 then return string.pack('<I8',slot)end
        if s.direct then
            for i,g in ipairs(s.guards)do
                if at==tab+g.offset and n==#g.bytes then
                    if mode=='guard_mismatch' and i==1 then return '\255'..g.bytes:sub(2)end
                    return g.bytes
                end
            end
        elseif at>=tab and at+n<=tab+#s.hashmap then
            local bytes=s.hashmap:sub(at-tab+1,at-tab+n)
            if mode=='guard_mismatch' and at==tab then bytes='\255'..bytes:sub(2)end
            return bytes
        end
        if at>=row and at+n<=row+#data then return data:sub(at-row+1,at-row+n)end
    end
    function api.write(at,bytes)
        assert(allowed[at]==#bytes,'unexpected address or write size')
        writes[#writes+1]={at=at,bytes=bytes}
        local off=at-row
        if fail then
            fail=false
            local count=math.floor(#bytes/2)
            data=data:sub(1,off)..bytes:sub(1,count)..data:sub(off+count+1)
            return false
        end
        data=data:sub(1,off)..bytes..data:sub(off+#bytes+1);return true
    end
    return {core=lib.Core.new(api,function(s)logs[#logs+1]=s end,s),spec=s,
        data=function()return data end,expected=expected,writes=writes,logs=logs,
        relocate=function()slot=0x50000000 end}
end

for which=1,2 do
    local f=fixture(which);f.core.step()
    assert(f.core.lease and not f.core.disabled and f.data()==f.expected and #f.writes==1)
    if which==1 then
        local a,b,c=string.unpack('<fff',f.data(),117)
        assert(a==4 and b==4 and c==4)
        assert(f.data():sub(1,116)==f.spec.original:sub(1,116))
        assert(f.data():sub(129)==f.spec.original:sub(129))
        print('PASS all three AimZoom floats are 4; all other WeaponData bytes unchanged')
    else
        assert(string.unpack('<I4',f.data())==156)
        assert(string.unpack('<i4',f.data(),5)==450 and string.unpack('<i4',f.data(),9)==225)
        assert(f.data():sub(1,4)==f.spec.original:sub(1,4))
        assert(f.data():sub(13)==f.spec.original:sub(13))
        print('PASS direct damage156 is 450/225; AP, force, demolition and status bytes unchanged')
    end
    f.core.step();assert(#f.writes==1)
    assert(f.core.stop() and f.data()==f.spec.original and #f.writes==2)
    assert(f.core.stop() and #f.writes==2)
    local bad=fixture(which,'conflict');bad.core.step();assert(bad.core.disabled and #bad.writes==0)
    local pre=fixture(which,'preexisting');pre.core.step();assert(pre.core.disabled and #pre.writes==0)
    local guard=fixture(which,'guard_mismatch');guard.core.step()
    assert(not guard.core.lease and #guard.writes==0)
    for i=1,30 do guard.core.step()end
    assert(guard.core.disabled and #guard.writes==0)
    local stale=fixture(which);stale.core.step();stale.relocate();stale.core.step()
    assert(stale.core.disabled and not stale.core.stop() and #stale.writes==1)
    local partial=fixture(which,'partial');partial.core.step()
    assert(partial.core.disabled and partial.data()==partial.spec.original and not partial.core.lease)
end
print('PASS idempotence, owned rollback, conflicts, neighbour/map guards, timeout, stale pointers and partial writes')
