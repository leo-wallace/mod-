local function scenario(mode)
    local env=setmetatable({}, {__index=_G});env._G=env
    local logs,cores={},{}
    local now,forwarded=100,0
    env.SPEC={module_sha256='expected',owner_rva=123,components={{label='Scope'},{label='Damage'}}}
    env.print=function()end
    env.CowboyBingusModLoader={api=1,open_log=function(name)
        assert(name=='P40KScope4x.log')
        return {write=function(_,s)logs[#logs+1]=s;return true end,flush=function()return true end,close=function()end}
    end}
    env.WindowsRead=function()return {module=function()return 0x10000000 end,
        module_hash=function()return mode=='bad_hash' and 'wrong' or 'expected'end,
        time=function()return now end,read=function()return nil end}end
    env.WindowsWrite=function()return function()error('unexpected OS write')end end
    env.Core={new=function(_,_,s)
        local c={steps=0,stops=0}
        c.step=function()
            c.steps=c.steps+1
            if mode=='damage_fail' and s.label=='Damage' then c.disabled=true;c.status='mismatch';return end
            if mode=='throws' and s.label=='Damage' then error('simulated failure')end
            if c.steps>=2 then c.lease={}end
        end
        c.stop=function()c.stops=c.stops+1 end
        cores[#cores+1]=c;return c
    end}
    env.update=function(...)forwarded=forwarded+1;return select('#',...),... end
    env.shutdown=function(...)return select('#',...),... end
    local f=assert(io.open('bolt_scope_010/source/boot.lua'));local source=f:read('*a');f:close()
    local m=assert(load(source,'@boot','t',env))()
    if mode=='bad_hash' then assert(m.disabled and #cores==0);return end
    assert(env.update()==0)
    assert(cores[1].steps==1 and cores[2].steps==1)
    if mode=='damage_fail' or mode=='throws' then
        assert(m.disabled and cores[1].stops==1 and cores[2].stops==1)
        assert(not table.concat(logs):find('APPLIED_READBACK_OK',1,true));return
    end
    assert(not table.concat(logs):find('APPLIED_READBACK_OK',1,true))
    now=now+2.1
    local n,a,b=env.update('ctx',nil)
    assert(n==2 and a=='ctx' and b==nil and forwarded==2 and cores[1].steps==2 and cores[2].steps==2)
    assert(table.concat(logs):find('APPLIED_READBACK_OK',1,true))
    assert(table.concat(logs):find('normal=450 durable=225',1,true))
    assert(table.concat(logs):find('aim_zoom=4/4/4',1,true))
    local count,value,empty=env.shutdown('ctx',nil)
    assert(count==2 and value=='ctx' and empty==nil and m.disabled)
    assert(cores[1].stops==1 and cores[2].stops==1)
end
scenario('normal');scenario('bad_hash');scenario('damage_fail');scenario('throws')
print('PASS API1 no-dt update retry, full varargs, successful-readback reporting, bad build refusal and group rollback')
