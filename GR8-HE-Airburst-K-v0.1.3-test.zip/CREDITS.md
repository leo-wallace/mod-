# Credits

Uses code / research from HD2Runtime by SkyeShade.
https://github.com/SkyeShade/HD2Runtime

Selected findings used: resource identities; ProjectileWeapon table layout and native fingerprints; player/inventory and private-copy layouts; package loader/residency layout and its proven calling convention; engine GUI call forms. This release is an independently assembled BSL addon and does not bundle the HD2Runtime runtime or SDK. HD2Runtime's license continues to cover the reused findings; see Source/third_party/LICENSE-HD2Runtime.txt.

The guarded read-only native reader in Source/src/vendor/native_hud.lua is adapted from DRIVER HUD 1.3.5 / 1.4.5 by FireScallion, MIT. See Source/third_party/LICENSE-DRIVER-HUD.txt.

User-provided Gubs Recoilless Rifle Fatman MIRV Conversion 1.0.0 supplied the reference approach for reading the native programmable-ammo selector. JAR-5 Dominator Rechambered 3.3.5 supplied a reference for standalone BSL projectile-reference editing. Their installed mod files are not redistributed here.

This is an unofficial fan-made test modification, not an Arrowhead or Sony release.
