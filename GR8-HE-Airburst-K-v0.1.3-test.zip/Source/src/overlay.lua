-- Optional simple label; the native reload menu retains its original HE label.
-- Engine GUI call forms researched by HD2Runtime by SkyeShade.
return function()
local M={};local world,gui,id,last
local FONT='core/performance_hud/monaco'
local function alive(S,w)
 for _,v in ipairs(S.Application.worlds()or{})do if v==w then return true end end
 return false
end
function M.close()
 local S=rawget(_G,'stingray')
 if gui and S and alive(S,world)then S.World.destroy_gui(world,gui)end
 world,gui,id,last=nil,nil,nil,nil
end
function M.show(text)
 local S=rawget(_G,'stingray');if not S then return end
 if not text then M.close();return end
 local w=S.Application.main_world()
 if w==nil or not alive(S,w)then return end
 if world and world~=w then M.close()end
 if not gui then world=w;gui=S.World.create_screen_gui(w,'scale',1,1)end
 if not gui or text==last then return end
 local pos=S.Vector3(30,155,950);local color=S.Color(255,255,230,150)
 if id and S.Gui.update_text then S.Gui.update_text(gui,id,text,FONT,18,FONT,pos,color)
 else
  if id then M.close();world=w;gui=S.World.create_screen_gui(w,'scale',1,1)end
  id=S.Gui.text(gui,text,FONT,18,FONT,pos,color)
 end
 last=text
end
return M
end
