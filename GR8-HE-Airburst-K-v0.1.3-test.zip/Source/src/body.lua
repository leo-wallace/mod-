-- HD2-Addon entry, Bingus Shared Loader; no HD2Runtime import.
local INSTALL='LeoWallace_GR8Airburst_V013'
if rawget(_G,INSTALL)then return rawget(_G,INSTALL)end
if rawget(_G,'jit')then jit.off(true,true)end
local C=Controller.new()
local S={clock=0,next=0,nextAsset=0,version='0.1.3-test',mode='Flak'}
local path=(os.getenv('LOCALAPPDATA')or''):gsub('\\','/')..'/CowboyBingus/Helldivers2/Logs/GR8Airburst.log'
local seen={}
local function log(msg)
 local f=io.open(path,'a');if f then f:write(os.date('%H:%M:%S '),msg,'\n');f:close()end
 if type(print)=='function'then print('[GR8Airburst] '..msg)end
end
local function once(msg)if not seen[msg]then seen[msg]=true;log(msg)end end
local W,B,A,P
local HUD=Overlay()
local hudFailed=false
local function label(s)
 if hudFailed then return end
 local ok,why=pcall(HUD.show,s)
 if not ok then hudFailed=true;pcall(HUD.close);log('optional HUD disabled: '..tostring(why))end
end
local function tick(dt)
 S.clock=S.clock+dt
 if not N.ensure(S.clock)then once('waiting: '..tostring(N.reason));return end
 once('native reader ready: '..tostring(N.reason))
 if not W then W=Windows(N,log);B=Native(N,Facts);B.prove();A=Assets(N,Facts,W,B);P=Patcher(N,W);log('equipment and selector code guards passed')end
 -- If a proof failed above, no memory operation is attempted on later ticks.
 if not B.proven or not A or not P then return end
 local down,focused,modifiers=W.keys()
 local proposed=Controller.step(C,down,focused,not modifiers)
 local press=proposed~=C.mode
 if not press and S.clock<S.next then return end
 S.next=S.clock+0.1
 local g=N.sample_graph()
 local h,heldReason=B.held(g)
 if not h then once('waiting for weapon: '..tostring(heldReason));label(nil);S.nextAsset=0;return end
 once('local GR8 identified; native HE='..tostring(h.he))
 if S.clock>=S.nextAsset then
  S.nextAsset=S.clock+1
  A.ready=false
  local ok,why=pcall(A.poll)
  if not ok then once('assets: '..tostring(why))end
 end
 if not A.ready then once('waiting for airburst package residency; requested='..tostring(A.requested));label('GR-8: waiting for airburst assets');return end
 -- Resample identities after the resource request and its asynchronous loading.
 g=N.sample_graph();h,heldReason=B.held(g)
 if not h then once('equipment changed after asset poll: '..tostring(heldReason));label(nil);return end
 local nextMode=(press and h.he and focused and not modifiers)and proposed or C.mode
 local t=B.templates(g)
 P.apply(g,t,h,nextMode)
 if not S.active then S.active=true;log('active: HE -> '..(nextMode==1 and'Flak (312)'or'Cluster (96)')..'; HEAT unchanged (153)')end
 if nextMode~=C.mode then log('HE submode -> '..(nextMode==1 and'Flak (312)'or'Cluster (96)'))end
 C.mode=nextMode;S.mode=nextMode==1 and'Flak'or'Cluster'
 S.nativeMode=h.he and'HE'or'HEAT'
 label(h.he and('GR-8 HE: '..S.mode..'  [K]')or('GR-8 HEAT  |  HE preset: '..S.mode))
end
local previous=rawget(_G,'update')
assert(type(previous)=='function','Bingus Shared Loader update hook unavailable')
rawset(_G,'update',function(...)
 local first,second=...
 once('update hook entered: argc='..select('#',...)..'; first='..type(first)..'; second='..type(second))
 -- BSL/mod wrappers do not all use update(dt): some forward context,dt or no dt.
 -- Keep the original argument list untouched; use a nominal frame step only when absent.
 local dt=1/60
 if type(first)=='number'and first>0 and first<1 then dt=first
 elseif type(second)=='number'and second>0 and second<1 then dt=second end
 local ok,why=pcall(tick,dt)
 if not ok then once('paused: '..tostring(why));label('GR-8 mod paused - see GR8Airburst.log')end
 return previous(...)
end)
rawset(_G,INSTALL,S)
log('GR8 Airburst 0.1.3 TEST loaded; read-only/write-copy data support + precise write diagnostics; no HD2Runtime dependency')
log('Uses code / research from HD2Runtime by SkyeShade https://github.com/SkyeShade/HD2Runtime')
return S
