-- Pure input state. Native HEAT/HE is an input, never an output.
local M={}
function M.new() return {mode=1,down=true,focused=false} end
function M.step(s,down,focused,eligible)
    local edge=down and not s.down and focused and s.focused
    s.down=down;s.focused=focused
    if edge and eligible then return 3-s.mode end
    return s.mode
end
return M
