return function(N,D)
local M={GR8='9f80d67a12a7e40f',RL77='26e40437ea275296'}
local u32,ptr=N.u32,N.ptr
local function unhex(s)return (s:gsub('..',function(h)return string.char(tonumber(h,16))end))end
M.unhex=unhex
local function p(g,a)return ptr(g:watch(a,8),0)end
local function guard(g,rva,hex)assert(g:read(N.base+rva,#hex/2)==unhex(hex),'layout guard '..string.format('%X',rva))end
function M.prove()
 local g=N.sample_graph()
 for _,v in ipairs(D.pins)do guard(g,v.rva,v.hex)end
 for _,v in ipairs(D.wielderPins)do guard(g,v.rva,v.hex)end
 guard(g,0x1787515,'4c8b1dc4f7b901')
 guard(g,0x755EF8,'488b43604b8d0c498b448804c1e802')
 M.proven=true
end
function M.record(g,root,resource)
 local tab=p(g,root+0xF12E80)
 assert(tab~=0,'ProjectileWeapon types unavailable')
 local first=N.mod64hex(resource,542)
 for i=0,541 do
  local raw=g:watch(tab+((first+i)%542)*16,16)
  local key=N.hex64(raw,0)
  if key==resource then
   local j=u32(raw,8)
   assert(u32(raw,12)==0 and j<542,'ProjectileWeapon type index')
   return tab+0x21E0+j*616,tab
  end
  if key=='0000000000000000'then break end
 end
 error('ProjectileWeapon resource not found: '..resource,0)
end
function M.templates(g)
 local root=g:root('network')
 local rr,tab=M.record(g,root,M.GR8)
 local ab=M.record(g,root,M.RL77)
 assert(u32(g:watch(rr,4),0)==153,'GR8 HEAT changed by another mod/build')
 assert(u32(g:watch(ab,4),0)==312 and u32(g:watch(ab+576,4),0)==96,'RL77 donor changed by another mod/build')
 return {at=rr+576,table=tab,root=root,raw=g:read(rr+576,4)}
end
function M.held(g)
 local state=D.state
 local game=p(g,N.base+state.game)
 if game==0 or u32(g:watch(game+state.state,4),0)~=state.mission then return nil,'not in mission'end
 local P,A,I=D.players,D.avatars,D.inventory
 local user=p(g,N.base+P.localUser)
 if user==0 then return nil,'no local user'end
 local peer=g:watch(user+P.localPeer,8)
 local mgr=p(g,N.base+P.global)
 if mgr==0 then return nil,'players unavailable'end
 local count=u32(g:watch(mgr+P.count,4),0)
 assert(count<=4,'player count')
 local slot
 for i=0,count-1 do
  if g:watch(mgr+P.peers+i*P.peerStride,8)==peer then
   assert(slot==nil,'ambiguous local peer');slot=i
  end
 end
 if slot==nil then return nil,'local peer not found'end
 local goid=u32(g:watch(mgr+A.avatarId+slot*A.avatarIdStride,4),0)
 local root=g:root('network')
 local player=g:net(root,goid,false)
 if not player then return nil,'no local avatar'end
 g:roundtrip(root,player)
 local hm=g:root('health')
 local hi,owner=g:component(hm,player.entity,0x1030,0x1048)
 if hi==nil or not N.same(owner,player)then return nil,'avatar health unavailable'end
 local hp=p(g,hm+0x1058)+hi*0x1B8
 if N.i32(g:watch(hp+0x14,4),0)<=0 or u32(g:watch(hp+0x19C,4),0)>=2 then return nil,'avatar dead'end
 local inv=p(g,N.base+I.global)
 local idx,own=g:component(inv,player.entity,I.hash,I.descriptors)
 if idx==nil or not N.same(own,player)then return nil,'inventory unavailable'end
 local record=p(g,inv+I.records)+idx*I.stride
 -- Inventory +0x10 is the carried-item slot, not the weapon currently wielded.
 local WI=D.wielder
 local wielder=p(g,N.base+WI.wielder)
 if wielder==0 then return nil,'wielder unavailable'end
 local wieldIndex=g:lookup(g:table(wielder+WI.wielderHash),player.entity)
 if wieldIndex==nil then return nil,'local avatar has no wielder instance'end
 local slots=p(g,wielder+WI.slots)
 local held=u32(g:watch(slots+wieldIndex*WI.stride,4),0)
 if held==0 or held==player.entity then return nil,'nothing wielded'end
 if held~=u32(g:watch(record+I.slots.support,4),0)then return nil,'support weapon not wielded'end
 local weapon=g:net(root,held,true)
 if not weapon or weapon.resource~=M.GR8 then return nil,'wielded entity is not GR8'end
 g:roundtrip(root,weapon)
 local wm=p(g,N.base+0x3326CE0)
 local wi=g:lookup(g:table(wm+0x30),held)
 if wi==nil then return nil,'native mode unavailable'end
 local bindings=g:watch(p(g,wm+0x58)+wi*0x3F0+0x350,16)
 local programmable=false
 for i=0,3 do if u32(bindings,i*4)==8 then programmable=true end end
 assert(programmable,'native HE selector missing')
 local modeAt=p(g,wm+0x60)+wi*12+4
 local modeWord=u32(g:watch(modeAt,4),0)
 local out={weapon=weapon,player=player,he=math.floor(modeWord/4)%4==1,modeAt=modeAt}
 -- Existing engine-owned private copies must be updated as well as the template.
 -- No native copy allocator is called and no instance is fabricated.
 local PW=D.pw
 local pw=p(g,N.base+PW.global)
 local ci=g:lookup(g:table(pw+PW.copies),held)
 if ci~=nil then
  local n=u32(g:watch(pw+PW.copyCount,4),0)
  assert(ci<n and n<1048576,'private ProjectileWeapon copy index')
  local copy=p(g,pw+PW.copyRecords)+ci*PW.copyStride
  assert(u32(g:watch(copy,4),0)==153,'private GR8 HEAT modified')
  out.copy={at=copy+576,raw=g:read(copy+576,4),entity=held,goid=weapon.goid,unit=weapon.unit}
 end
 return out
end
return M
end
