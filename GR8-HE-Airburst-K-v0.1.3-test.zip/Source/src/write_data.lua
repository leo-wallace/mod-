-- Four-byte configuration writes through an injectable Win32 backend.
-- Accept only committed non-executable private/mapped data; restore any temporary protection.
return function(B)
local M={};local reported={}
local function hex(s)
 if type(s)~='string'then return 'unreadable'end
 return (s:gsub('.',function(c)return string.format('%02X',c:byte())end))
end
function M.write4(at,old,new)
 assert(type(old)=='string'and#old==4 and type(new)=='string'and#new==4,'write width')
 local prefix=string.format('at=0x%X',at)
 local function fail(step,extra)return false,prefix..' step='..step..' '..tostring(extra or'')end
 if M.disabled then return fail('disabled',M.disabled)end
 if at%4~=0 then return fail('alignment')end
 local before=B.read(at,4)
 if before~=old then return fail('compare-before','expected='..hex(old)..' actual='..hex(before))end
 if old==new then return true end
 local r,why=B.query(at)
 if not r then return fail('query',why)end
 prefix=prefix..string.format(' protection=0x%X type=0x%X',r.protection,r.kind)
 if r.state~=4096 or (r.kind~=0x20000 and r.kind~=0x40000)
  or (r.protection~=2 and r.protection~=4 and r.protection~=8)
  or r.base>at or at+4>r.base+r.size then return fail('region-refused')end
 local previous
 if r.protection==2 then
  previous,why=B.protect(at,4,4)
  if not previous then return fail('make-writable',why)end
 end
 -- Nothing between protection elevation and restoration may escape with a Lua exception.
 local ok,result,detail=pcall(function()
  if previous and previous~=r.protection then return false,'protection changed before write'end
  local fresh=B.read(at,4)
  if fresh~=old then return false,'compare-after-protect expected='..hex(old)..' actual='..hex(fresh)end
  local written,error=B.write(at,new)
  if not written then return false,'WriteProcessMemory '..tostring(error)end
  local after=B.read(at,4)
  if after~=new then return false,'readback expected='..hex(new)..' actual='..hex(after)end
  return true
 end)
 if previous then
  local restored,back,restoreWhy=pcall(B.protect,at,4,previous)
  if not restored or not back then
   M.disabled='restore protection failed: '..tostring(restoreWhy or back)
   return fail('restore-protection',M.disabled)
  end
 end
 if not ok then return fail('write-exception',result)end
 if not result then return fail('write-or-verify',detail)end
 if B.log and not reported[at]then
  reported[at]=true
  pcall(B.log,'configuration write verified: '..prefix..' '..hex(old)..' -> '..hex(new)
   ..(previous and'; original protection restored'or''))
 end
 return true
end
return M
end
