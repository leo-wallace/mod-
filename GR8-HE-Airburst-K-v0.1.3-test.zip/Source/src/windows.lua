return function(N,log)
local ffi=require('ffi')
for _,decl in ipairs({
 'void * __stdcall GetProcAddress(void *, const char *);',
 'int __stdcall WriteProcessMemory(void *, void *, const void *, size_t, size_t *);'
})do pcall(ffi.cdef,decl)end
local k=ffi.load('kernel32');local u=k.GetModuleHandleA('user32.dll')
local function proc(module,name,sig)local a=k.GetProcAddress(module,name);assert(a~=nil,name);return ffi.cast(sig,a)end
local down=proc(u,'GetAsyncKeyState','int16_t (*)(int)')
local foreground=proc(u,'GetForegroundWindow','void *(*)(void)')
local owner=proc(u,'GetWindowThreadProcessId','uint32_t (*)(void *, uint32_t *)')
local pid=proc(k.GetModuleHandleA('kernel32.dll'),'GetCurrentProcessId','uint32_t (*)(void)')()
local pidbuf=ffi.new('uint32_t[1]');local mbi=ffi.new('uint8_t[48]');local written=ffi.new('size_t[1]')
local value=ffi.new('uint32_t[1]');local process=k.GetCurrentProcess()
local requestType=ffi.typeof('void (*)(void *, const uint64_t *, uint32_t)')
local ids=ffi.new('uint64_t[1]')
local protect=proc(k.GetModuleHandleA('kernel32.dll'),'VirtualProtect','int (*)(void *, size_t, uint32_t, uint32_t *)')
local lastError=proc(k.GetModuleHandleA('kernel32.dll'),'GetLastError','uint32_t (*)(void)')
local oldProtection=ffi.new('uint32_t[1]')
local M={exe=tonumber(ffi.cast('uintptr_t',k.GetModuleHandleA(nil)))}
function M.keys()
 local w=foreground();pidbuf[0]=0
 if w~=nil then owner(w,pidbuf)end
 return down(0x4B)<0,pidbuf[0]==pid,
  down(0x11)<0 or down(0x10)<0 or down(0x12)<0 or down(0x0D)<0 or down(0x1B)<0
end
function M.bytes(n)value[0]=n;return ffi.string(value,4)end
local writer=DataWriter({read=N.win.read,log=log,
 query=function(at)
  if tonumber(k.VirtualQuery(ffi.cast('const void *',at),mbi,48))~=48 then return nil,'Win32='..tonumber(lastError())end
  local b=ffi.string(mbi,48)
  return {base=N.ptr(b,0),size=N.ptr(b,24),state=N.u32(b,32),protection=N.u32(b,36),kind=N.u32(b,40)}
 end,
 protect=function(at,n,want)
  oldProtection[0]=0
  if protect(ffi.cast('void *',at),n,want,oldProtection)==0 then return nil,'Win32='..tonumber(lastError())end
  return tonumber(oldProtection[0])
 end,
 write=function(at,new)
  written[0]=0
  local ok=k.WriteProcessMemory(process,ffi.cast('void *',at),new,4,written)
  local code=tonumber(lastError())
  if ok==0 or tonumber(written[0])~=4 then return false,'Win32='..code..' bytes='..tonumber(written[0])end
  return true
 end})
M.write4=writer.write4
function M.request(at,instance,raw)
 assert(#raw==8,'package id');ffi.copy(ids,raw,8)
 ffi.cast(requestType,at)(ffi.cast('void *',instance),ids,1)
end
return M
end
