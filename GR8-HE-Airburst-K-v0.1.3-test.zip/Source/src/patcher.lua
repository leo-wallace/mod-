-- At most two four-byte changes, with compare-before-write and rollback.
return function(N,W)
local M={shared=nil,copies={}}
function M.apply(g,t,h,mode)
 local want=W.bytes(mode==1 and 312 or 96)
 local current=N.u32(t.raw,0)
 local old=M.shared
 local same=old and old.at==t.at and old.root==t.root and old.table==t.table
 assert(current==36 or (same and t.raw==old.last),'HE template conflict; restart without other GR8 ammo mods')
 local changes={{at=t.at,old=t.raw,new=want,label='shared HE template'}}
 local c=h and h.copy
 local key,prior
 if c then
  key=c.entity..':'..c.goid..':'..c.unit
  prior=M.copies[key]
  local inherited=same and c.raw==old.last
  assert(N.u32(c.raw,0)==36 or inherited or (prior and c.raw==prior.last),
   'private HE copy conflict')
  changes[#changes+1]={at=c.at,old=c.raw,new=want,label='private HE copy'}
 end
 g:validate()
 for i,x in ipairs(changes)do
  local good,why=W.write4(x.at,x.old,x.new)
  if not good then
   local rollback={}
   for j=i,1,-1 do
    local y=changes[j]
    if y.old~=y.new and N.win.read(y.at,4)==y.new then
     local restored,reason=W.write4(y.at,y.new,y.old)
     if not restored then rollback[#rollback+1]=y.label..': '..tostring(reason)end
    end
   end
   error(x.label..' write failed: '..tostring(why or'backend refused')..'; mode not committed'
    ..(#rollback>0 and'; rollback failures: '..table.concat(rollback,' | ')or''),0)
  end
 end
 M.shared={at=t.at,root=t.root,table=t.table,last=want}
 if c then M.copies[key]={last=want}end
 return true
end
return M
end
