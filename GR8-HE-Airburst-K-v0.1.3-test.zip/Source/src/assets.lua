-- Small standalone loader built from credited native findings; no Runtime require.
return function(N,D,W,B)
local M={ready=false,requested=false};local L,E=D.loader,D.loader.engine
local u32,ptr=N.u32,N.ptr
local loadout=B.unhex('4d120c61796e64f7')
local mission=B.unhex('b487998541f9d17e')
local function read(p,n)local b=N.win.read(p,n);assert(b and#b==n,'package memory unavailable');return b end
local function p(a)return ptr(read(a,8),0)end
local function prove(base,rva,hex)assert(read(base+rva,#hex/2)==B.unhex(hex),'package loader build mismatch')end
function M.resident(want)
 local manager=p(p(W.exe+E.managerGlobalRva)+E.packageManager)
 local resources=p(manager+E.resourceManager)
 local count=u32(read(resources+E.listCount,4),0)
 assert(count<=8192,'package list count');local list=p(resources+E.list)
 for first=0,count-1,256 do
  local n=math.min(256,count-first);local block=read(list+first*8,n*8)
  for j=0,n-1 do
   local pkg=ptr(block,j*8)
   if read(pkg+E.packageId,8)==want then
    local parts=u32(read(pkg+E.partCount,4),0)
    if parts==0 or parts>64 then return false end
    local array=read(p(pkg+E.parts),parts*8)
    for q=0,parts-1 do
     if u32(read(ptr(array,q*8)+E.partState,4),0)~=E.loadedState then return false end
    end
    return true
   end
  end
 end
 return false
end
function M.poll()
 N.win.begin_sample()
 prove(N.base,L.requestRva,L.requestProof)
 prove(N.base,L.releaseRva,L.releaseProof)
 prove(W.exe,E.hasLoadedRva,E.hasLoadedProof)
 prove(W.exe,E.findPackageRva,E.findPackageProof)
 -- Request only after the common mission dependencies are fully loaded.
 if not M.resident(mission)then M.ready=false;return false end
 if not M.requested then
  local instance=p(N.base+L.instanceGlobalRva)
  local header=read(instance,32);local map=L.refcountMap
  local cap=u32(header,map.capacity);local entries=ptr(header,map.entries)
  assert(cap>=16 and cap<=65536 and cap%2==0 and entries~=0,'package ref map')
  local used=0
  for first=0,cap-1,256 do
   local n=math.min(256,cap-first);local raw=read(entries+first*16,n*16)
   for j=0,n-1 do if raw:sub(j*16+1,j*16+8)~=string.rep('\0',8)then used=used+1 end end
  end
  assert(used/cap<0.75,'package ref map full')
  assert(read(instance,32)==header and p(N.base+L.instanceGlobalRva)==instance,'package identity changed')
  W.request(N.base+L.requestRva,instance,loadout)
  M.requested=true -- Keep one reference until process exit, as the engine loader expects.
 end
 M.ready=M.resident(loadout)
 return M.ready
end
return M
end
