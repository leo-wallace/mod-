# Validation — 2026-10-11

Status: offline-tested prototype; no game process was available for live testing.

23 tests executed in LuaJIT 2.1 through Python Lupa:

- Resolve the local peer among two players, its living avatar, inventory, held GR-8 and native HE flag.
- Change only the four-byte alternate projectile field, preserving HEAT, all surrounding configuration bytes and the native selector.
- Apply and toggle an existing private ProjectileWeapon copy.
- Handle a private copy created after a shared-template change.
- Roll back the template if the copy write is refused; do not commit the logical mode.
- Refuse foreign template/copy projectile values before any write.
- Refuse modified HEAT and donor references.
- Refuse writes when equipment identity changes between read and commit.
- Reject non-held, dead and out-of-mission contexts.
- Read HEAT independently of the remembered airburst mode.
- Filter held-key repeats, initial held keys, focus regain and ineligible input.
- Refuse native code fingerprint mismatch.
- Wait for package residency, request the RL-77 package once, and verify each loaded part.
- Exercise the actual update-hook body with simulated Win32 input/resource loading: no write before assets; K ignored in HEAT; HE switches; state survives HEAT round trips; original update is called.

All Lua sources and the assembled Lua entry compile with LuaJIT. The packed resource payload is extracted and compared byte-for-byte with the assembled source; ZIP CRC and manifest checked.

Not verified by these tests: actual Win32 calls inside Helldivers 2, current installed game build compatibility, projectile behavior, visual/audio dependencies, HUD rendering, ammo/reload behavior in live play, chat/menu input focus, multiplayer replication, or interactions with unrelated mods.

Reproduce offline checks: install Python `lupa`, run `python Source/tests/run.py`. Build with `python Source/build.py`; no game assets or runtime installation needed for these offline checks.

0.1.2 regression: carried-item slot can be empty while GR-8 is wielded; a stored GR-8 in that slot does not qualify when nothing is wielded.

0.1.3 adds eight writer tests: read-only protection lifecycle; read/write and write-copy pages; rejection of executable/guard/image/uncommitted memory; protection elevation failure; write failure/exception restoration; readback failure restoration; concurrent data change refusal; restoration failure stops future writes. Tests exercise the writer with an injected Win32 backend, not actual Helldivers process pages.
