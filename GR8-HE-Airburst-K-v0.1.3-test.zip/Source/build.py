from pathlib import Path
import importlib.util, json, uuid, zipfile, struct, hashlib

ROOT = Path(__file__).resolve().parent
def build():
    chunks = ['-- HD2-Addon: mods/leo_wallace/rr_airburst_modes',
              '-- GR-8 HE Airburst 0.1.3-test; no HD2Runtime installation dependency.',
              '-- Uses code / research from HD2Runtime by SkyeShade; see CREDITS.md.']
    for name, file in [('N','vendor/native_hud'), ('Facts','facts'), ('Controller','controller'),
                       ('Native','native'), ('DataWriter','write_data'), ('Windows','windows'), ('Assets','assets'),
                       ('Patcher','patcher'), ('Overlay','overlay')]:
        chunks.extend(['local '+name+'=(function()', (ROOT/'src'/f'{file}.lua').read_text(), 'end)()'])
    chunks.append((ROOT/'src/body.lua').read_text())
    source = '\n'.join(chunks).encode('utf-8')
    dist = ROOT/'dist'; dist.mkdir(exist_ok=True)
    (dist/'rr_airburst.lua').write_bytes(source)
    from lupa.luajit21 import LuaRuntime
    LuaRuntime().execute('assert(loadstring(...))', source.decode())
    spec = importlib.util.spec_from_file_location('pack', ROOT/'tools/pack_patch.py')
    pack = importlib.util.module_from_spec(spec); spec.loader.exec_module(pack)
    patch, _ = pack.build_patch([source])
    offset = struct.unpack_from('<Q', patch, 104+16)[0]
    length, version = struct.unpack_from('<II',patch,offset)
    assert version == 2 and patch[offset+8:offset+8+length] == source
    manifest = {'Version':1, 'Guid':str(uuid.uuid5(uuid.NAMESPACE_URL,'leo-wallace/gr8-he-airburst')),
      'Name':'GR-8 HE Airburst 0.1.3 TEST',
      'Description':'HEAT unchanged; HE Flak/Cluster via K. Requires Bingus Shared Loader v17+. No HD2Runtime dependency. Offline tested only. Uses research from HD2Runtime by SkyeShade; see README.',
      'Options':[{'Name':'GR-8 HE Airburst','Description':'Enable K airburst submode switching','Include':['data']}]}
    out = ROOT/'dist/GR8-HE-Airburst-K-v0.1.3-test.zip'
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
        z.writestr('data/9ba626afa44a3aa3.patch_0',patch)
        z.writestr('data/9ba626afa44a3aa3.patch_0.stream',b'')
        z.writestr('data/9ba626afa44a3aa3.patch_0.gpu_resources',b'')
        for n in ['README.md','CREDITS.md','VALIDATION.md']:
            z.write(ROOT/n,n)
        z.writestr('Source/dist/rr_airburst.lua',source)
        z.write(ROOT/'build.py','Source/build.py')
        for folder in ['src','tools','tests','third_party']:
            for p in sorted((ROOT/folder).rglob('*')):
                if p.is_file() and '__pycache__' not in p.parts:
                    z.write(p,'Source/'+str(p.relative_to(ROOT)))
        # Include docs with the build tree so the extracted sources rebuild independently.
        for n in ['README.md','CREDITS.md','VALIDATION.md']:
            z.write(ROOT/n,'Source/'+n)
    with zipfile.ZipFile(out) as z:
        assert z.testzip() is None
        assert json.loads(z.read('manifest.json'))['Options'][0]['Include']==['data']
    print(out)
    print('SHA256 '+hashlib.sha256(out.read_bytes()).hexdigest())
    return out

if __name__=='__main__':build()
