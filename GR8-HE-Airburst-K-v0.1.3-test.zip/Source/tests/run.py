from pathlib import Path
from lupa.luajit21 import LuaRuntime
root = Path(__file__).resolve().parents[1]
lua = LuaRuntime()
for p in (root / 'src').rglob('*.lua'):
    lua.execute('assert(loadstring(...))', p.read_text())
lua.globals().ROOT = str(root)
assert lua.execute((root / 'tests/test.lua').read_text()) >= 23
print('All source files compile with LuaJIT 2.1.')
