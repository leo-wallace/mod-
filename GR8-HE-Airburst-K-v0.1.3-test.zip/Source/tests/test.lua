local function loadpart(name)return assert(loadfile(ROOT..'/src/'..name..'.lua'))()end
local N=loadpart('vendor/native_hud')
local D=loadpart('facts')
local B=loadpart('native')(N,D)
local Controller=loadpart('controller')
local Patcher=loadpart('patcher')
local DataWriter=loadpart('write_data')
local passed=0
local function test(name,fn)
 local ok,why=pcall(fn);assert(ok,name..': '..tostring(why));passed=passed+1;print('PASS '..name)
end
local function b4(n)local t={};for i=1,4 do t[i]=string.char(n%256);n=math.floor(n/256)end;return table.concat(t)end
local function b8(n)return b4(n%4294967296)..b4(math.floor(n/4294967296))end
local function hex(h)return B.unhex(h):reverse()end
local function fixture()
 local mem={};local f={mem=mem,writes={}}
 function f.put(a,s)for i=1,#s do mem[a+i-1]=s:byte(i)end end
 function f.read(a,n)local out={};for i=0,n-1 do out[#out+1]=string.char(mem[a+i]or 0)end;return table.concat(out)end
 function f.set(a,n)f.put(a,b4(n))end
 local function ptr(a,p)f.put(a,b8(p))end
 local nextmap=0x30000000
 local function map(at,items)
  local entries=nextmap;nextmap=nextmap+0x1000
  ptr(at,entries);f.set(at+8,8);f.set(at+12,0xFFFFFFFF);f.set(at+16,1)
  for i=0,7 do f.set(entries+i*8,0xFFFFFFFF)end
  for key,index in pairs(items)do
   local i=key%8
   while N.u32(f.read(entries+i*8,4),0)~=0xFFFFFFFF do i=(i+1)%8 end
   f.set(entries+i*8,key);f.set(entries+i*8+4,index)
  end
 end
 f.base=0x100000;f.root=0x10000000
 N.base=f.base;N.win={read=f.read,begin_sample=function()end}
 N.lookup_cache=nil
 ptr(f.base+N.roots.network,f.root)
 f.game=0x20000000;ptr(f.base+D.state.game,f.game);f.set(f.game+D.state.state,4)
 local user,pm=0x21000000,0x22000000
 ptr(f.base+D.players.localUser,user);f.put(user+D.players.localPeer,'LOCAL123')
 ptr(f.base+D.players.global,pm);f.set(pm+D.players.count,2)
 f.put(pm+D.players.peers,'REMOTE12');f.put(pm+D.players.peers+56,'LOCAL123')
 f.set(pm+D.avatars.avatarId,999);f.set(pm+D.avatars.avatarId+32,100)
 local descriptors=f.root+0xF32F18
 f.put(descriptors,hex('aaaaaaaaaaaaaaaa')..b4(3001)..b4(500)..b4(100)..b4(1))
 f.put(descriptors+24,hex(B.GR8)..b4(4001)..b4(501)..b4(200)..b4(1))
 map(f.root+0xF1AEB0,{[3001]=0,[4001]=1});map(f.root+0xF22EC8,{[100]=0,[200]=1})
 local hm=0x23000000;ptr(f.base+N.roots.health,hm)
 map(hm+0x1030,{[3001]=0});ptr(hm+0x1048,hm+0x2000);ptr(hm+0x2000,descriptors)
 f.health=hm+0x4000;ptr(hm+0x1058,f.health);f.set(f.health+0x14,100)
 local inv=0x24000000;ptr(f.base+D.inventory.global,inv)
 map(inv+0x28,{[3001]=0});ptr(inv+0x40,inv+0x2000);ptr(inv+0x2000,descriptors)
 f.inv=inv+0x3000;ptr(inv+0x50,f.inv);f.set(f.inv+8,4001);f.set(f.inv+16,4001)
 local wielder=0x28000000;ptr(f.base+D.wielder.wielder,wielder)
 map(wielder+D.wielder.wielderHash,{[3001]=0})
 f.wielded=wielder+0x3000;ptr(wielder+D.wielder.slots,f.wielded);f.set(f.wielded,4001)
 local wm=0x25000000;ptr(f.base+0x3326CE0,wm);map(wm+0x30,{[4001]=0})
 ptr(wm+0x58,wm+0x2000);f.set(wm+0x2000+0x350,8)
 ptr(wm+0x60,wm+0x4000);f.modeAt=wm+0x4004;f.set(f.modeAt,4)
 f.pw=0x26000000;ptr(f.base+D.pw.global,f.pw);map(f.pw+D.pw.copies,{})
 f.copy=f.pw+0x3000;ptr(f.pw+D.pw.copyRecords,f.copy)
 function f.private(alt)
  map(f.pw+D.pw.copies,{[4001]=0});f.set(f.pw+D.pw.copyCount,1)
  f.put(f.copy,B.unhex(D.native_gr8));f.set(f.copy+576,alt or 36)
 end
 local tab=0x27000000;ptr(f.root+0xF12E80,tab)
 local function typeRecord(hash,index,bytes)
  local slot=N.mod64hex(hash,542);f.put(tab+slot*16,hex(hash)..b8(index))
  local at=tab+0x21E0+index*616;f.put(at,bytes);return at
 end
 f.rr=typeRecord(B.GR8,260,B.unhex(D.native_gr8))
 f.rl=typeRecord(B.RL77,241,B.unhex(D.native_rl77))
 function f.write4(at,old,new)
  if f.read(at,4)~=old then return false end
  if f.fail==at then return false end
  if old~=new then f.put(at,new);f.writes[#f.writes+1]={at,old,new}end
  return true
 end
 f.W={write4=f.write4,bytes=b4}
 function f.sample()local g=N.sample_graph();local h=B.held(g);return g,B.templates(g),h end
 return f
end
test('native lookup identifies local peer, held GR8 and HE',function()
 local f=fixture();local g,t,h=f.sample();assert(h and h.he and h.weapon.entity==4001);assert(t.at==f.rr+576);g:validate()
end)
test('HE patch changes exactly four bytes; HEAT and native selector unchanged',function()
 local f=fixture();local old=f.read(f.rr,616);local g,t,h=f.sample();local p=Patcher(N,f.W)
 p.apply(g,t,h,1)
 assert(f.read(f.rr,616)==old:sub(1,576)..b4(312)..old:sub(581))
 assert(N.u32(f.read(f.modeAt,4),0)==4 and#f.writes==1)
 local g,t,h=f.sample();p.apply(g,t,h,2);assert(N.u32(f.read(f.rr+576,4),0)==96)
 assert(N.u32(f.read(f.rr,4),0)==153 and N.u32(f.read(f.modeAt,4),0)==4)
end)
test('existing private copy also updated',function()
 local f=fixture();f.private();local g,t,h=f.sample();assert(h.copy.at==f.copy+576)
 local p=Patcher(N,f.W);p.apply(g,t,h,1)
 assert(N.u32(f.read(f.copy+576,4),0)==312 and#f.writes==2)
 local g,t,h=f.sample();p.apply(g,t,h,2);assert(N.u32(f.read(f.copy+576,4),0)==96)
end)
test('copy created after template patch inherits and switches',function()
 local f=fixture();local p=Patcher(N,f.W);local g,t,h=f.sample();p.apply(g,t,h,1)
 f.private(312);g,t,h=f.sample();p.apply(g,t,h,2)
 assert(N.u32(f.read(f.copy+576,4),0)==96)
end)
test('copy failure rolls template back and does not commit',function()
 local f=fixture();f.private();f.fail=f.copy+576;local p=Patcher(N,f.W)
 local g,t,h=f.sample();assert(not pcall(p.apply,g,t,h,1))
 assert(N.u32(f.read(f.rr+576,4),0)==36 and p.shared==nil)
end)
test('foreign template and copy changes refused before writes',function()
 for _,private in ipairs({false,true})do
  local f=fixture();if private then f.private(99)else f.set(f.rr+576,99)end
  local g,t,h=f.sample();assert(not pcall(Patcher(N,f.W).apply,g,t,h,1));assert(#f.writes==0)
 end
end)
test('modified HEAT and changed donor rejected',function()
 for _,which in ipairs({'rr','rl'})do
  local f=fixture();f.set(f[which],123);assert(not pcall(f.sample));assert(#f.writes==0)
 end
end)
test('identity change between sample and commit refuses writes',function()
 local f=fixture();local g,t,h=f.sample();f.set(f.wielded,4002)
 assert(not pcall(Patcher(N,f.W).apply,g,t,h,1));assert(#f.writes==0)
end)
test('not held, dead, out of mission do not qualify',function()
 local f=fixture();f.set(f.wielded,4002);assert(not B.held(N.sample_graph()))
 f=fixture();f.set(f.health+0x14,0);assert(not B.held(N.sample_graph()))
 f=fixture();f.set(f.health+0x19C,2);assert(not B.held(N.sample_graph()))
 f=fixture();f.set(f.game+D.state.state,3);assert(not B.held(N.sample_graph()))
end)
test('carried-item field is independent of wielded support weapon',function()
 local f=fixture();f.set(f.inv+16,0);assert(B.held(N.sample_graph()).weapon.entity==4001)
 f.set(f.inv+16,4001);f.set(f.wielded,0);assert(not B.held(N.sample_graph()))
end)
test('HEAT read remains separate from submode',function()
 local f=fixture();f.set(f.modeAt,0);local g,t,h=f.sample();assert(not h.he)
 Patcher(N,f.W).apply(g,t,h,2)
 assert(N.u32(f.read(f.modeAt,4),0)==0 and N.u32(f.read(f.rr,4),0)==153)
end)
test('K edge, held key, lost focus and ineligible input',function()
 local s=Controller.new();assert(Controller.step(s,true,true,true)==1)
 Controller.step(s,false,true,true);s.mode=Controller.step(s,true,true,true);assert(s.mode==2)
 assert(Controller.step(s,true,true,true)==2)
 Controller.step(s,false,true,true);assert(Controller.step(s,true,true,false)==2)
 Controller.step(s,false,false,true);assert(Controller.step(s,true,true,true)==2)
 Controller.step(s,false,true,true);s.mode=Controller.step(s,true,true,true);assert(s.mode==1)
end)
test('native fingerprints fail closed',function()
 local f=fixture();assert(not pcall(B.prove))
 for _,v in ipairs(D.pins)do f.put(f.base+v.rva,B.unhex(v.hex))end
 for _,v in ipairs(D.wielderPins)do f.put(f.base+v.rva,B.unhex(v.hex))end
 f.put(f.base+0x1787515,B.unhex('4c8b1dc4f7b901'))
 f.put(f.base+0x755EF8,B.unhex('488b43604b8d0c498b448804c1e802'))
 B.prove();assert(B.proven)
end)
test('resource loader waits, requests once, and checks every part',function()
 local f=fixture();local exe=0x40000000;local L,E=D.loader,D.loader.engine
 for _,v in ipairs({{f.base,L.requestRva,L.requestProof},{f.base,L.releaseRva,L.releaseProof},
  {exe,E.hasLoadedRva,E.hasLoadedProof},{exe,E.findPackageRva,E.findPackageProof}})do
  f.put(v[1]+v[2],B.unhex(v[3]))
 end
 local er,pm,resources,list=0x50000000,0x51000000,0x52000000,0x53000000
 f.put(exe+E.managerGlobalRva,b8(er));f.put(er+E.packageManager,b8(pm))
 f.put(pm+E.resourceManager,b8(resources));f.put(resources+E.list,b8(list));f.set(resources+E.listCount,2)
 local part={}
 for i,id in ipairs({'7ed1f941859987b4','f7646e79610c124d'})do
  local pkg=0x54000000+i*0x1000;local array=pkg+0x100;part[i]=pkg+0x200
  f.put(list+(i-1)*8,b8(pkg));f.put(pkg+E.packageId,hex(id));f.set(pkg+E.partCount,1)
  f.put(pkg+E.parts,b8(array));f.put(array,b8(part[i]));f.set(part[i]+E.partState,0)
 end
 local inst,entries=0x55000000,0x56000000
 f.put(f.base+L.instanceGlobalRva,b8(inst));f.put(inst,b8(entries));f.set(inst+8,16)
 local requests=0
 local w={exe=exe,request=function(at,instance,raw)
  assert(at==f.base+L.requestRva and instance==inst and raw==hex('f7646e79610c124d'))
  requests=requests+1
 end}
 local a=loadpart('assets')(N,D,w,B)
 assert(not a.poll()and requests==0)
 f.set(part[1]+E.partState,4);assert(not a.poll()and requests==1)
 assert(not a.poll()and requests==1)
 f.set(part[2]+E.partState,4);assert(a.poll()and requests==1)
 f.set(part[2]+E.partState,0);assert(not a.poll()and requests==1)
 f.put(f.base+L.requestRva,'BAD!');assert(not pcall(a.poll));assert(requests==1)
end)
test('entry hook: assets gate, HEAT ignores K, HE cycles and remembers',function()
 local f=fixture();local down,focus,mods=false,true,false;local assetsReady=false
 local oldUpdate=0
 _G.update=function()oldUpdate=oldUpdate+1 end
 N.ensure=function()return true end
 local windows=function()
  f.W.keys=function()return down,focus,mods end;return f.W
 end
 local assets=function()
  local a={ready=false};function a.poll()a.ready=assetsReady;return a.ready end;return a
 end
 -- Use real reader, inject only platform-dependent input/resources/GUI.
 local native=function()local obj=loadpart('native')(N,D);obj.prove=function()obj.proven=true end;return obj end
 local body=assert(io.open(ROOT..'/src/body.lua')):read('*a')
 local env=setmetatable({N=N,Facts=D,Controller=Controller,Windows=windows,Native=native,Assets=assets,
  Patcher=Patcher,Overlay=function()return {show=function()end,close=function()end}end,
  print=function()end,io={open=function()end}}, {__index=_G})
 env._G=env;env.update=_G.update
 local fn=assert(loadstring(body));setfenv(fn,env);local st=fn()
 local function frame()env.update(0.2)end
 env.update({},0.2);env.update();assert(#f.writes==0)
 frame();frame();assert(#f.writes==0)
 assetsReady=true;for i=1,6 do frame()end
 assert(N.u32(f.read(f.rr+576,4),0)==312)
 f.set(f.modeAt,0);down=true;frame();assert(st.mode=='Flak')
 f.set(f.modeAt,4);frame();assert(st.mode=='Flak') -- still holding K
 down=false;frame();down=true;frame();assert(st.mode=='Cluster')
 assert(N.u32(f.read(f.modeAt,4),0)==4 and N.u32(f.read(f.rr,4),0)==153)
 f.set(f.modeAt,0);down=false;frame();f.set(f.modeAt,4);frame();assert(st.mode=='Cluster')
 down=true;mods=true;frame();assert(st.mode=='Cluster')
 assert(oldUpdate>10)
end)
local function writerFixture(prot)
 local f={raw=b4(36),protection=prot,kind=0x20000,state=4096,events={},writes=0}
 local B={}
 function B.read()if f.readFail then return nil end;return f.raw end
 function B.query()
  return {base=0x10000,size=4096,protection=f.protection,kind=f.kind,state=f.state}
 end
 function B.protect(at,n,want)
  f.events[#f.events+1]=want
  if f.restoreFail and want==2 then return nil,'restore error'end
  if f.elevateFail and want==4 then return nil,'elevation error'end
  local old=f.protection;f.protection=want
  if f.race and want==4 then f.raw=b4(99)end
  return old
 end
 function B.write(at,new)
  f.writes=f.writes+1
  if f.exception then error('write exception')end
  if f.writeFail then return false,'error=5'end
  f.raw=new
  if f.badReadback then f.readFail=true end
  return true
 end
 f.writer=DataWriter(B)
 function f.apply()return f.writer.write4(0x10000,b4(36),b4(312))end
 return f
end
test('read-only data temporarily writable, then restored',function()
 local f=writerFixture(2);assert(f.apply());assert(f.raw==b4(312)and f.protection==2)
 assert(#f.events==2 and f.events[1]==4 and f.events[2]==2 and f.writes==1)
end)
test('read-write and write-copy data accepted without protection changes',function()
 for _,prot in ipairs({4,8})do local f=writerFixture(prot);assert(f.apply());assert(#f.events==0)end
end)
test('executable, guard, image and uncommitted regions refused',function()
 for _,prot in ipairs({1,16,32,64,128,0x102})do
  local f=writerFixture(prot);assert(not f.apply());assert(f.writes==0 and#f.events==0)
 end
 local f=writerFixture(2);f.kind=0x1000000;assert(not f.apply()and f.writes==0)
 f=writerFixture(2);f.state=8192;assert(not f.apply()and f.writes==0)
end)
test('protection elevation failure never writes',function()
 local f=writerFixture(2);f.elevateFail=true;local ok,why=f.apply()
 assert(not ok and why:find('make%-writable')and f.writes==0 and f.protection==2)
end)
test('write failure and Lua exception still restore protection',function()
 for _,mode in ipairs({'writeFail','exception'})do
  local f=writerFixture(2);f[mode]=true;assert(not f.apply());assert(f.protection==2 and#f.events==2)
 end
end)
test('readback failure still restores protection',function()
 local f=writerFixture(2);f.badReadback=true;local ok,why=f.apply()
 assert(not ok and why:find('readback')and f.protection==2)
end)
test('changed bytes after elevation refused and protection restored',function()
 local f=writerFixture(2);f.race=true;assert(not f.apply());assert(f.writes==0 and f.protection==2)
end)
test('restoration failure disables later writes and reports exact step',function()
 local f=writerFixture(2);f.restoreFail=true;local ok,why=f.apply()
 assert(not ok and why:find('restore%-protection')and f.writer.disabled)
 f.raw=b4(36);local n=f.writes;assert(not f.apply()and f.writes==n)
end)
print('TOTAL '..passed..' tests passed')
return passed
