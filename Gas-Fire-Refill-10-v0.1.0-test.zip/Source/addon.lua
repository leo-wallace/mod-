-- HD2-Addon: mods/leo_wallace/gas_fire_refill_10
-- G-4 / G-8 refill 10 standalone TEST 0.1.0; Bingus Shared Loader only.
local KEY='LeoWallaceGasFireRefill10_v010'
if rawget(_G,KEY) then return rawget(_G,KEY) end
local loader=assert(rawget(_G,'CowboyBingusModLoader'),'Bingus Shared Loader required')
assert(loader.api>=1,'Loader API 1 required')
local logfile=loader.open_log and loader.open_log('GasFireRefill10.log')
local function log(s)
 print('[GasFireRefill10] '..tostring(s))
 if logfile then logfile:write(tostring(s)..'\n');logfile:flush() end
end
local state={};rawset(_G,KEY,state)
local function unhex(s)return (s:gsub('..',function(x)return string.char(tonumber(x,16))end))end
local function u32(s,i)
 i=i+1;local a,b,c,d=s:byte(i,i+3);return a+b*256+c*65536+d*16777216
end
local MAP=unhex('70cac1804c444c440100000070cac18084d002000100000000000000')
local COMPONENT=27335376
local HEADER=unhex('03010000b5bc16af4c444c4401000000b5bc16af704600000100000000000000')
local TARGETS={
 {name='G-4 Gas',row=55,record=31,hash=unhex('7b7522494f981604'),default=2},
 {name='G-8 Immolation',row=4,record=15,hash=unhex('e03bdd5977f2145c'),default=3}
}
local PATCH=(function()
-- Validates all targets before any write; restores completed writes on failure.
local M={}
function M.apply(api,game,owner_offset,edits)
 local jobs={}
 for _,e in ipairs(edits) do
  local p,guards=nil,{}
  local function read_guard(a,n)
   local b=api.read(a,n)
   if b then guards[#guards+1]={a=a,b=b} end
   return b
  end
  if e.kind=='located' then
   p=game
   assert(read_guard(p,28)==e.map_header,'Entity map changed')
   assert(read_guard(p+e.component_offset-4,32)==e.component_header,'Throwable layout changed')
  elseif e.kind=='global' then
   p=game
   assert(read_guard(game+e.code_offset,#e.code)==e.code,'Native consumer changed: '..e.label)
  elseif e.kind=='section' then
   local root=api.pointer(read_guard(game+e.global_rva,8))
   if not root then return 'Waiting for settings data' end
   if e.root_pointer_offset then
    root=api.pointer(read_guard(root+e.root_pointer_offset,8))
    if not root then return 'Waiting for settings collection' end
   end
   assert(read_guard(root+e.header_offset,#e.header)==e.header,'Settings layout changed: '..e.label)
   p=root+e.header_offset+24
  elseif e.kind=='array' then
   local root=api.pointer(read_guard(game+e.global_rva,8))
   if not root then return 'Waiting for settings data' end
   assert(read_guard(root+e.header_offset,#e.header)==e.header,'Settings layout changed: '..e.label)
   assert(read_guard(root+e.descriptor_offset+8,8)==e.count_bytes,'Settings count changed: '..e.label)
   p=api.pointer(read_guard(root+e.descriptor_offset,8))
   if not p then return 'Waiting for settings array' end
  else
   local owner=api.pointer(read_guard(game+owner_offset,8))
   if not owner then return 'Waiting for game data' end
   p=api.pointer(read_guard(owner+e.owner_offset,8))
   if not p then return 'Waiting for table data' end
   assert(read_guard(p-28,28)==e.header,'Table layout changed: '..e.label)
  end
  assert(read_guard(p+(e.identity_offset or e.slot*16),#e.identity)==e.identity,'Resource mapping changed: '..e.label)
  if e.guard then assert(read_guard(p+e.guard_offset,#e.guard)==e.guard,'Field identity changed: '..e.label) end
  local a=p+e.offset
  assert(#e.before==#e.after and #e.after>0,'Invalid patch width: '..e.label)
  local current=assert(api.read(a,#e.after),'Value unavailable')
  assert(current==e.before or current==e.after or (e.original and current==e.original),'Conflicting value: '..e.label)
  jobs[#jobs+1]={a=a,before=current,after=e.after,module_data=e.kind=='global',guards=guards,label=e.label}
 end
 -- Different locators can still resolve to the same live allocation.
 local ordered={}
 for i,j in ipairs(jobs)do ordered[i]=j end
 table.sort(ordered,function(a,b)return a.a<b.a end)
 for i=2,#ordered do
  assert(ordered[i].a>=ordered[i-1].a+#ordered[i-1].after,'Overlapping patch targets: '..ordered[i].label)
 end
 local function check_guards(j)
  for _,g in ipairs(j.guards)do assert(api.read(g.a,#g.b)==g.b,'Target changed during validation: '..j.label) end
 end
 local written={}
 local ok,err=pcall(function()
  for _,j in ipairs(jobs)do check_guards(j) end
  for _,j in ipairs(jobs) do
   check_guards(j)
   assert(api.read(j.a,#j.before)==j.before,'Value changed during validation')
   if j.before~=j.after then
    -- A native write can succeed before its protection-restoration step throws.
    written[#written+1]=j
    assert(api.replace_data(j.a,j.before,j.after,j.module_data),'Write failed')
    assert(api.read(j.a,#j.after)==j.after,'Read-back failed')
   end
  end
 end)
 if not ok then
  local restored=true
  for i=#written,1,-1 do
   local j=written[i]
   local rollback_ok,result=pcall(function()
    check_guards(j)
    local current=api.read(j.a,#j.before)
    if current==j.before then return true end
    if current~=j.after then return false end
    api.replace_data(j.a,j.after,j.before,j.module_data)
    return api.read(j.a,#j.before)==j.before
   end)
   if not rollback_ok or not result then restored=false end
  end
  error(tostring(err)..(restored and ' (rolled back)' or ' (restart game: rollback incomplete)'))
 end
 return 'Active: '..#edits..' number changes'
end
return M

end)()
local make_api=(function()
-- Adapted Windows read/hash helpers from CowboyBingus/ConsistentVaulting.
return function()
    local ffi = require('ffi')
    assert(ffi.abi('64bit'), 'Windows x64 is required')
    ffi.cdef [[
        void *GetModuleHandleA(const char *name);
        uint32_t GetModuleFileNameW(void *module, uint16_t *path, uint32_t capacity);
        void *GetCurrentProcess(void);
        uint64_t GetTickCount64(void);
        int ReadProcessMemory(void *process, const void *address, void *buffer, size_t size, size_t *read);
        int WriteProcessMemory(void *process, void *address, const void *buffer, size_t size, size_t *written);
        typedef struct {
            void *base; void *allocation_base; uint32_t allocation_protection;
            uint16_t partition; uint16_t reserved; size_t size;
            uint32_t state; uint32_t protection; uint32_t type;
        } LeoGasFireMemoryRegion_v010;
        size_t VirtualQuery(const void *address, void *region, size_t size);
        void *CreateFileW(const uint16_t *path, uint32_t access, uint32_t share, void *security,
                          uint32_t disposition, uint32_t flags, void *template_file);
        int ReadFile(void *file, void *buffer, uint32_t size, uint32_t *read, void *overlapped);
        int CloseHandle(void *handle);
        int32_t BCryptOpenAlgorithmProvider(void **algorithm, const uint16_t *name,
                                            const uint16_t *provider, uint32_t flags);
        int32_t BCryptCloseAlgorithmProvider(void *algorithm, uint32_t flags);
        int32_t BCryptCreateHash(void *algorithm, void **hash, void *object, uint32_t object_size,
                                 const void *secret, uint32_t secret_size, uint32_t flags);
        int32_t BCryptHashData(void *hash, const void *data, uint32_t size, uint32_t flags);
        int32_t BCryptFinishHash(void *hash, void *digest, uint32_t size, uint32_t flags);
        int32_t BCryptDestroyHash(void *hash);
    ]]
    local kernel, bcrypt = ffi.load('kernel32'), ffi.load('bcrypt')
    -- LuaJIT retains the first function declaration in the shared VM. Use an
    -- opaque buffer when declaring first so another mod's equivalent struct is
    -- accepted. Cast our own call as well for a typed declaration loaded first.
    local query_region = ffi.cast('size_t (*)(const void *, void *, size_t)', kernel.VirtualQuery)
    local process = kernel.GetCurrentProcess()
    local api = {}
    function api.time() return tonumber(kernel.GetTickCount64()) / 1000 end

    function api.module(name)
        local handle = kernel.GetModuleHandleA(name)
        if handle == nil then return nil end
        return ffi.cast('uint8_t *', handle)
    end

    function api.read(address, size)
        local buffer, count = ffi.new('uint8_t[?]', size), ffi.new('size_t[1]')
        if kernel.ReadProcessMemory(process, address, buffer, size, count) == 0 or count[0] ~= size then
            return nil
        end
        return ffi.string(buffer, size)
    end

    function api.write(address, bytes)
        if not api.writable_data(address, #bytes) then return false end
        local count = ffi.new('size_t[1]')
        return kernel.WriteProcessMemory(process, address, bytes, #bytes, count) ~= 0 and count[0] == #bytes
    end

    function api.pointer(bytes, offset)
        offset = offset or 0
        if not bytes or offset < 0 or offset + 8 > #bytes then return nil end
        local value = ffi.new('uintptr_t[1]')
        ffi.copy(value, bytes:sub(offset + 1, offset + 8), 8)
        if value[0] < 0x10000 or value[0] >= 0x800000000000 then return nil end
        return ffi.cast('uint8_t *', value[0])
    end

    function api.distance(first, second)
        return tonumber(ffi.cast('intptr_t', first) - ffi.cast('intptr_t', second))
    end

    function api.writable_data(address, size)
        if size <= 0 then return false end
        local cursor = ffi.cast('uint8_t *', address)
        local remaining = size
        local region = ffi.new('LeoGasFireMemoryRegion_v010[1]')
        while remaining > 0 do
            if query_region(cursor, region, ffi.sizeof(region[0])) ~= ffi.sizeof(region[0]) then return false end
            -- Settings must already be writable private data, never executable or mapped module pages.
            if region[0].state ~= 0x1000 or region[0].type ~= 0x20000 or region[0].protection ~= 4 then return false end
            local available = tonumber(region[0].size) - api.distance(cursor, region[0].base)
            if available <= 0 then return false end
            local count = math.min(available, remaining)
            cursor, remaining = cursor + count, remaining - count
        end
        return true
    end

    function api.module_hash(module)
        local path = ffi.new('uint16_t[32768]')
        local length = kernel.GetModuleFileNameW(module, path, 32768)
        assert(length > 0 and length < 32768, 'Cannot resolve module file')
        local file = kernel.CreateFileW(path, 0x80000000, 7, nil, 3, 0x08000000, nil)
        assert(file ~= ffi.cast('void *', -1), 'Cannot read module file')
        local algorithm, hash = ffi.new('void *[1]'), ffi.new('void *[1]')
        local ok, result = pcall(function()
            local name = ffi.new('uint16_t[7]', {83, 72, 65, 50, 53, 54, 0})
            assert(bcrypt.BCryptOpenAlgorithmProvider(algorithm, name, nil, 0) == 0, 'SHA256 unavailable')
            assert(bcrypt.BCryptCreateHash(algorithm[0], hash, nil, 0, nil, 0, 0) == 0, 'SHA256 creation failed')
            local buffer, count = ffi.new('uint8_t[1048576]'), ffi.new('uint32_t[1]')
            while true do
                assert(kernel.ReadFile(file, buffer, 1048576, count, nil) ~= 0, 'Module file read failed')
                if count[0] == 0 then break end
                assert(bcrypt.BCryptHashData(hash[0], buffer, count[0], 0) == 0, 'SHA256 update failed')
            end
            local digest, hex = ffi.new('uint8_t[32]'), {}
            assert(bcrypt.BCryptFinishHash(hash[0], digest, 32, 0) == 0, 'SHA256 finish failed')
            for i = 0, 31 do hex[#hex + 1] = string.format('%02X', digest[i]) end
            return table.concat(hex)
        end)
        if hash[0] ~= nil then bcrypt.BCryptDestroyHash(hash[0]) end
        if algorithm[0] ~= nil then bcrypt.BCryptCloseAlgorithmProvider(algorithm[0], 0) end
        kernel.CloseHandle(file)
        if not ok then error(result) end
        return result
    end

    ffi.cdef [[
        int VirtualProtect(void *address, size_t size, uint32_t protection, uint32_t *old);
    ]]
    function api.replace_data(address,before,after,allow_image_data)
        assert(#before==#after and #before>=1 and #before<=22096,'Invalid write extent')
        local region=ffi.new('LeoGasFireMemoryRegion_v010[1]')
        if query_region(address,region,ffi.sizeof(region[0]))~=ffi.sizeof(region[0]) then return false end
        local r=region[0]
        -- Private data by default. Explicitly guarded tunables may use writable image data; never executable pages.
        local permitted=r.type==0x20000 or (allow_image_data==true and r.type==0x1000000 and r.protection==4)
        if r.state~=0x1000 or not permitted or (r.protection~=2 and r.protection~=4) then return false end
        if api.distance(address,r.base)<0 or api.distance(address,r.base)+#after>tonumber(r.size) then return false end
        if api.read(address,#before)~=before then return false end
        local old=ffi.new('uint32_t[1]')
        if kernel.VirtualProtect(address,#after,4,old)==0 then return false end
        local ok,result=pcall(function()
            if api.read(address,#before)~=before then return false end
            local n=ffi.new('size_t[1]')
            local written=kernel.WriteProcessMemory(process,address,after,#after,n)~=0 and n[0]==#after
            if not written or api.read(address,#after)~=after then
                kernel.WriteProcessMemory(process,address,before,#before,n)
                return false
            end
            return true
        end)
        local ignored=ffi.new('uint32_t[1]')
        local restored=kernel.VirtualProtect(address,#after,old[0],ignored)~=0
        if not restored then error('Could not restore grenade data page protection') end
        if not ok then error(result) end
        return result
    end
    function api.query(address)
        local r=ffi.new('LeoGasFireMemoryRegion_v010[1]')
        if query_region(ffi.cast('void *',address),r,ffi.sizeof(r[0]))~=ffi.sizeof(r[0]) then return nil end
        return {base=tonumber(ffi.cast('uintptr_t',r[0].base)),
            allocation=tonumber(ffi.cast('uintptr_t',r[0].allocation_base)),size=tonumber(r[0].size),
            state=tonumber(r[0].state),kind=tonumber(r[0].type),protection=tonumber(r[0].protection)}
    end
    function api.address(n) return ffi.cast('uint8_t *',n) end
    return api
end

end)()

-- Read and validate the whole 92-row index so shared records are never patched.
local function edits_for(api,base)
 assert(api.read(base,28)==MAP,'Entity allocation identity changed')
 assert(api.read(base+COMPONENT-4,32)==HEADER,'Throwable component framing changed')
 local index=assert(api.read(base+COMPONENT+28,1472),'Throwable index unreadable')
 local edits={}
 for _,t in ipairs(TARGETS)do
  local at=t.row*16
  assert(index:sub(at+1,at+8)==t.hash and u32(index,at+8)==t.record and u32(index,at+12)==0,'Grenade mapping changed: '..t.name)
  local owners=0
  for row=0,91 do
   local p=row*16
   if index:sub(p+1,p+8)~=string.rep('\0',8) and u32(index,p+8)==t.record then owners=owners+1 end
  end
  assert(owners==1,'Shared grenade record: '..t.name)
  edits[#edits+1]={kind='located',map_header=MAP,component_offset=COMPONENT,component_header=HEADER,
   identity_offset=COMPONENT+28,identity=index,
   offset=COMPONENT+28+1472+t.record*360+108,
   before=string.char(t.default,0,0,0),after=string.char(10,0,0,0),label=t.name}
 end
 return edits
end
local function start()
 local api=make_api()
 local game=assert(api.module('game.dll'),'game.dll unavailable')
 assert(api.module_hash(game)=='2E2C3B7C2500646DADD5F2B4C6E0504DBB7E7896139F64CDDC0D1813C718F51E','Game DLL version differs; no writes')
 assert(api.module_hash(api.module('helldivers2.exe'))=='F5FEE03DCFDB2E553A4752C283590950AC13316B376D8196AA556FF0400D5F06','Game executable version differs; no writes')
 local cursor,candidates,queries=65536,{},0
 local base,edits,next_check=nil,nil,0
 local previous=rawget(_G,'update')
 local function tick()
  if not base then
   -- Amortize the read-only allocation search over frames; reject ambiguity.
   for _=1,256 do
    local r=api.query(cursor)
    if not r then cursor=140737488289792;break end
    assert(r.size>0 and r.base+r.size>cursor,'Invalid memory map')
    cursor=r.base+r.size;queries=queries+1
    assert(queries<=200000,'Memory discovery query limit')
    if r.base==r.allocation and r.size==46616576 and r.state==4096 and r.kind==131072 and (r.protection==2 or r.protection==4) then
     if api.read(api.address(r.base),28)==MAP then candidates[#candidates+1]=r.base end
    end
    if cursor>=140737488289792 then break end
   end
   if cursor<140737488289792 then return end
   if #candidates==0 then
    -- Data may not be loaded yet. Retry the bounded search in five seconds.
    cursor,candidates,queries=65536,{},0;next_check=api.time()+5;return
   end
   assert(#candidates==1,'Ambiguous entity allocation; no writes')
   base=api.address(candidates[1]);edits=edits_for(api,base)
  end
  local result=PATCH.apply(api,base,0,edits)
  if state.status~=result then state.status=result;log(result..' (G-4 / G-8 refill=10)')end
  next_check=api.time()+1
 end
 function update(...)
  if not state.failed and api.time()>=next_check then
   local ok,err=pcall(tick)
   if not ok then state.failed=true;log('Disabled: '..tostring(err)) end
  end
  if type(previous)=='function' then return previous(...) end
 end
 log('Registered; standalone G-4 / G-8 refill test; build hashes verified')
end
local ok,err=pcall(start)
if not ok then state.failed=true;log('Disabled: '..tostring(err))end
return state
