G-4 毒气雷 / G-8 长效火雷：补给数量 10，独立测试版 0.1.0

依赖：Bingus Shared Loader（API >= 1）。不需要安装 HD2Runtime。
用你现有的 HD2 Mod Manager 导入本 ZIP，选中本选项后部署，完整重启游戏。
停用旧 Resupply-10-6 混合包。本包可以和独立 Stim-Refill-6 共存。

仅修改 ThrowableComponentData 的补给数量字段：G-4 2 -> 10；G-8 3 -> 10。
不修改出场数量、携带上限、伤害、穿甲、爆炸、毒气或燃烧时间。
实际补入仍受携带上限限制：若最多携带4个，空背包最多回到4个，不会变成10个。
测试：启动后等数秒再进入任务，分别装备 G-4 和 G-8，消耗手雷后领取一格补给。
地面手雷箱、补给背包等补给来源是否都使用这个字段，尚需游戏内分别验证。

这是未做游戏内实测的测试版，不承诺已生效。
版本锁定：Steam build 25480438 / exe 1.8.46015.0；同时验证 exe 和 game.dll SHA-256。
版本不同、资源索引不同、原补给值已被其他模组改动时停止写入。
启动后扫描一次受限内存区域；验证组件头、资源索引和独占记录，只写两个4字节字段。
每秒核验，发现漂移即停用；卸载后完整重启游戏恢复默认。
日志使用 Loader 的 open_log，名称 GasFireRefill10.log（不是 HD2Runtime.log）。

数据依据：用户提供的 HD2Runtime 0.30.3 元数据；无需运行或安装它。
Windows read/hash helpers adapted from CowboyBingus/ConsistentVaulting and supplied Health Rework.
Source/addon.lua 为完整源码；python Source/rebuild.py 可用 Python 标准库重建 ZIP。
