# MA5C 1100 射速 / 120 发 / 耐久伤害 ×2（0.1.1 实验版）

基于用户提供的 Halo-MA5C-M6C-0.1.0-experimental 包修改。

| 项目 | 原包 | 此版 |
| --- | --- | --- |
| MA5C 射速 | 900 RPM | 1100 RPM |
| MA5C 弹匣容量 | 60 发 | 120 发 |
| 所用 MG-43 弹药的单发耐久伤害 | 23 | 46 |
| 单发普通伤害 | 90 | 90 |

“120 发”指每个弹匣容量。备用弹匣数量、补给、操控、换弹、后坐力、射击模式沿用原包。
M6C 沿用原包的 MG-206 弹丸替换，其射速、12 发弹匣等配置未改。

## 共享伤害影响

原包将 MA5C 的弹丸换为 MG-43 弹丸。此版直接修改共享 DamageInfo 125 的耐久字段，因此原版 MG-43 和其他引用这条伤害记录的武器也会获得 23→46 的耐久伤害。该效果不限定在 MA5C 上。

数据依据：原包的 ProjectileType 148；Darctor/Helldivers2_RawData 的公开弹丸/伤害表用于识别 90/23 配置；用户 build 25480438 的只读日志中，完整匹配记录为 DamageInfo 125。不同版本的 ID 有变化，最终写入由当前日志中的完整 76 字节记录和相邻记录共同校验。实际游戏内的弹丸关联和伤害结果尚未验证。

https://github.com/Darctor/Helldivers2_RawData

## 安装

1. 退出游戏，禁用并移除旧的 Halo MA5C + M6C 包。
2. 使用 Arsenal 或 HD2 Mod Manager 导入本 ZIP，启用并部署。
3. 保留 Bingus Shared Loader v15，重新启动游戏。

此包沿用旧包的 GUID 和资源标识，用于替换旧版，不要同时部署两个 Halo 版本。
沿用原包的 game.dll SHA-256 限制，目标 build 25480438；校验不符时不写入。

## 验证与日志

已进行 Lua 语法、离线内存模拟、写入回读、恢复及不匹配拒绝检查；尚未进入游戏实测。
日志为 HaloMa5cM6c.log。MA5C 的三项组件分别显示 applied_template_gameplay_unverified，表示对应模板写入成功，不代表实战效果已被验证。
出现 template_mismatch_no_write 或 template_not_found_no_write 时，该组停止应用并尝试恢复已持有的修改。
source 目录附实际嵌入 Lua 及离线测试，游戏加载 data 目录中的补丁。
