# Halo MA5C 1100 RPM / 120 rounds / durable damage x2 (0.1.1 experimental)

MA5C: 900 to 1100 RPM; 60 to 120 rounds per magazine. The shared MG-43 damage record changes from 90 normal / 23 durable to 90 normal / 46 durable. This also affects MG-43 and any other weapon referencing that damage record. M6C retains the input package's MG-206 projectile swap and other settings.

Replace the old Halo package in Arsenal or HD2 Mod Manager, deploy, and fully restart the game. Requires the existing Bingus Shared Loader v15. Uses the original GUID, resource identity, and exact game.dll SHA-256 guard for build 25480438.

Offline checks cover syntax, exact writes/readback, restore, and mismatch rejection. Gameplay remains unverified. See README.zh-CN.md for mapping evidence, shared effects, and log interpretation.
