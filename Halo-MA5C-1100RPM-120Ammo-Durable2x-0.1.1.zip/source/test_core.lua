local loaded = dofile('halo011/source/test_spec.lua')
local Core, SPEC = loaded.Core, loaded.SPEC
assert(#SPEC.components == 4)
local function setup(spec, mismatch)
    spec.game = 0x10000000
    spec.owner_rva = SPEC.owner_rva
    local owner, tab = 0x20000000, 0x30000000
    local mem, writes = {}, {}
    local function put(at, data)
        for i=1,#data do mem[at+i-1]=data:byte(i) end
    end
    local api = {}
    function api.read(at, n)
        local bytes = {}
        for i=0,n-1 do
            if mem[at+i] == nil then return nil end
            bytes[#bytes+1]=string.char(mem[at+i])
        end
        return table.concat(bytes)
    end
    function api.pointer(data) return string.unpack('<I8',data) end
    function api.write(at,data)
        writes[#writes+1]={at=at, data=data}; put(at,data); return true
    end
    put(spec.game+spec.owner_rva, string.pack('<I8',owner))
    put((spec.direct and spec.game or owner)+spec.candidate_slot, string.pack('<I8',tab))
    local record = tab
    if spec.direct then
        for _,guard in ipairs(spec.guards) do put(tab+guard.offset,guard.bytes) end
    else
        put(tab,spec.hashmap)
        record=tab+#spec.hashmap+spec.record_index*spec.record_size
    end
    put(record,spec.original)
    if mismatch then put(record+spec.record_size-1,'\255') end
    local c = Core.new(api,function()end,spec)
    return c,api,record,writes,put
end
for i,spec in ipairs(SPEC.components) do
    local c,api,record,writes = setup(spec)
    c.step()
    assert(c.lease and not c.disabled, spec.label)
    assert(#writes==#spec.edits)
    for j,e in ipairs(spec.edits) do
        assert(writes[j].at==record+e.offset and writes[j].data==e.replacement)
    end
    if i==1 then
        assert(string.unpack('<I4',api.read(record,4))==148)
        assert(string.unpack('<f',api.read(record+8,4))==1100)
    elseif i==2 then
        assert(string.unpack('<I4',api.read(record+136,4))==120)
    elseif i==3 then
        assert(string.unpack('<I4',api.read(record,4))==275)
    elseif i==4 then
        assert(string.unpack('<I4',api.read(record+4,4))==90)
        assert(string.unpack('<I4',api.read(record+8,4))==46)
    end
    c.step(); assert(#writes==#spec.edits)
    assert(c.stop() and api.read(record,spec.record_size)==spec.original)
    local bad,badapi,badrecord,badwrites = setup(spec,true)
    bad.step(); assert(bad.disabled and #badwrites==0)
    if spec.direct then
        local guarded,_,at,gw,put = setup(spec)
        put(at+spec.guards[1].offset,'\255')
        guarded.step(); assert(not guarded.lease and #gw==0)
    end
    print('PASS '..spec.label..': apply, readback, restore, mismatch rejection')
end
print('PASS all offline checks; real game behavior unverified')
