from pathlib import Path
import json, re, shutil, struct, zipfile

root = Path('halo011')
(root / 'data').mkdir(parents=True, exist_ok=True)
(root / 'source').mkdir(exist_ok=True)
original = Path('halo_input/script0.lua').read_text()
source = original.replace('000000000000614400000000', '000000000080894400000000', 1)
source = source.replace('offset=136,replacement=unhex("3c000000")', 'offset=136,replacement=unhex("78000000")', 1)
assert source != original and source.count('000000000080894400000000') == 1
rows = {}
slots = {}
for line in Path('upload/P34ThermiteStagger60(2).log').read_text().splitlines():
    m = re.search(r'ROW route=(\w+) delta=(-?\d+) addr=(0x[0-9a-f]+) id=(\d+).* hex=([0-9a-f]+)', line)
    if m:
        route, delta, addr, ident, hx = m.groups()
        rows[int(addr, 16)] = hx
        if route == 'slot': slots[int(ident)] = (int(delta), int(addr, 16))
delta, addr = slots[125]
raw = bytes.fromhex(rows[addr])
assert struct.unpack_from('<III', raw) == (125, 90, 23)
assert delta == 9 and len(raw) == 76
guards = ','.join('{offset=%d,bytes=unhex("%s")}' % (o, rows[addr+o]) for o in (-76, 76))
component = ('{group="MA5C",label="MA5C.SharedMG43Damage",resource="damage:125",'
             'record_size=76,record_index=125,candidate_slot=%d,original=unhex("%s"),'
             'direct=true,guards={%s},edits={{offset=8,replacement=unhex("2e000000")}}},\n'
             % (58483808 + delta*8, raw.hex(), guards))
source = source.replace('}}\nlocal key=', component + '}}\nlocal key=', 1)
assert source.count('label="MA5C.SharedMG43Damage"') == 1
source = source.replace("version='0.1.0-experimental'", "version='0.1.1-experimental'")
source = source.replace('scope=MA5C_M6C gameplay=UNVERIFIED',
    'scope=MA5C_M6C MA5C_rpm=1100 magazine=120 shared_damage_id=125 normal=90 durable=46 gameplay=UNVERIFIED')
(root/'source/halo_ma5c_m6c.lua').write_text(source)
prefix = source[:source.index("local key='StarmHaloMa5cM6c'")]
(root/'source/test_spec.lua').write_text(prefix + '\nreturn {Core=Core,SPEC=SPEC}\n')
blob = bytearray(Path('halo_input/data/9ba626afa44a3aa3.patch_0').read_bytes()[:192])
encoded = source.encode()
payload = struct.pack('<II', len(encoded), 2) + encoded
struct.pack_into('<I', blob, 160, len(payload))
blob += payload
blob += bytes((-len(blob)) % 16)
struct.pack_into('<Q', blob, 32, len(blob))
(root/'data/9ba626afa44a3aa3.patch_0').write_bytes(blob)
for ext in ('stream', 'gpu_resources'):
    (root/f'data/9ba626afa44a3aa3.patch_0.{ext}').write_bytes(b'')
manifest = json.loads(Path('halo_input/manifest.json').read_text())
manifest['Name'] = 'Halo MA5C 1100RPM 120Ammo Durable2x - Experimental 0.1.1'
manifest['Description'] = 'MA5C：1100 RPM、120 发弹匣、共享 MG-43 耐久伤害 23→46；普通伤害 90。M6C 配置沿用原包。build 25480438。'
manifest['Options'][0]['Description'] = '包含共享弹药耐久伤害修改，也影响使用同一伤害数据的武器。需要 Bingus Shared Loader v15，替换旧版后重启。'
(root/'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
for f in ('THIRD-PARTY-NOTICES.txt', 'C4-LICENSE.txt'):
    shutil.copyfile(Path('halo_input')/f, root/f)
(root/'DESCRIPTION.md').write_text(manifest['Description'] + '\n')
print('Built', len(encoded), 'Lua bytes;', len(blob), 'patch bytes; damage slot', 58483808 + delta*8)
