# LAS-22 切变 v1.0.4 资源持有实验

适用 Steam build 25480438，Bingus Shared Loader v18 / API1。

本轮针对标准散热器正常、扩容与快速散热器在中途加入任务时显示紫色问号。
以 v1.0.2 为基础，保留解锁与改装写入，不含 v1.0.3 的资源列表补丁。
新增代码核对游戏指纹、完整请求/释放函数字节、脚本 API 分发表、配件资源键到独立资源包的直接映射及资源引用表。
在菜单/简报状态请求两个独立资源包，回读引用计数是否恰好加一，并保持这两个引用跨越任务。遇到资源管理器重建时重新等待安全菜单状态。
这保证的是资源包请求及引用持有，不等同于模型已经完成异步加载；效果须游戏验证。

## 安装和测试

退出游戏，在模组管理器停用旧切变版本，仅启用本包并重新部署。
先停留主菜单至少一分钟，检查日志两条 HEATSINK_PACKAGE_ACQUIRE_VERIFIED；再直接加入已开始任务，分别查看扩容和快速散热器。
不要为了预热先打开军械库，否则无法区分本实验和预览预热的效果。
保留一次正常标准散热器对照。若失败，保留日志与配件类型。

## 日志与恢复

日志：%LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\LAS22ShearCustomizationExperimentM4.log
运行时错误仅停用新增资源持有逻辑；能确认属于本次且管理器仍一致的引用会尝试释放。
关闭游戏、停用本版并重新部署 v1.0.2 即可恢复；没有修改存档或网络数据。

## 接口依据

https://github.com/CowboyBingus/ArmoryPreviewCache/blob/main/src/native.lua
https://github.com/CowboyBingus/ArmoryPreviewCache/blob/main/src/dependencies.lua
https://github.com/CowboyBingus/ArmoryPreviewCache/blob/main/src/signatures.lua

本包尚未通过游戏内中途加入测试，不能宣称修复成功。
