-- HD2-Addon: mods/codex/las22_shear_overheat_demolition40
-- Native evidence: Rapid Heat Sink ability2861 -> projectile273 -> explosion64 -> DamageInfo387.
-- The standard overheat projectile5 shares explosion64. Beam and direct-hit records are untouched.
local VERSION = '0.1.0-native-verified-demolition40'
local GAME_SHA256 = '2e2c3b7c2500646dadd5f2b4c6e0504dbb7e7896139f64cddc0d1813c718f51e'
local EXE_SHA256 = 'f5fee03dcfdb2e553a4752c283590950ac13316b376d8196aa556ff0400d5f06'
local NAME = 'LAS22ShearOverheatDemolition40'
local previous = rawget(_G, NAME)
if previous then return previous end
local public = {version = VERSION, status = 'initializing', game_memory_writes = 0}
rawset(_G, NAME, public)
local loader = rawget(_G, 'CowboyBingusModLoader')
local log
if type(loader) == 'table' and type(loader.open_log) == 'function' then
    local ok, handle = pcall(loader.open_log, 'LAS22ShearOverheatDemolition40.log')
    if ok then log = handle end
end
local function emit(message)
    local line = '[' .. NAME .. '] ' .. message
    pcall(print, line)
    if log then pcall(function() log:write(line .. '\n'); log:flush() end) end
end
local function close_log()
    if log then pcall(function() log:close() end); log = nil end
end
local function finish(message)
    public.status = 'disabled'
    emit(message)
    close_log()
end
emit('START version=' .. VERSION .. ' DEMOLITION=40 BEAM_WRITE=OFF DIRECT_HIT_WRITE=OFF HD2RUNTIME=NOT_REQUIRED CAPTURE=OFF')
emit('SCOPE ability2861->projectile273->explosion64->damage387; standard_overheat_projectile5_shares_explosion64')
if type(loader) ~= 'table' or loader.api ~= 1 or (loader.version or 0) < 16 then
    finish('DISABLED reason=compatible_Shared_Loader_API1_required'); return public
end
if type(rawget(_G, 'update')) ~= 'function' then
    finish('DISABLED reason=update_callback_unavailable'); return public
end

local ok_ffi, ffi = pcall(require, 'ffi')
if not ok_ffi or ffi.os ~= 'Windows' or not ffi.abi('64bit') then
    finish('disabled: Windows x64 LuaJIT FFI required')
    return public
end
ffi.cdef [[
    void *GetModuleHandleA(const char *);
    uint32_t GetModuleFileNameW(void *, uint16_t *, uint32_t);
    void *GetCurrentProcess(void);
    int ReadProcessMemory(void *, const void *, void *, size_t, size_t *);
    size_t VirtualQuery(const void *, void *, size_t);
    void *CreateFileW(const uint16_t *, uint32_t, uint32_t, void *, uint32_t, uint32_t, void *);
    int ReadFile(void *, void *, uint32_t, uint32_t *, void *);
    int CloseHandle(void *);
    int32_t BCryptOpenAlgorithmProvider(void **, const uint16_t *, const uint16_t *, uint32_t);
    int32_t BCryptCreateHash(void *, void **, void *, uint32_t, const void *, uint32_t, uint32_t);
    int32_t BCryptHashData(void *, const void *, uint32_t, uint32_t);
    int32_t BCryptFinishHash(void *, void *, uint32_t, uint32_t);
    int32_t BCryptDestroyHash(void *);
    int32_t BCryptCloseAlgorithmProvider(void *, uint32_t);
]]
local k, bcrypt = ffi.load('kernel32'), ffi.load('bcrypt')
local process = k.GetCurrentProcess()
local function read(address, length)
    if type(address) ~= 'number' or address < 65536 or address + length >= 0x800000000000
        or length < 1 or length > 1024 * 1024 then return nil end
    local out, count = ffi.new('uint8_t[?]', length), ffi.new('size_t[1]')
    if k.ReadProcessMemory(process, ffi.cast('const void *', address), out, length, count) == 0
        or tonumber(count[0]) ~= length then return nil end
    return ffi.string(out, length)
end
local function u32(bytes, offset)
    local a, b, c, d = bytes:byte(offset + 1, offset + 4)
    if not d then return nil end
    return a + b * 256 + c * 65536 + d * 16777216
end
local function u64at(bytes, offset)
    local p = ffi.new('uint64_t[1]')
    ffi.copy(p, bytes:sub(offset + 1, offset + 8), 8)
    return tonumber(p[0])
end
local function f32(bytes, offset)
    if #bytes < offset + 4 then return nil end
    local n = ffi.new('union { uint32_t bits; float value; }')
    n.bits = u32(bytes, offset)
    return tonumber(n.value)
end
local function sha256_of_module(module)
    local path = ffi.new('uint16_t[32768]')
    local n = tonumber(k.GetModuleFileNameW(ffi.cast('void *', module), path, 32768))
    assert(n > 0 and n < 32768, 'module_path_unavailable')
    local file = k.CreateFileW(path, 0x80000000, 7, nil, 3, 0x08000000, nil)
    assert(file ~= ffi.cast('void *', -1), 'module_file_unavailable')
    local algorithm, hash = ffi.new('void *[1]'), ffi.new('void *[1]')
    local ok, result = pcall(function()
        local name = ffi.new('uint16_t[7]', {83, 72, 65, 50, 53, 54, 0})
        assert(bcrypt.BCryptOpenAlgorithmProvider(algorithm, name, nil, 0) == 0, 'sha256_provider')
        assert(bcrypt.BCryptCreateHash(algorithm[0], hash, nil, 0, nil, 0, 0) == 0, 'sha256_create')
        local chunk, count = ffi.new('uint8_t[65536]'), ffi.new('uint32_t[1]')
        local total = 0
        while true do
            assert(k.ReadFile(file, chunk, 65536, count, nil) ~= 0, 'module_file_read')
            if count[0] == 0 then break end
            total = total + tonumber(count[0])
            assert(total <= 64 * 1024 * 1024, 'module_file_size_limit')
            assert(bcrypt.BCryptHashData(hash[0], chunk, count[0], 0) == 0, 'sha256_update')
        end
        local digest, parts = ffi.new('uint8_t[32]'), {}
        assert(bcrypt.BCryptFinishHash(hash[0], digest, 32, 0) == 0, 'sha256_finish')
        for i = 0, 31 do parts[#parts + 1] = string.format('%02x', digest[i]) end
        return table.concat(parts)
    end)
    if hash[0] ~= nil then bcrypt.BCryptDestroyHash(hash[0]) end
    if algorithm[0] ~= nil then bcrypt.BCryptCloseAlgorithmProvider(algorithm[0], 0) end
    k.CloseHandle(file)
    assert(ok, result)
    return result
end


ffi.cdef [[
    uint64_t GetTickCount64(void);
    int WriteProcessMemory(void *, void *, const void *, size_t, size_t *);
    int VirtualProtect(void *, size_t, uint32_t, uint32_t *);
    uint32_t GetLastError(void);
]]
local function now() return tonumber(k.GetTickCount64()) / 1000 end
local function pointer(address)
    local bytes = read(address, 8)
    if not bytes then return nil end
    local p = u64at(bytes, 0)
    if p >= 65536 and p < 0x800000000000 and p % 4 == 0 then return p end
end
local function region(address)
    local info = ffi.new('uint8_t[48]')
    if tonumber(k.VirtualQuery(ffi.cast('const void *', address), info, 48)) ~= 48 then return nil end
    local bytes = ffi.string(info, 48)
    return u64at(bytes, 0), u64at(bytes, 24), u32(bytes, 32), u32(bytes, 36)
end
-- Only a four-byte data field can be written. Never make code pages writable.
local function write_field(address, expected, replacement)
    if #expected ~= 4 or #replacement ~= 4 or read(address, 4) ~= expected then return false end
    local start, size, state, protection = region(address)
    if not start or state ~= 0x1000 or address < start or address + 4 > start + size
        or (protection ~= 0x02 and protection ~= 0x04) then return false end
    local at = ffi.cast('void *', address)
    local old, unused = ffi.new('uint32_t[1]'), ffi.new('uint32_t[1]')
    local changed = protection == 0x02
    if changed and k.VirtualProtect(at, 4, 0x04, old) == 0 then return false end
    local ok, written = pcall(function()
        if changed and tonumber(old[0]) ~= protection then return false end
        if read(address, 4) ~= expected then return false end
        local count = ffi.new('size_t[1]')
        return k.WriteProcessMemory(process, at, replacement, 4, count) ~= 0
            and tonumber(count[0]) == 4 and read(address, 4) == replacement
    end)
    local restored = true
    if changed then
        restored = k.VirtualProtect(at, 4, old[0], unused) ~= 0
        if not restored then restored = k.VirtualProtect(at, 4, old[0], unused) ~= 0 end
    end
    if not restored then emit('PAGE_PROTECTION_RESTORE_FAILED address=' .. string.format('%#x', address)) end
    return ok and written and restored
end
local game_handle = k.GetModuleHandleA('game.dll')
if game_handle == nil then finish('DISABLED reason=game_dll_unavailable'); return public end
local game = tonumber(ffi.cast('uintptr_t', game_handle))
local hash_ok, hash = pcall(sha256_of_module, game)
if not hash_ok or hash ~= GAME_SHA256 then
    finish('DISABLED reason=game_dll_hash_guard actual=' .. tostring(hash)); return public
end
local exe_ok, exe_hash = pcall(sha256_of_module, k.GetModuleHandleA(nil))
if not exe_ok or exe_hash ~= EXE_SHA256 then
    finish('DISABLED reason=exe_hash_guard actual=' .. tostring(exe_hash)); return public
end
emit('HASH_VERIFIED build=25480438 loader_version=' .. tostring(loader.version))

local function unhex(s)
    return (s:gsub('%x%x', function(pair) return string.char(tonumber(pair, 16)) end))
end
local function replace_bytes(bytes, offset, replacement)
    return bytes:sub(1, offset) .. replacement .. bytes:sub(offset + #replacement + 1)
end
local DAMAGE_TABLE_RVA = 0x37c60c0
local PROJECTILE_TABLE_RVA = 0x37c7670
local EXPLOSION_TABLE_RVA = 0x37cc920
local DAMAGE_TYPE, DAMAGE_SIZE, DEMOLITION_OFFSET = 387, 76, 28
local DAMAGE_EXPECTED = unhex('830100002c0100002c01000003000000000000000000000000000000140000001e00000014000000000000000000000000000000000000000000000000000000000000000000000000000000')
local PROJECTILE_EXPECTED = unhex('1101000080147b993e84daef6952cdf1f5c84b7d5898656a00002041010000000000fa44000040410000000000000000010000000000c04000000000820100000000803e00000000c5168eb39bd86d6800000000000000000000004000000000000000000000000000000000000000000b20f525c300fc91000000000000000000000000000000000000a042010000004000000000000000000000000000000000000000cdcccc3d0b0000000b0000000000000000000000000070420000403f0000404000007041491ca4a1000000000000000000000000000080bf0000000000000000000000000100000000000000790000000200000018953d390000000000000000000000000000000000000000')
local EXPLOSION_EXPECTED = unhex('40000000830100000000000000000000000000400000804000004040000000000000c8410000000030ff0000000000000100000000000000c367401a661a99b5876149d3040000001e0000000000000000000000000000000f000000020000000000000000000000000000000000000000000000050000000000000002000000000000000000000000000042030000000000000000000000')
local SHAKE_EXPECTED = unhex('369955a9736f4b50')
local BEFORE, AFTER = string.char(20, 0, 0, 0), string.char(40, 0, 0, 0)
local DAMAGE_AFTER = replace_bytes(DAMAGE_EXPECTED, DEMOLITION_OFFSET, AFTER)
local NATIVE_GUARDS = {
    {rva=0x763c80, bytes=unhex('458bb548020000'), label='heat_overheat_ability_offset_0x248'},
    {rva=0x763ee6, bytes=unhex('458bc6488bcbf30f114424208b5008e846700600'), label='heat_passes_ability_to_native_activation'},
    {rva=0x11509e7, bytes=unhex('ffca81fa320b00000f8784bd00004c8d1504f6eafe418b949284c715014903d2ffe2'), label='generated_ability_dispatch_id_minus_one'},
    {rva=0x115f434, bytes=unhex('07c71501'), label='ability2861_case_slot'},
    {rva=0x115c707, bytes=unhex('418bd0e8f139ffff440fb6c84883c428c3'), label='ability2861_handler_call'},
    {rva=0x115017b, bytes=unhex('ba1101000041b8bf0a5257e8f5e00400'), label='rapid_overheat_requests_projectile273'},
    {rva=0x119e5e0, bytes=unhex('8b55ab894dcf8b4da78b4008894d9f488b0db2e82d0248c744243000000000895c242889442420f20f1145c7f2440f114d97e839a92000'), label='fire_helper_passes_type_to_projectile_request'},
    {rva=0x13a9715, bytes=unhex('488d0d54df41024a8b0cf9'), label='native_projectile_type_pointer_table'},
    {rva=0x13aa642, bytes=unhex('498b46108b8890000000894f7c'), label='projectile_impact_explosion_to_instance'},
    {rva=0x13b0736, bytes=unhex('8bb40fbcd00400'), label='impact_explosion_reads_instance_type'},
    {rva=0x13b0788, bytes=unhex('8bc64c8d258fc141024d8b24c4'), label='native_explosion_type_pointer_table'},
    {rva=0x13b09ab, bytes=unhex('448bc64c89'), label='impact_explosion_argument_from_instance'},
    {rva=0x13b0a00, bytes=unhex('e87b000100'), label='native_explosion_request_call'},
}
local damage_slot = game + DAMAGE_TABLE_RVA + DAMAGE_TYPE * 8
local native_verified, lease, next_due, last_wait = false, nil, 0, nil
local started = now()

local function native_ready()
    for _, guard in ipairs(NATIVE_GUARDS) do
        if read(game + guard.rva, #guard.bytes) ~= guard.bytes then return false, guard.label end
    end
    return true
end
local function valid_explosion(row)
    if not row or #row ~= 152 then return false, 'explosion64_unreadable' end
    -- Normalize only the documented DLArray pointer; never write this pointer.
    local normalized = replace_bytes(row, 40, EXPLOSION_EXPECTED:sub(41, 48))
    if normalized ~= EXPLOSION_EXPECTED then return false, 'explosion64_record_mismatch' end
    local p = u64at(row, 40)
    if u32(row, 48) ~= 1 or p < 65536 or p >= 0x800000000000 or p % 4 ~= 0
        or read(p, 8) ~= SHAKE_EXPECTED then return false, 'explosion64_shake_array_guard' end
    return true
end
local function settings_context()
    local projectile = pointer(game + PROJECTILE_TABLE_RVA + 273 * 8)
    local explosion = pointer(game + EXPLOSION_TABLE_RVA + 64 * 8)
    local damage = pointer(damage_slot)
    if not projectile or not explosion or not damage then return nil, 'settings_not_resident' end
    local p, e, d = read(projectile, 272), read(explosion, 152), read(damage, DAMAGE_SIZE)
    if not p or not e or not d then return nil, 'records_not_readable' end
    if p ~= PROJECTILE_EXPECTED then return false, 'projectile273_record_mismatch' end
    local exp_ok, why = valid_explosion(e)
    if not exp_ok then return false, why end
    if d ~= DAMAGE_EXPECTED and d ~= DAMAGE_AFTER then return false, 'damage387_record_mismatch' end
    return {projectile = projectile, explosion = explosion, damage = damage, damage_row = d}
end
local function current_context_matches(context)
    return pointer(game + PROJECTILE_TABLE_RVA + 273 * 8) == context.projectile
        and pointer(game + EXPLOSION_TABLE_RVA + 64 * 8) == context.explosion
        and pointer(damage_slot) == context.damage
end
local function restore(reason)
    local item = lease
    if not item then return true end
    -- A replaced slot no longer owns this address. Do not touch freed/reused memory.
    if pointer(damage_slot) ~= item.damage then
        lease = nil
        emit('LEASE_RETIRED reason=' .. reason .. ' slot_replaced no_stale_write')
        return true
    end
    local row = read(item.damage, DAMAGE_SIZE)
    if row == DAMAGE_EXPECTED then
        lease = nil; emit('LEASE_RESTORED reason=' .. reason .. ' already_original'); return true
    end
    if row ~= DAMAGE_AFTER then
        lease = nil
        emit('LEASE_RESTORE_SKIPPED reason=' .. reason .. ' record_changed_by_other_writer')
        return true
    end
    if write_field(item.damage + DEMOLITION_OFFSET, AFTER, BEFORE)
        and read(item.damage, DAMAGE_SIZE) == DAMAGE_EXPECTED then
        public.game_memory_writes = public.game_memory_writes + 1
        lease = nil
        emit('LEASE_RESTORED reason=' .. reason .. ' damage_type=387 demolition=20')
        return true
    end
    emit('LEASE_RESTORE_FAILED reason=' .. reason .. ' damage_type=387')
    return false
end
local function disable(reason)
    restore('disable')
    finish('DISABLED reason=' .. reason)
end
local function apply(context)
    -- Revalidate the entire context immediately before claiming the one field.
    local again, why = settings_context()
    if not again or not current_context_matches(context) or again.damage ~= context.damage then
        disable('context_changed_before_write:' .. tostring(why)); return
    end
    if again.damage_row == DAMAGE_AFTER then
        public.status = 'already_applied_external'
        emit('ALREADY_APPLIED_EXTERNAL damage_type=387 demolition=40 lease_owned=NO')
        return
    end
    lease = context -- Record ownership BEFORE attempting the transaction.
    local ok = write_field(context.damage + DEMOLITION_OFFSET, BEFORE, AFTER)
    if not ok or pointer(damage_slot) ~= context.damage or read(context.damage, DAMAGE_SIZE) ~= DAMAGE_AFTER then
        disable('write_or_full_record_readback_failed'); return
    end
    public.game_memory_writes = public.game_memory_writes + 1
    public.status = 'applied'
    emit('APPLIED_READBACK_OK ability=2861 projectile=273 explosion=64 damage_type=387 demolition=20->40'
        .. ' explosion_damage=300/300 direct_damage=1200/1200 write_bytes=4 BEAM_UNCHANGED=YES'
        .. ' STANDARD_OVERHEAT_SHARED=YES gameplay=UNVERIFIED')
end
local function tick()
    if public.status == 'disabled' or public.status == 'shutdown' then return end
    local time = now()
    if time < next_due then return end
    next_due = time + 2.0
    if not native_verified then
        local ready, why = native_ready()
        if not ready then
            if time - started > 120 then disable('native_code_guard_timeout:' .. tostring(why)); return end
            if last_wait ~= why then emit('WAITING_FOR_NATIVE guard=' .. tostring(why)); last_wait = why end
            return
        end
        native_verified = true
        emit('NATIVE_CHAIN_VERIFIED ability2861->projectile273->explosion64->damage387')
    end
    local context, why = settings_context()
    if context == false then disable(why); return end
    if not context then
        if lease then restore('settings_unavailable') end
        if time - started > 120 then disable(why); return end
        if last_wait ~= why then emit('WAITING_FOR_SETTINGS reason=' .. tostring(why)); last_wait = why end
        return
    end
    if lease and lease.damage ~= context.damage then restore('settings_replaced') end
    if lease then
        if context.damage_row ~= DAMAGE_AFTER then disable('demolition_changed_by_other_writer') end
        return
    end
    if public.status == 'already_applied_external' and context.damage_row == DAMAGE_AFTER then return end
    apply(context)
end
local original_update = rawget(_G, 'update')
update = function(...)
    local result = original_update(...)
    local ok, why = pcall(tick)
    if not ok then disable('runtime_exception:' .. tostring(why)) end
    return result
end
local original_shutdown = rawget(_G, 'shutdown')
shutdown = function(...)
    local ok, restored = pcall(restore, 'shutdown')
    if not ok or not restored then emit('SHUTDOWN_RESTORE_INCOMPLETE') end
    public.status = 'shutdown'
    close_log()
    if type(original_shutdown) == 'function' then return original_shutdown(...) end
end
return public
