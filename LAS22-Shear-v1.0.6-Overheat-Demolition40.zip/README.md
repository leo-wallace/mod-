# LAS-22 切变 v1.0.6：末次过热爆炸40拆毁

修改已经确认的伤害记录：快速过热 ability2861 → Projectile273 → Explosion64 → DamageInfo387。
新增组件只把 DamageInfo387 的 demolition_strength 从20写为40（4字节）。
爆炸伤害仍300/300，快速过热末次弹体直击仍1200/1200，光束、穿甲、爆炸范围、弹药不变。
原 v1.0.4 两个功能补丁逐字节保留，包括解锁、改装和散热器模型资源持有。
不需要 HD2Runtime；只依赖原包已经使用的 Bingus Shared Loader v18 / API1。
适用 Steam build25480438 / game.dll SHA256 2e2c3b7c2500646dadd5f2b4c6e0504dbb7e7896139f64cddc0d1813c718f51e。

## 共用范围

普通散热器 ability2860 发射 Projectile5，也引用 Explosion64。
所以普通和快速过热散热器的最后爆炸都会变成40拆毁。这不是按玩家/模式隔离的修改。
这两个弹体的直击拆毁值没有修改。原先猜测的 Explosion62 / Damage646 不修改。

## 安装

退出游戏，在管理器停用旧切变版本（包括v1.0.5采集版），仅启用本包，重新部署。
保留 Bingus Shared Loader。不要同时启用多个切变包。
本包不再生成 LAS22ShearNativeCapture.bin；旧采集文件无须重新上传。

## 测试与日志

装快速过热散热器，分别测试未过热光束与过热后的最后爆炸对建筑/巢口的表现。
注意40拆毁值不保证所有建筑均可摧毁；最终还受爆炸位置、碰撞/射线检测等原生规则影响。
建议分别用末次弹体直接命中与贴近爆炸测试。判定生效请看新日志，而不是旧探针日志。

Win+R 打开：%LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs
新增日志：LAS22ShearOverheatDemolition40.log
APPLIED_READBACK_OK ... demolition=20->40 表示内存写入并完整回读成功。
NATIVE_CHAIN_VERIFIED 只表示路径核对成功，不能单独证明数值写入成功。
DISABLED / RECORD_MISMATCH 或没有新日志时，附本次新日志与 BingusSharedLoader.log。

## 写入保护与恢复

双模块哈希、13个短原生路径指纹、完整弹体/爆炸/伤害记录共同验证后才写一个4字节字段。
Explosion64 的 DLArray 重定位指针只读归一化，单独核验其数量和实际震屏资源ID。
不调用游戏原生函数、不修改代码、不增加实体扫描、状态/血量探针或大段采集。
每2秒只核对直接类型指针槽及这三条短记录，不逐帧扫描。
脚本 shutdown/错误时仅在本组件仍拥有相同记录且其他字段没改变时恢复20，避免覆盖其他MOD。
正常退出后修改不会写回游戏文件；停用本包并重新部署原v1.0.4即可恢复。

## 验证范围

原生调用链已经通过此次运行时代码采集离线确认；40拆毁的游戏实战效果尚未测试。
Validation/native-overheat-mapping.json 保留路径与指令证据。
Source/las22_shear_overheat_demolition40.lua 与新增patch2中的源码一致。
