local key='CodexFireDogTimedRotation'
if rawget(_G,key) then return rawget(_G,key)end
local M={version='0.1.3-045-owner-dedup-loaderfix',status='starting',disabled=false}
rawset(_G,key,M)
local loader=rawget(_G,'CowboyBingusModLoader')
local previous_update=rawget(_G,'update')
if type(loader)~='table' or loader.api~=1                                                       
    or type(loader.open_log)~='function' or type(previous_update)~='function' then
    M.disabled=true;M.status='requires_Shared_Loader_v17_API1'
    print('[FireDogRotation] '..M.status);return M
end
local api,game,log,native,snapshot,controller
local function emit(message)
    local line=os.date('!%Y-%m-%dT%H:%M:%SZ')..' '..message
    if log then assert(log:write(line..'\n'));assert(log:flush())end
    print('[FireDogRotation] '..message)
    M.status=message
end
local ok,why=pcall(function()
    log=assert(loader.open_log('FireDogRotation.log'),'log_unavailable')
    emit('START version='..M.version..' build=25480438 mode=ROTATION_045_OWNER_DEDUP_LOADERFIX gameplay=UNVERIFIED')
    emit('POLICY lock_seconds=0.45 candidate_lease_seconds=0.25 result_window_seconds=0.80 scope=HotDog188 timer_basis=NATIVE_LOCK_NOT_HIT')
    emit('STATUS_PROBE=REMOVED IDENTITY_TRACE=TARGET_CHANGE_ONLY DISCOVERY=DIRECT_BEHAVIOR188_OWNER_DEDUP damage=UNCHANGED burning=UNCHANGED enemy_health=UNCHANGED health=UNCHANGED')
    api=WindowsRead()
    game=assert(api.module('game.dll'),'game_dll_missing')
    assert(api.module_hash(game):lower()==SPEC.game_sha256,'unsupported_game_dll_no_write')
    emit('GAME_HASH_VERIFIED')
    local raw_read=api.read
    api.read=function(address,size)
        if type(address)~='number' or address%1~=0 or type(size)~='number' or size%1~=0
            or address<65536 or address+size>=0x800000000000 or size<=0 or size>16384 then return nil end
        local parts={}
        for i=0,size-1,2048 do
            local b=raw_read(address+i,math.min(2048,size-i))
            if not b then return nil end
            parts[#parts+1]=b
        end
        return table.concat(parts)
    end
    api.compare_write=MakeWriter(api)
    local reader=DirectFireDogSnapshotFactoryRuntime.new()
    -- Only the native reader is exposed by the modified factory; the reference
    -- installer and aim/fire/selection writers are never created or executed.
    assert(type(reader)=='table' and type(reader.snapshot)=='function','snapshot_factory_invalid')
    local dog_key=string.char(0xc6,0x1f,0x8d,0xd4,0xc6,0x9b,0x9e,0x97)
    reader.profiles[dog_key]={name='HotDog',behavior=188}
    local count=0
    for resource,p in pairs(reader.profiles)do
        if p.behavior~=188 then reader.profiles[resource]=nil
        else count=count+1;assert(p.name=='HotDog','fire_dog_profile_changed')end
    end
    assert(count==1,'fire_dog_profile_missing')
    snapshot=reader.snapshot
    native=Native.new(api,game)
    controller=Controller.new(api,native,emit,{dwell=0.45,lease=0.25,result_window=0.8})
    M.controller=controller
    emit('READY waiting_for_local_fire_dog RETARGET_RESULT=NOT_YET_OBSERVED DISCOVERY=DIRECT_BEHAVIOR188_OWNER_DEDUP STATUS_PROBE=OFF IDENTITY_TRACE=ON HEALTH=UNCHANGED')
end)
if not ok then
    M.disabled=true;pcall(emit,'STARTUP_FAILED_NO_WRITE '..tostring(why))
    if log then pcall(function()log:close()end)end
    return M
end
local next_tick,next_summary=0,0
local snapshot_failures=0
local last_snapshot_error
local function tick()
    local now=api.time()
    controller.expire(now)
    if M.disabled then return end
    if controller.disabled then
        M.disabled=true;controller.stop('controller_disabled')
        emit('DISABLED inspect_log');return
    end
    if now<next_tick then return end
    next_tick=now+0.05
    local good,rows,state=pcall(snapshot,api,game)
    if not good then
        snapshot_failures=snapshot_failures+1
        if rows~=last_snapshot_error or snapshot_failures==1 or snapshot_failures%100==0 then
            emit('SNAPSHOT_UNAVAILABLE no_request count='..snapshot_failures..' reason='..tostring(rows))
            last_snapshot_error=rows
        end
        -- Mission transitions can temporarily invalidate the registry. Release
        -- only still-owned bytes; let a fresh snapshot discover new instances.
        controller.step({},now)
    else
        snapshot_failures=0;last_snapshot_error=nil
        controller.step(rows,now)
        if now>=next_summary then
            next_summary=now+10
            emit(string.format('SUMMARY local_fire_dogs=%d requests=%d confirmed_changes=%d timeouts=%d behavior_slot_switches=%d health_boosts=%d state=%s',
                #rows,controller.requests,controller.changes,controller.timeouts,controller.behavior_switches or 0,0,tostring(state)))
        end
    end
end
update=function(...)
    local success,err=pcall(tick)
    if not success then
        M.disabled=true;pcall(controller.stop,'runtime_error')
        pcall(emit,'RUNTIME_DISABLED '..tostring(err))
    end
    return previous_update(...)
end
local previous_shutdown=rawget(_G,'shutdown')
shutdown=function(...)
    M.disabled=true
    local cleanup_ok,clean=pcall(controller.stop,'shutdown')
    pcall(emit,string.format('SHUTDOWN requests=%d confirmed_changes=%d timeouts=%d health_boosts=%d cleanup_ok=%s',
        controller.requests,controller.changes,controller.timeouts,0,tostring(cleanup_ok and clean)))
    if log then pcall(function()log:close()end);log=nil end
    if type(previous_shutdown)=='function' then return previous_shutdown(...)end
end
return M
