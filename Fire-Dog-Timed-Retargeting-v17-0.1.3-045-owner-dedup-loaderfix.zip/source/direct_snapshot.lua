-- Direct BehaviorComponent enumerator for AX/FLAM-75 Hot Dog.
-- v0.1.3: duplicate behavior=188 rows that belong to the same perception owner
-- are collapsed to one stable row before the controller sees them.
local DirectFireDogSnapshotFactory={}
function DirectFireDogSnapshotFactory.new()
    local ffi,bit=require('ffi'),require('bit')
    local R={profiles={}}
    local function scalar(t,b,o,n)
        o=o or 0
        if type(b)~='string' or #b<o+n then return nil end
        local v=ffi.new(t..'[1]');ffi.copy(v,b:sub(o+1,o+n),n);return tonumber(v[0])
    end
    local function u32(b,o)return scalar('uint32_t',b,o,4)end
    local function ptr(api,address)
        local b=api.read(address,8);if not b then return nil end
        return api.pointer(b)
    end
    local function hex64le(b)
        if type(b)~='string' or #b<8 then return '0000000000000000' end
        local t={};for i=8,1,-1 do t[#t+1]=string.format('%02x',b:byte(i))end
        return table.concat(t)
    end
    local function better(a,b)
        if not b then return true end
        -- Prefer a record that currently carries a real target.  If both have
        -- the same activity state, keep the lowest record address so the
        -- selected runtime row is deterministic across snapshots.
        if a.has~=b.has then return a.has end
        return a.behavior_address<b.behavior_address
    end
    function R.snapshot(api,game)
        local raw_rows={}
        local root=ptr(api,game+53634880)
        if not root then return {},'behavior_root_unavailable' end
        local countb=api.read(root+32,4)
        local count=u32(countb or '',0)
        if not count then return {},'behavior_count_unavailable' end
        if count<0 or count>8192 then error('behavior_count_bound_'..tostring(count))end
        local entities=ptr(api,root+88)
        local records=ptr(api,root+96)
        if not entities or not records then return {},'behavior_arrays_unavailable' end
        local stride=504
        local behavior188=0
        for i=0,count-1 do
            local ep=ptr(api,entities+i*8)
            if ep then
                local key=api.read(ep,24)
                local b=api.read(records+i*stride,160)
                if key and b and u32(b,0)==188 then
                    behavior188=behavior188+1
                    local id=u32(key,8) or 0
                    local node=u32(b,8) or 0
                    local target=u32(b,24) or 0
                    local owner=u32(b,104) or id
                    local authority=api.read(ep+20,1)
                    local local_authority=authority and bit.band(authority:byte(),3)==1
                    if local_authority and id>0 and id<4294967295 then
                        local valid_target=target>0 and target<4294967295
                        local resource=key:sub(1,8)
                        raw_rows[#raw_rows+1]={
                            profile='HotDog',id=id,key=key:sub(1,20),entity=ep,
                            behavior_address=records+i*stride,authority_address=ep+20,
                            perception_owner=(owner>0 and owner<4294967295) and owner or id,
                            node=node,target=target,runtime_target=target,
                            source_flags=valid_target and 1 or 0,has=valid_target,enabled=true,
                            resource_hex=hex64le(resource),resource_expected=R.profiles[resource]~=nil,
                            guards={
                                {address=ep,bytes=key:sub(1,20)},
                                {address=records+i*stride,bytes=b:sub(1,4)},
                                {address=records+i*stride+104,bytes=b:sub(105,108)},
                                {address=ep+20,bytes=authority}
                            },
                            transition_guards={
                                {address=records+i*stride+8,bytes=b:sub(9,12)},
                                {address=records+i*stride+24,bytes=b:sub(25,28)}
                            }
                        }
                    end
                end
            end
        end
        local by_owner={}
        for _,row in ipairs(raw_rows)do
            local stable=row.perception_owner or row.id
            local old=by_owner[stable]
            if better(row,old) then by_owner[stable]=row end
        end
        local rows={}
        for _,row in pairs(by_owner)do rows[#rows+1]=row end
        table.sort(rows,function(a,b)
            local ao=a.perception_owner or a.id
            local bo=b.perception_owner or b.id
            if ao==bo then return a.behavior_address<b.behavior_address end
            return ao<bo
        end)
        local state
        if #rows>0 then
            state=string.format('behavior188_local_raw=%d deduped=%d',#raw_rows,#rows)
        else
            state='behavior188_seen='..behavior188..' behavior_count='..count
        end
        return rows,state
    end
    return R
end
return DirectFireDogSnapshotFactory
