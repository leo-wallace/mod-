-- Per-instance native data access. No game function pointers or status writes.
-- Candidate layout follows the user-supplied RoverFireSpread 0.7.14 reader.
-- Targeting/behavior/clock/faction roots also match SentryAimRetention data-v8.5.
local Native = {}
function Native.new(api, game)
    local ffi, bit = require('ffi'), require('bit')
    local N = {}
    local ZERO4 = string.rep('\0', 4)
    local HOT_DOG = string.char(0xc6,0x1f,0x8d,0xd4,0xc6,0x9b,0x9e,0x97)
    local function read(a,n)
        local b=api.read(a,n)
        assert(type(b)=='string' and #b==n,'native_read_unavailable')
        return b
    end
    local function scalar(t,b,o,n)
        o=o or 0
        assert(type(b)=='string' and #b>=o+n,'short_scalar')
        local v=ffi.new(t..'[1]');ffi.copy(v,b:sub(o+1,o+n),n)
        return tonumber(v[0])
    end
    local function u32(b,o)return scalar('uint32_t',b,o,4)end
    local function u64(b,o)return scalar('uint64_t',b,o,8)end
    local function f32(b,o)return scalar('float',b,o,4)end
    local function word64(n)
        assert(n>=0 and n<9007199254740991 and n%1==0,'invalid_tick')
        return ffi.string(ffi.new('uint64_t[1]',n),8)
    end
    local function add(g,a,b)g[#g+1]={address=a,bytes=b};return b end
    local function copy(g)
        local h={};for _,x in ipairs(g or {})do h[#h+1]=x end;return h
    end
    local function extend(g,h)for _,x in ipairs(h or {})do g[#g+1]=x end end
    local function pointer(a,g)
        local b=read(a,8);local p=assert(api.pointer(b),'native_pointer_unavailable')
        add(g,a,b);return p
    end
    function N.matches(g)
        for _,x in ipairs(g or {})do
            if api.read(x.address,#x.bytes)~=x.bytes then return false end
        end
        return true
    end
    -- Bounded open-addressing entity map; multiplication must retain uint64 bits.
    local function lookup(a,id,limit,g)
        local b=read(a,20)
        local cap,empty,mult=u32(b,8),u32(b,12),u32(b,16)
        if cap==0 then return nil end
        assert(cap<=limit and bit.band(cap,cap-1)==0,'entity_map_bound')
        local p=assert(api.pointer(b:sub(1,8)),'entity_map_pointer')
        local hash=tonumber(ffi.cast('uint32_t',ffi.new('uint64_t',id)*ffi.new('uint64_t',mult)))
        for i=0,math.min(cap,128)-1 do
            local at=p+bit.band(hash+i,cap-1)*8
            local row=read(at,8);local key=u32(row)
            if key==id then
                add(g,a,b);add(g,at,row)
                local index=u32(row,4)
                if index~=4294967295 then return index end
                return nil
            end
            if key==empty then return nil end
        end
        error('entity_map_probe_bound')
    end

    -- Low-overhead identity trace for unit-class comparison. This performs one
    -- bounded faction lookup when a newly engaged target ID is first observed.
    -- It does NOT scan components or status containers.
    local function hex64le(b)
        local t={}
        for i=8,1,-1 do t[#t+1]=string.format('%02x',b:byte(i)) end
        return table.concat(t)
    end
    function N.enemy_identity(id)
        assert(type(id)=='number' and id>0 and id<4294967295,'invalid_enemy_id')
        local g={}
        local faction=pointer(game+53636280,g)
        local i=lookup(faction+73808,id,131072,g)
        if i==nil then return nil end
        assert(i<16384,'faction_index_bound')
        local array=pointer(faction+73832,g)
        local entity=pointer(array+i*8,g)
        local key=read(entity,20)
        assert(u32(key,8)==id,'enemy_entity_mismatch')
        return {
            entity=entity,
            hash_hex=hex64le(key:sub(1,8)),
            meta=u32(key,12),
            slot=u32(key,16)
        }
    end
    function N.engaged(s)
        return s.profile=='HotDog' and s.enabled==true and s.has==true
            and s.target~=0 and s.target~=4294967295 and s.runtime_target==s.target
            and bit.band(s.source_flags or 0,1)~=0
    end
    function N.prepare(s)
        assert(s.profile=='HotDog','wrong_fire_dog_type')
        local identity=copy(s.guards)
        local b=read(s.behavior_address,160)
        assert(u32(b)==188,'wrong_fire_dog_behavior')
        assert(u32(b,24)==s.target and u32(b,8)==s.node,'target_changed_during_read')
        local owner=u32(b,104)
        local expected_owner=s.perception_owner or s.id
        assert(owner==expected_owner,'perception_owner_changed_'..tostring(owner)..'_'..tostring(expected_owner))
        add(identity,s.behavior_address,b:sub(1,4))
        add(identity,s.behavior_address+104,b:sub(105,108))
        local authority=read(s.authority_address,1)
        assert(bit.band(authority:byte(),3)==1,'not_local_authority')
        add(identity,s.authority_address,authority)
        local perception=pointer(game+53634376,identity)
        local pi=assert(lookup(perception+48,owner,32768,identity),'no_perception')
        assert(pi<16384,'perception_index_bound')
        local owners=pointer(perception+72,identity)
        assert(pointer(owners+pi*8,identity)==s.entity,'perception_owner_mismatch')
        local records=pointer(perception+80,identity)
        local record=records+pi*5112
        local cache=read(record,5112)
        local preflight=copy(identity)
        local factions=u32(cache)
        assert(factions<=32,'perception_filter_bound')
        add(preflight,record,cache:sub(1,4))
        local wanted=0
        for i=0,factions-1 do
            local o=8+i*8;local f=u32(cache,o)
            assert(f<32,'perception_faction_bit_bound')
            wanted=bit.bor(wanted,bit.lshift(1,f))
            add(preflight,record+o,cache:sub(o+1,o+4))
        end
        assert(wanted~=0,'empty_perception_filter')
        local faction_guards={}
        local faction=pointer(game+53636280,faction_guards)
        local enemy_cache={}
        local function enemy(id)
            if enemy_cache[id]~=nil then return enemy_cache[id] or nil end
            local g=copy(faction_guards)
            local i=lookup(faction+73808,id,131072,g)
            if i==nil then enemy_cache[id]=false;return nil end
            assert(i<16384,'faction_index_bound')
            local array=pointer(faction+73832,g)
            local entity=pointer(array+i*8,g)
            local key=read(entity,20)
            assert(u32(key,8)==id,'candidate_entity_mismatch')
            add(g,entity,key)
            local result={key=key,guards=g}
            enemy_cache[id]=result;return result
        end
        local candidates={}
        local function candidate(o)
            local r=cache:sub(o+1,o+80);local id=u32(r)
            if id==0 or id==4294967295 then return end
            local score,flags,mask=f32(r,68),u32(r,72),u32(r,76)
            assert(score==score and math.abs(score)<100000,'invalid_candidate_score')
            local e=enemy(id)
            if not e then return end
            local g=copy(identity);extend(g,e.guards)
            add(g,record+o,r:sub(1,4))
            local c={id=id,key=e.key,address=record+o+76,before=r:sub(77,80),
                guards=g,eligible=bit.band(flags,1)~=0 and bit.band(mask,wanted)~=0 and score>0}
            function c.valid()return N.matches(g)end
            function c.eligible_now()
                if not c.valid() then return false end
                local fresh=api.read(record+o+68,12)
                if not fresh then return false end
                local score_now=f32(fresh)
                return score_now==score_now and score_now>0 and score_now<100000
                    and bit.band(u32(fresh,4),1)~=0 and bit.band(u32(fresh,8),wanted)~=0
            end
            candidates[#candidates+1]=c
        end
        for _,group in ipairs({{784,792},{2072,2080},{3360,3368}})do
            local count=u32(cache,group[1])
            assert(count<=16,'candidate_group_bound')
            add(preflight,record+group[1],cache:sub(group[1]+1,group[1]+4))
            for i=0,count-1 do candidate(group[2]+i*80)end
        end
        for _,o in ipairs({4648,4728,4808})do
            if u32(cache,o+72)~=0 then candidate(o)end
        end
        local blocked,alternates={},{}
        local current_eligible=false
        local alt_ids={}
        for _,c in ipairs(candidates)do
            if c.id==s.target then
                current_eligible=current_eligible or c.eligible
                if c.before~=ZERO4 then blocked[#blocked+1]=c end
            elseif c.eligible then
                alternates[#alternates+1]=c;alt_ids[c.id]=true
            end
        end
        if not current_eligible or #blocked==0 then return nil,'current_target_not_in_cache' end
        if #alternates==0 then return nil,'no_other_eligible_target' end
        local clock_guards={}
        local clock=pointer(game+53633864,clock_guards)
        local now_native=u64(read(clock+24,8))
        local before=b:sub(153,160);local deadline=u64(before)
        assert(now_native>0 and now_native<9007199254740991 and deadline<9007199254740991,'clock_bound')
        assert(deadline-now_native<=1000000,'unexpected_selection_deadline')
        extend(preflight,clock_guards);extend(preflight,s.transition_guards)
        local deadline_guards=copy(identity)
        extend(deadline_guards,clock_guards);extend(deadline_guards,s.transition_guards)
        local changes={}
        for _,c in ipairs(blocked)do
            changes[#changes+1]={kind='candidate',address=c.address,before=c.before,after=ZERO4,guards=c.guards}
        end
        changes[#changes+1]={kind='deadline',address=s.behavior_address+152,before=before,
            after=word64(now_native),guards=deadline_guards}
        local alt_count=0;for _ in pairs(alt_ids)do alt_count=alt_count+1 end
        local plan={changes=changes,alternatives=alt_count,slots=#blocked,deadline_us=deadline-now_native}
        function plan.valid()
            if not N.matches(preflight) then return false end
            for _,c in ipairs(blocked)do if not c.valid() then return false end end
            -- Require at least one still-eligible alternative immediately before each write.
            for _,c in ipairs(alternates)do if c.eligible_now() then return true end end
            return false
        end
        return plan
    end
    return N
end
return Native
