-- Timed native re-selection experiment, not a fear/status detector.
local Controller={}
function Controller.new(api,native,emit,options)
    local opt=options or {}
    local dwell=opt.dwell or 1.0
    local ttl=opt.lease or 0.25
    local result_window=opt.result_window or 0.8
    local C={records={},requests=0,changes=0,timeouts=0,disabled=false,identity_seen={},behavior_switches=0}
    local function log(message)pcall(emit,message)end
    local function restore(record,reason)
        local lease=record.lease
        if not lease then return true end
        local keep={};local restored,skipped,conflict=0,0,0
        for i=#lease.changes,1,-1 do
            local c=lease.changes[i]
            if not native.matches(c.guards) then
                skipped=skipped+1 -- Entity/cache slot was replaced; do not touch its successor.
            else
                local current=api.read(c.address,#c.before)
                if current==c.before then
                    -- Already restored or never written.
                elseif current==c.after then
                    local ok=api.compare_write(c.address,c.after,c.before)
                    if ok then restored=restored+1 else keep[#keep+1]=c end
                elseif current and c.partial then
                    -- A reported partial write can only be undone while every byte
                    -- still belongs to this attempted before/after pair.
                    local ours=true
                    for j=1,#current do
                        local x=current:byte(j)
                        if x~=c.before:byte(j) and x~=c.after:byte(j) then ours=false end
                    end
                    if ours then
                        if api.compare_write(c.address,current,c.before) then restored=restored+1
                        else keep[#keep+1]=c end
                    else conflict=conflict+1 end
                else
                    conflict=conflict+1 -- Native engine or another mod owns the new value.
                end
            end
        end
        if #keep>0 then lease.changes=keep else record.lease=nil end
        log(string.format('LEASE_RELEASE fire_dog=%u reason=%s restored=%d stale=%d changed=%d pending=%d',
            record.id,reason,restored,skipped,conflict,#keep))
        return #keep==0
    end
    local function notice(r,now,reason)
        if reason~=r.notice or now>=(r.notice_at or 0)+5 then
            r.notice=reason;r.notice_at=now
            log('SKIP fire_dog='..r.id..' reason='..reason)
        end
    end
    local function request(r,s,now)
        local ok,plan,why=pcall(native.prepare,s)
        if not ok then notice(r,now,'layout_or_snapshot_rejected '..tostring(plan));r.retry=now+2;return end
        if not plan then notice(r,now,why or 'no_plan');r.retry=now+0.25;return end
        if not plan.valid() then notice(r,now,'preflight_changed');r.retry=now+0.25;return end
        for _,c in ipairs(plan.changes)do
            if not native.matches(c.guards) or api.read(c.address,#c.before)~=c.before then
                notice(r,now,'write_precondition_changed');r.retry=now+0.25;return
            end
        end
        r.lease={changes={},until_time=now+ttl}
        for _,c in ipairs(plan.changes)do
            if not plan.valid() or not native.matches(c.guards) then
                if not restore(r,'precondition_changed') then C.disabled=true end
                r.retry=now+0.5;return
            end
            if c.before~=c.after then
                r.lease.changes[#r.lease.changes+1]=c
                -- Register ownership before the OS call, including partial writes/errors.
                c.partial=true
                local success,write_ok,why_write=pcall(api.compare_write,c.address,c.before,c.after)
                if not success or not write_ok then
                    C.disabled=true
                    restore(r,'write_failed')
                    log('DISABLED write_failed '..tostring(why_write or write_ok))
                    return
                end
                c.partial=false
            end
        end
        C.requests=C.requests+1;r.notice=nil
        r.pending={from=s.target,at=now,until_time=now+result_window,samples=0}
        r.retry=now+dwell
        log(string.format('ROTATE_REQUEST fire_dog=%u from=%u node=%u alternatives=%d masked_slots=%d lock_s=%.2f deadline_delta_us=%.0f request=%d',
            r.id,s.target,s.node,plan.alternatives,plan.slots,now-r.locked_since,plan.deadline_us,C.requests))
    end
    function C.expire(now)
        for _,r in pairs(C.records)do
            if r.lease and (C.disabled or now>=r.lease.until_time) then
                if not restore(r,C.disabled and 'disabled' or 'lease_timeout') then C.disabled=true end
            end
        end
    end
    function C.step(snapshots,now)
        C.expire(now)
        local seen={}
        for _,s in ipairs(snapshots)do
            if s.profile=='HotDog' then
                local stable_id=s.perception_owner or s.id
                seen[stable_id]=true
                local r=C.records[stable_id]
                if r and (r.key~=s.key or r.entity~=s.entity) then
                    if not restore(r,'entity_replaced') then C.disabled=true end
                    log('ENTITY_REPLACED fire_dog='..stable_id)
                    if r.lease then return end
                    C.records[stable_id]=nil;r=nil
                end
                if not r then
                    r={id=stable_id,key=s.key,entity=s.entity,behavior_address=s.behavior_address,target=0,
                        locked_since=now,retry=now,failures=0}
                    C.records[stable_id]=r
                    log(string.format('FIRE_DOG_FOUND fire_dog=%u behavior=188 node=%u target=%u owner=%u resource=0x%s expected_resource=%s source_flags=%u has=%s runtime_target=%u enabled=%s',
                        stable_id,s.node,s.target,s.perception_owner or 0,tostring(s.resource_hex or 'unknown'),tostring(s.resource_expected),s.source_flags,tostring(s.has),s.runtime_target,tostring(s.enabled)))
                elseif r.behavior_address~=s.behavior_address then
                    C.behavior_switches=C.behavior_switches+1
                    r.behavior_address=s.behavior_address
                end
                local engaged=native.engaged(s)
                if r.pending then
                    local p=r.pending
                    if engaged and s.target~=p.from then
                        if p.candidate==s.target then p.samples=p.samples+1
                        else p.candidate=s.target;p.samples=1 end
                        if p.samples>=2 then
                            C.changes=C.changes+1;r.failures=0
                            log(string.format('TARGET_CHANGED_AFTER_REQUEST fire_dog=%u from=%u to=%u elapsed_s=%.3f changes=%d causality=NOT_PROVEN',
                                r.id,p.from,s.target,now-p.at,C.changes))
                            r.pending=nil
                            if not restore(r,'target_changed') then C.disabled=true end
                        end
                    else p.candidate=nil;p.samples=0 end
                    if r.pending and now>=p.until_time then
                        C.timeouts=C.timeouts+1;r.failures=r.failures+1
                        log(string.format('NO_CONFIRMED_CHANGE fire_dog=%u from=%u observed=%u has=%s timeout_s=%.2f',
                            r.id,p.from,s.target,tostring(s.has),now-p.at))
                        r.pending=nil;r.retry=now+(r.failures>=3 and 5 or 1)
                        if not restore(r,'result_timeout') then C.disabled=true end
                    end
                end
                if not engaged then
                    r.locked_since=now;r.target=0
                    notice(r,now,string.format('not_engaged node=%u target=%u runtime=%u flags=%u has=%s enabled=%s',
                        s.node,s.target,s.runtime_target,s.source_flags,tostring(s.has),tostring(s.enabled)))
                elseif r.target~=s.target or (r.last_seen and now-r.last_seen>0.3) then
                    if r.target~=s.target then
                        log(string.format('LOCK_OBSERVED fire_dog=%u target=%u node=%u',r.id,s.target,s.node))
                        if not C.identity_seen[s.target] then
                            C.identity_seen[s.target]=true
                            local ok_id,ident=pcall(native.enemy_identity,s.target)
                            if ok_id and ident then
                                log(string.format('TARGET_IDENTITY target=%u hash=0x%s meta=%u slot=%u source=FACTION_ENTITY_KEY',
                                    s.target,ident.hash_hex,ident.meta,ident.slot))
                            else
                                log(string.format('TARGET_IDENTITY_UNAVAILABLE target=%u reason=%s',s.target,tostring(ident)))
                            end
                        end
                    end
                    r.target=s.target;r.locked_since=now
                end
                r.last_seen=now
                if not C.disabled and engaged and not r.pending and not r.lease
                    and now>=r.retry and now-r.locked_since>=dwell then request(r,s,now)end
            end
        end
        for id,r in pairs(C.records)do
            if not seen[id] then
                if not restore(r,'fire_dog_missing') then C.disabled=true end
                if not r.lease then
                    if r.pending then log('REQUEST_UNRESOLVED fire_dog='..id..' reason=fire_dog_missing')end
                    log('FIRE_DOG_REMOVED fire_dog='..id);C.records[id]=nil
                end
            end
        end
    end
    function C.stop(reason)
        C.disabled=true
        local all=true
        for _,r in pairs(C.records)do if not restore(r,reason or 'stop') then all=false end end
        return all
    end
    return C
end
return Controller
