Fire Dog Timed Retargeting 0.1.3

核心变化：
- 统一改为 0.45 秒重选。
- 已确认火狗 resource=0x979e9bc6d48d1fc6、behavior=188 能被运行时识别。
- 同一 perception owner 的多个 Behavior188 runtime row 先去重：有有效 target 的 active row 优先。
- behavior slot 在 active/idle 之间切换时，不再当成 ENTITY_REPLACED，也不会重置 lock timer。
- 不改伤害、燃烧、状态、弹药或生命值。

成功标志：日志应开始出现 ROTATE_REQUEST fire_dog=...。
日志：FireDogRotation.log

修复：v0.1.2 合并运行时源码中出现了一个字面 NUL 字节，可能导致 Shared Loader 在 open_log() 之前解析失败，因此没有 FireDogRotation.log。v0.1.3 已去除该字节。
