param(
    [ValidateSet('Check','Apply','Restore')][string]$Mode = 'Check',
    [string]$GamePath = 'E:\steam\steamapps\common\Helldivers 2'
)
$ErrorActionPreference = 'Stop'
$repairConfig = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'repair-config.json') -Raw | ConvertFrom-Json
$repairRoot = [IO.Path]::GetFullPath($GamePath).TrimEnd('\')
$repairData = Join-Path $repairRoot 'data\game'
$repairToken = [guid]::NewGuid().ToString('N')
$repairMarker = Join-Path $repairData 'HD2DOT4HSMK-BETA4.active-transaction.json'
$repairStaged = @()
$repairCommitted = @()
$repairMarkerCreated = $false

function Assert-PlainPath([string]$Path) {
    $walkPath = [IO.Path]::GetFullPath($Path)
    while ($walkPath) {
        if (Test-Path -LiteralPath $walkPath) {
            if ((Get-Item -LiteralPath $walkPath -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) {
                throw "Reparse point refused: $walkPath"
            }
        }
        $walkParent = [IO.Path]::GetDirectoryName($walkPath)
        if ($walkParent -eq $walkPath) { break }
        $walkPath = $walkParent
    }
}
function Read-Hash([string]$Path) {
    Assert-PlainPath $Path
    $hashStream = [IO.File]::Open($Path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
    $hasher = [Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($hasher.ComputeHash($hashStream)).Replace('-','').ToLowerInvariant() }
    finally { $hasher.Dispose(); $hashStream.Dispose() }
}
function Assert-Native {
    if (Get-Process -Name helldivers2 -ErrorAction SilentlyContinue) { throw 'Close Helldivers 2 first.' }
    foreach ($native in $repairConfig.native) {
        if ((Read-Hash (Join-Path $repairRoot $native.path)) -ne $native.sha256) { throw "Unsupported game executable: $($native.path)" }
    }
    $manifestPath = [IO.Path]::GetFullPath((Join-Path $repairRoot '..\..\appmanifest_553850.acf'))
    $manifestText = Get-Content -LiteralPath $manifestPath -Raw
    $apps = [regex]::Matches($manifestText,'"appid"\s*"(\d+)"')
    $builds = [regex]::Matches($manifestText,'"buildid"\s*"(\d+)"')
    if ($apps.Count -ne 1 -or $apps[0].Groups[1].Value -ne '553850' -or $builds.Count -ne 1 -or $builds[0].Groups[1].Value -ne '26088801') {
        throw 'Steam build is not 26088801.'
    }
}
function Get-ResourceState($Resource) {
    $resourcePath = Join-Path $repairData $Resource.name
    $resourceHash = Read-Hash $resourcePath
    foreach ($candidateState in @('original','legacy','fixed')) {
        if ($resourceHash -eq $Resource.$candidateState.sha256) { return $candidateState }
    }
    throw "Unknown resource refused: $($Resource.name) SHA256=$resourceHash"
}
function Write-NewBytes([string]$Path,[byte[]]$Bytes) {
    $newStream = [IO.File]::Open($Path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try { $newStream.Write($Bytes,0,$Bytes.Length); $newStream.Flush($true) } finally { $newStream.Dispose() }
}

try {
    Assert-PlainPath $repairData
    Assert-Native
    if (Test-Path -LiteralPath $repairMarker) { throw 'Previous transaction marker exists. Inspect it and the retained backups before retrying.' }
    if (Test-Path -LiteralPath (Join-Path $repairData 'HD2DOT4HSMK-B26088801.txn')) { throw 'Unfinished in-game installer transaction exists. No repair attempted.' }
    foreach ($resource in $repairConfig.resources) {
        foreach ($suffix in @('.HD2DOT4HSMK-B26088801.rollback','.HD2DOT4HSMK-B26088801.temporary')) {
            if (Test-Path -LiteralPath (Join-Path $repairData ($resource.name+$suffix))) { throw 'Unfinished in-game installer transaction file exists. No repair attempted.' }
        }
    }
    $repairSnapshot = @()
    foreach ($resource in $repairConfig.resources) {
        foreach ($stateName in @('original','legacy','fixed')) {
            if ((Read-Hash (Join-Path $PSScriptRoot $resource.$stateName.file)) -ne $resource.$stateName.sha256) { throw 'Packaged resource verification failed.' }
        }
        $repairSnapshot += [pscustomobject]@{ name=$resource.name; state=(Get-ResourceState $resource) }
    }
    if ($Mode -eq 'Check') {
        [pscustomobject]@{ Mode=$Mode; Build=26088801; Resources=$repairSnapshot; FilesChanged=$false } | ConvertTo-Json -Depth 5
        exit 0
    }
    $desiredState = if ($Mode -eq 'Apply') { 'fixed' } else { 'original' }
    foreach ($resource in $repairConfig.resources) {
        $beforeState = Get-ResourceState $resource
        if ($beforeState -eq $desiredState) { continue }
        $livePath = Join-Path $repairData $resource.name
        $stagePath = $livePath + '.BETA4.' + $repairToken + '.stage'
        $backupPath = $livePath + '.BETA4.' + $repairToken + '.before'
        Assert-PlainPath $stagePath
        Assert-PlainPath $backupPath
        if (Test-Path -LiteralPath $backupPath) { throw 'Fresh backup path occupied.' }
        $desiredBytes = [IO.File]::ReadAllBytes((Join-Path $PSScriptRoot $resource.$desiredState.file))
        Write-NewBytes $stagePath $desiredBytes
        if ((Read-Hash $stagePath) -ne $resource.$desiredState.sha256) { throw 'Staging verification failed.' }
        $repairStaged += [pscustomobject]@{ resource=$resource; live=$livePath; stage=$stagePath; backup=$backupPath; before=$resource.$beforeState.sha256; after=$resource.$desiredState.sha256 }
    }
    if ($repairStaged.Count -eq 0) {
        [pscustomobject]@{ Mode=$Mode; State=$desiredState; FilesChanged=$false } | ConvertTo-Json
        exit 0
    }
    Assert-Native
    foreach ($entry in $repairStaged) {
        if ((Read-Hash $entry.live) -ne $entry.before -or (Read-Hash $entry.stage) -ne $entry.after) { throw 'Resource changed during preparation.' }
    }
    $markerBytes = [Text.Encoding]::UTF8.GetBytes(($repairStaged | Select-Object live,backup,before,after | ConvertTo-Json -Depth 5))
    Write-NewBytes $repairMarker $markerBytes
    $repairMarkerCreated = $true
    foreach ($entry in $repairStaged) {
        if ((Read-Hash $entry.live) -ne $entry.before) { throw 'Resource changed before replacement.' }
        [IO.File]::Replace($entry.stage,$entry.live,$entry.backup)
        $repairCommitted += $entry
        if ((Read-Hash $entry.live) -ne $entry.after -or (Read-Hash $entry.backup) -ne $entry.before) { throw 'Commit verification failed.' }
    }
    foreach ($entry in $repairStaged) { if ((Read-Hash $entry.live) -ne $entry.after) { throw 'Final verification failed.' } }
    $markerArchive = Join-Path $repairData ('HD2DOT4HSMK-BETA4.'+$repairToken+'.committed.json')
    [IO.File]::Move($repairMarker,$markerArchive)
    [pscustomobject]@{ Mode=$Mode; State=$desiredState; FilesChanged=$true; RetainedBackups=@($repairCommitted | Select-Object -ExpandProperty backup); GameplayVerified=$false } | ConvertTo-Json -Depth 5
    exit 0
} catch {
    $failureMessage = $_.Exception.Message
    $rollbackComplete = $true
    for ($index=$repairCommitted.Count-1; $index -ge 0; $index--) {
        $entry=$repairCommitted[$index]
        try {
            if ((Read-Hash $entry.live) -ne $entry.after -or (Read-Hash $entry.backup) -ne $entry.before) { throw 'Concurrent change; rollback refused.' }
            $rollbackStage=$entry.live+'.BETA4.'+$repairToken+'.restore-stage'
            $failedBytes=$entry.live+'.BETA4.'+$repairToken+'.failed'
            Write-NewBytes $rollbackStage ([IO.File]::ReadAllBytes($entry.backup))
            [IO.File]::Replace($rollbackStage,$entry.live,$failedBytes)
            if ((Read-Hash $entry.live) -ne $entry.before) { throw 'Rollback verification failed.' }
        } catch { $rollbackComplete=$false; [Console]::Error.WriteLine('ROLLBACK NEEDS INSPECTION: '+$_.Exception.Message) }
    }
    if ($rollbackComplete -and $repairMarkerCreated -and (Test-Path -LiteralPath $repairMarker)) {
        try { [IO.File]::Move($repairMarker,(Join-Path $repairData ('HD2DOT4HSMK-BETA4.'+$repairToken+'.rolled-back.json'))) } catch { $rollbackComplete=$false }
    }
    [Console]::Error.WriteLine('REPAIR REFUSED: '+$failureMessage)
    [Console]::Error.WriteLine('RollbackComplete='+$rollbackComplete+'. All backups and staging files retained.')
    exit 2
}
