# DOT×4 + 治疗烟雾 & LIFT-182 传送烟雾 20m（Chef 自动合并版 v4）

你原来两个“boot 安装器” mod 的 **Chef Loader addon 合并版**：不再占用游戏 boot、
不再需要切换安装器；挂在「0. 前置 + 藏宝图雷达（Chef Loader）」下自动加载。

## v4 修了什么（首测失败原因）

首测（15:29–15:36 那一局）两个 addon 都正常加载并排队了；退出时 DOT4 写盘完成，
但 LIFT-182 的 45 MB 重写 + 纯 Lua 指纹校验在“退出钩子”里要 30–40 秒，
游戏进程在收尾前被结束，留下 `.txn`/`.rollback`，没有写成完成标记，
所以看起来“没有成功”。v4 改为：

- **进游戏后（到标题/飞船，且不在任务中）立刻写盘**，不再把重活放在退出时——
  退出游戏恢复正常速度；
- LIFT-182 的提交过程去掉了三处“刚由自己写入/改名的文件再算一次全文件指纹”的
  冗余校验（暂存文件的完整校验保留，事务日志/回滚机制不变），写盘从 ~40 秒降到 ~10 秒；
- 如果上一次在 45 MB 写入中途被强杀，新版本启动时会先用内建 `recover()`
  把上次事务收尾/回滚，再决定是否需要重写（这一次启动可能卡 10–20 秒）。

## 它做什么

- 第一次满足条件时自动写入 4 个资源（原安装器的目标字节，原样复用）：
  `generated_damage_settings.dl_bin`（DOT×4）、`generated_status_effect_settings.dl_bin`（治疗烟雾）、
  `generated_entities.dl_bin`（LIFT-182 落点 → G-3 烟雾）、`generated_explosion_settings.dl_bin`（G-3 半径 20m）。
- 写完在游戏根目录留下标记文件，以后不再写盘：
  `HD2DOT4HSMK-B26088801.chef-auto.done`、`LIFT182-WarpSmoke20-B26088801.chef-auto.done`。
- 无菜单、无按键、无屏幕文字，只在游戏根目录两个日志里记录 `CHEF AUTO: ...`。

## 安装

1. Arsenal 里停用/删除旧的 DOT4、LIFT182「boot 安装器」，以及**任何其它占用 boot 的安装器/加载器**；
   确认「0. 前置 + 藏宝图雷达（Chef Loader）」是启用状态（本 mod 依赖它，不替代它）。
2. Arsenal → 添加/导入本 ZIP → 勾选本 mod（Options 选「安装」）→ Deploy。
3. 启动游戏。**进到标题/飞船后可能会卡 10–20 秒（正在写 45 MB），属正常，别关游戏、别强杀**；
   日志出现下面这些即完成：
   - `HD2DOT4HSMK-B26088801.log`：`CHEF AUTO: APPLY WILL RUN NOW` → `SUCCESS: PATCHED BOTH FILES` → `CHEF AUTO: APPLY COMPLETE`
   - `LIFT182-WarpSmoke20-B26088801.log`：`CHEF AUTO: APPLY WILL RUN NOW` → `BOTH FILES WRITTEN AND VERIFIED` → `TRANSACTION CLEAN` → `CHEF AUTO: APPLY COMPLETE`
4. 退出游戏，再启动一次 → 效果生效（数据在启动时加载）。
5. 之后每次启动都是秒进、不写盘。

> 本次首测已经在 `data/game` 留下半收尾的事务（`.txn`+`.rollback`，DOT4 已完成并带标记）。
> 装好 v4 后第一次启动会自动把 LIFT 的事务收尾（约 10–20 秒），不会再重写 45 MB。

## 还原原版

1. 游戏根目录新建文本文件 `HD2Merged-RESTORE.txt`（内容随意）。
2. 启动游戏，等它自动还原（约 10–20 秒卡顿），日志出现 `CHEF AUTO: RESTORE COMPLETE`；
   同时生成 `HD2Merged-HOLD.txt` 防止自动重装。
3. 想再装：删掉 `HD2Merged-HOLD.txt`，再启动一次即可。
4. 如果之后用 Steam「验证游戏文件完整性」恢复原版，记得同时删掉游戏根目录的
   `*.chef-auto.done` 两个标记文件，否则不会自动重装。

## 如果写入后游戏进不去（保险步骤）

1. Arsenal 停用本 mod。
2. 用本 mod 目录里的 `Recovery-DOT4/Repair-Mod.ps1 -Mode Restore` 还原 DOT4 两个文件；
   LIFT 两个文件用 Steam「验证游戏文件完整性」还原原版。带着两个日志反馈。

## 已知副作用（和原安装器一致）

- G-3 烟雾是共享数据：其他用 G-3 的装备也会变成 20m 半径。
- LIFT-182 落点原来的伤害爆炸被替换成烟雾。
- 只适用 Steam Build 26088801；游戏更新后安装器会拒绝写入（构建号/哈希校验）。

## 文件说明

- `data/9ba626afa44a3aa3.patch_0`：一个 Chef patch，内含两个 `-- HD2-Addon:` 资源
  （`mods/chef/treasure_radar_dot4heal`、`mods/chef/treasure_radar_warp182`）。
- `Source/`：两个 addon 的 Lua 源码（不部署）。
- `Recovery-DOT4/`：DOT4 原包里的离线恢复脚本（不部署）。


> v4（本包）：写盘在“进游戏后、不在任务中”的稳定世界里执行，退出游戏不再卡；
> 如果当时游戏占着文件导致写失败，会在关闭游戏时自动再试一次。
> 首次进游戏可能会卡 10–20 秒（写 45 MB / 收尾上次残留事务），属正常，别强杀。
