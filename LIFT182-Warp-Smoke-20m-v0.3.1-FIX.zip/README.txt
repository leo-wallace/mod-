LIFT-182 Warp Smoke 20m v0.3.1 - LOAD FIX / EXPERIMENTAL TEST

FIXES: v0.3.0 reused an old Lua resource hash while changing the declared name, so Bingus discovery skipped it. v0.3.1 fixes the resource hash and validates the resource table.

ONE OPTION ONLY: Smoke Spawn Test A. There is NO 20m-damage-blast Test B in this ZIP.

Mechanism: remap LIFT-182 arrival ExplosionInfo 254 to original G-3 Smoke ExplosionInfo 28; widen SHARED G-3 inner and outer smoke radius from 8m to 20m. All mods/grenades referencing the same G-3 row may be affected on your client, including other players' effects. This is NOT player-specific. Your G-89 uses a different effect, but isolation is not proven without inspecting its table row. This mode REPLACES the normal LIFT-182 arrival damage explosion with smoke, and does not solve simultaneous damage+smoke. Visibility and game behavior remain UNTESTED.

INSTALL: Remove/disable v0.3.0 and v0.2.0 Fusion first, import this ZIP into Arsenal or HD2MM, enable the only option, then Purge and Deploy. Restart the game fully. Keep Bingus Shared Loader as winning Wwise startup replacement. Loader v19 recommended. Do not install both packages/options.

CHECK LOADER LOG FIRST: %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\BingusSharedLoader.log
Expected line: mods/field/lift182_smoke20: loaded
Then check: %LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\LIFT182Smoke20.log
Expected if the actual memory patch is applied: SMOKE20_LINK_VERIFIED
If it reports refused or gave_up, no validated gameplay change is established; send both logs.

Solo controlled tests only, away from other players. Warp collision/death logic is unchanged.

This package has been OFFLINE validated for resource-name hash, Lua envelope, ZIP integrity, and manifest option. It has NOT been launched in the game.
