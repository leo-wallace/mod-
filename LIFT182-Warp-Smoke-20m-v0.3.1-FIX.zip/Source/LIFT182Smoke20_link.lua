-- HD2-Addon: mods/field/lift182_smoke20
-- LIFT-182 Smoke 20m v0.3.1 - experimental
-- Mode LINK swaps native explosion reference; mode FUSION tests smoke volume.
-- WARNING: not player isolated; solo test only, disable previous v0.2.0 first.

local WARP = { hi = 0xB4975679, lo = 0x5D9B0E68 }
local T_WARP, T_EXPLOSION = 0xA7813546, 0x2AEA2592
local MOD = {
 id='mods/field/lift182_smoke20', global='FieldLIFT182Smoke20_link', title='LIFT-182 Smoke 20m Test',
 version='0.3.1', author='local', log='LIFT182Smoke20.log',
 targets={
  {label='Warp Pack',table=T_WARP,stride=632,entity=WARP,capture='warp_links',edits={}},
  {label='Warp Explosion',table=T_EXPLOSION,stride=152,tail=true,row_source='warp_explosion',capture='explosion_link',edits={}},
  {label='G-3 Smoke Explosion',table=T_EXPLOSION,stride=152,tail=true,row_id=28,edits={}},
 }
}
-- ================================================================ tuning engine
-- Shared by every SHODAN tuning mod; the MOD table above says what to change.
--
-- The game lays its settings tables down in memory as LDLD blocks. Keyed tables hold a
-- bucket array (u64 entity hash, u32 record index, u32 0; always two buckets per entity)
-- followed by fixed-stride records; row tables hold a u64 descriptor and a u32 row count,
-- then fixed-stride rows that start with a unique id. Records are found from that structure
-- alone -- entity hash or row id, plus the exact record size this build uses -- never from
-- the stat values, so other mods changing the same weapon cannot stop these values from
-- being applied. The fields written must still hold plausible values beforehand; anything
-- else means the layout moved in a game update, and nothing is written.
--
-- Every write is read back and the rest of the record is checked untouched, or it is
-- rolled back. Once applied, the values are re-checked every few seconds and restored if
-- something else overwrote them. Changes live in memory only.

local SMOKE_MODE = 'link'
if rawget(_G, 'CodexLIFT182SmokeFusion') then error('Remove v0.2 smoke fusion before installing v0.3') end
if rawget(_G, MOD.global) then return end

local HEADER_BYTES = 24
local MAX_PAYLOAD = 64 * 1024 * 1024
local FRAME_BUDGET = 0.006
local CHUNK = 262144
local START_FRAME = 300
local PROBE_MIN_ALLOC = 64 * 1024
local PROBE_BYTES = 128 * 1024
local SELF_MARGIN = 4096
local MAX_ROUNDS = 12
local ROUND_DELAY_SECONDS = 2
local ENFORCE_SECONDS = 5
local MAX_UNINDEXED_RECORDS = 2  -- keyed tables carry at most this many records no entity points at
local MAX_LOG_LINES = 400

local MEM_COMMIT, MEM_PRIVATE = 0x1000, 0x20000
local PAGE_READONLY, PAGE_READWRITE = 0x02, 0x04

local state = {
    title = MOD.title, version = MOD.version, phase = 'starting', status = 'starting',
    frame = 0, rounds = 0, applied = 0, reapplied = 0, refused = 0,
    sources = {},
}
rawset(_G, MOD.global, state)

-- ---------------------------------------------------------------- byte helpers
local function u32_bytes(value)
    value = value % 4294967296
    return string.char(value % 256,
                       math.floor(value / 256) % 256,
                       math.floor(value / 65536) % 256,
                       math.floor(value / 16777216) % 256)
end

local function u32(blob, offset)
    local a, b, c, d = blob:byte(offset + 1, offset + 4)
    if not d then return nil end
    return a + b * 256 + c * 65536 + d * 16777216
end

-- Independent decoder: bits -> number, so read-back checks never share code with the encoder.
local function bits_to_f32(bits)
    local sign = 1
    if bits >= 2147483648 then sign = -1; bits = bits - 2147483648 end
    local exp = math.floor(bits / 8388608)
    local mant = bits - exp * 8388608
    if exp == 255 then return mant == 0 and sign * math.huge or 0 / 0 end
    if exp == 0 then return mant == 0 and sign * 0.0 or sign * mant * 2 ^ -149 end
    return sign * (1 + mant / 8388608) * 2 ^ (exp - 127)
end

local function near(a, b)
    return a ~= nil and math.abs(a - b) < 1e-4
end

local NEEDLE = 'LDLD' .. u32_bytes(1)

-- ---------------------------------------------------------------- windows api
local ffi_ok, ffi = pcall(require, 'ffi')
local api = nil
local f32_bytes = nil
local REGION_TYPE = MOD.global .. 'Region'

local function build_api()
    for _, declaration in ipairs({
        'void *GetCurrentProcess(void);',
        'int ReadProcessMemory(void *process, const void *address, void *buffer, size_t size, size_t *read);',
        'int WriteProcessMemory(void *process, void *address, const void *buffer, size_t size, size_t *written);',
        'size_t VirtualQuery(const void *address, void *region, size_t size);',
        'int VirtualProtect(void *address, size_t size, uint32_t new_protection, uint32_t *old_protection);',
        'int CreateDirectoryA(const char *path, void *security);',
        'uint32_t GetLastError(void);',
    }) do
        pcall(ffi.cdef, declaration)
    end
    pcall(ffi.cdef, [[typedef struct {
        void *base; void *allocation_base; uint32_t allocation_protection;
        uint16_t partition; uint16_t reserved; size_t size;
        uint32_t state; uint32_t protection; uint32_t type;
    } ]] .. REGION_TYPE .. ';')

    local kernel = ffi.load('kernel32')
    local query = ffi.cast('size_t (*)(const void *, void *, size_t)', kernel.VirtualQuery)
    local virtual_protect = ffi.cast('int (*)(void *, size_t, uint32_t, uint32_t *)', kernel.VirtualProtect)
    local process = kernel.GetCurrentProcess()
    local region = ffi.new(REGION_TYPE .. '[1]')
    local region_size = ffi.sizeof(region[0])
    local counter = ffi.new('size_t[1]')

    local self = {}

    function self.read(address, size)
        if size <= 0 then return nil end
        local buffer = ffi.new('uint8_t[?]', size)
        if kernel.ReadProcessMemory(process, ffi.cast('const void *', address),
                                    buffer, size, counter) == 0 then return nil end
        if tonumber(counter[0]) ~= size then return nil end
        return ffi.string(buffer, size)
    end

    function self.query(address)
        if query(ffi.cast('const void *', address), region, region_size) ~= region_size then
            return nil
        end
        local base = tonumber(ffi.cast('uintptr_t', region[0].base))
        local size = tonumber(region[0].size)
        if not base or not size or size <= 0 then return nil end
        return { base = base, size = size, state = region[0].state,
                 protection = region[0].protection, kind = region[0].type }
    end

    function self.write(address, bytes)
        if #bytes <= 0 then return false end
        local info = self.query(address)
        if not info or info.state ~= MEM_COMMIT or info.kind ~= MEM_PRIVATE
            or address < info.base or address + #bytes > info.base + info.size
            or (info.protection ~= PAGE_READONLY and info.protection ~= PAGE_READWRITE) then
            return false
        end
        local old_protection = ffi.new('uint32_t[1]')
        local changed = info.protection == PAGE_READONLY
        if changed and virtual_protect(ffi.cast('void *', address), #bytes,
                                       PAGE_READWRITE, old_protection) == 0 then
            return false
        end
        local wrote = kernel.WriteProcessMemory(process, ffi.cast('void *', address),
                                                bytes, #bytes, counter) ~= 0
                      and tonumber(counter[0]) == #bytes
        local restored = not changed or virtual_protect(
            ffi.cast('void *', address), #bytes, old_protection[0], old_protection) ~= 0
        return wrote and restored
    end

    function self.regions()
        local out = {}
        local address = 0
        while address < 0x7FFFFFFF0000 do
            if query(ffi.cast('const void *', address), region, region_size) ~= region_size then break end
            local base = tonumber(ffi.cast('uintptr_t', region[0].base))
            local size = tonumber(region[0].size)
            if not base or not size or size <= 0 then break end
            if region[0].state == MEM_COMMIT and region[0].type == MEM_PRIVATE
                and (region[0].protection == PAGE_READONLY or region[0].protection == PAGE_READWRITE) then
                out[#out + 1] = { base = base, size = size,
                                  allocation_base = tonumber(ffi.cast('uintptr_t', region[0].allocation_base)) }
            end
            address = base + size
        end
        table.sort(out, function(a, b) return a.size > b.size end)
        return out
    end

    function self.address_of(text)
        local ok, value = pcall(function()
            return tonumber(ffi.cast('uintptr_t', ffi.cast('const char *', text)))
        end)
        if ok then return value end
        return nil
    end

    function self.mkdir(path)
        return kernel.CreateDirectoryA(path, nil) ~= 0 or kernel.GetLastError() == 183
    end

    return self
end

-- ---------------------------------------------------------------- log
local log_path, log_lines, log_counts = nil, {}, {}

local function ensure_log_path()
    if log_path ~= nil then return log_path end
    log_path = false
    local ok, resolved = pcall(function()
        local base = os.getenv('LOCALAPPDATA')
        if not base or base == '' then return nil end
        for _, part in ipairs({ 'CowboyBingus', 'Helldivers2', 'Logs' }) do
            base = base .. '/' .. part
            if not api.mkdir(base) then return nil end
        end
        return base .. '/' .. MOD.log
    end)
    if ok and resolved then log_path = resolved end
    return log_path
end

local function flush_log()
    local path = ensure_log_path()
    if not path then return end
    local ok, handle = pcall(io.open, path, 'wb')
    if not ok or not handle then return end
    local lines = {
        MOD.title .. ' v' .. MOD.version .. ' by ' .. MOD.author,
        'status: ' .. tostring(state.phase) .. ' - ' .. tostring(state.status),
        'applied ' .. state.applied .. ', re-applied ' .. state.reapplied .. ', refused ' .. state.refused,
        '',
    }
    for _, line in ipairs(log_lines) do lines[#lines + 1] = line end
    pcall(function() handle:write(table.concat(lines, '\r\n') .. '\r\n') end)
    pcall(function() handle:close() end)
end

local function log(message)
    local count = (log_counts[message] or 0) + 1
    log_counts[message] = count
    if count > 3 or #log_lines >= MAX_LOG_LINES then return end
    local line = '[frame ' .. tostring(state.frame) .. '] ' .. message
    if count == 3 then line = line .. ' (further repeats not logged)' end
    log_lines[#log_lines + 1] = line
    print('[' .. MOD.global .. '] ' .. line)
end

local function set_status(phase, status)
    state.phase, state.status = phase, status
    log(phase .. ': ' .. status)
    pcall(flush_log)
end

local function hex(n) return string.format('0x%X', n) end

-- ---------------------------------------------------------------- edits
-- Each edit: offset, kind ('f32' or 'u32'), value, max. A field is overwritten whatever it
-- holds, as long as that is a plausible value for the field (0..max); an implausible value
-- means the record layout is not the one this build uses, and the record is left alone.
local function prepare_edits()
    for _, target in ipairs(MOD.targets) do
        for _, edit in ipairs(target.edits) do
            if not edit.source_key then
                if edit.kind == 'f32' then
                    edit.bytes = f32_bytes(edit.value)
                    assert(near(bits_to_f32(u32(edit.bytes, 0)), edit.value), 'float encoder self-check failed')
                else
                    edit.bytes = u32_bytes(edit.value)
                end
            end
        end
    end
end

local function desired_bytes(edit)
    if edit.source_key then
        local value = state.sources[edit.source_key]
        if value == nil then return nil end
        return edit.kind == 'f32' and f32_bytes(value) or u32_bytes(value)
    end
    return edit.bytes
end

local function plausible(edit, bytes)
    local bits = u32(bytes, 0)
    if not bits then return false end
    if edit.kind == 'f32' then
        local value = bits_to_f32(bits)
        return value == value and value >= 0 and value <= edit.max
    end
    return bits <= edit.max
end

-- Returns 'applied', 'already' or a reason the record was left alone.
local function apply_edits(address, size, target)
    local before = api.read(address, size)
    if not before then return 'unreadable' end
    local pending = {}
    for _, edit in ipairs(target.edits) do
        local wanted = desired_bytes(edit)
        if not wanted then return 'waiting for source ' .. tostring(edit.source_key) end
        local current = before:sub(edit.offset + 1, edit.offset + 4)
        if current ~= wanted then
            if not plausible(edit, current) then return 'implausible value at +' .. edit.offset end
            pending[#pending + 1] = { edit.offset, current, wanted }
        end
    end
    if #pending == 0 then return 'already' end

    local function rollback(reason)
        for _, change in ipairs(pending) do api.write(address + change[1], change[2]) end
        return reason
    end
    for _, change in ipairs(pending) do
        if not api.write(address + change[1], change[3]) then return rollback('write failed at +' .. change[1]) end
    end
    local after = api.read(address, size)
    if not after then return rollback('could not read back') end
    local expected = before
    for _, change in ipairs(pending) do
        expected = expected:sub(1, change[1]) .. change[3] .. expected:sub(change[1] + 5)
    end
    if after ~= expected then return rollback('read-back did not match') end
    return 'applied'
end

-- ---------------------------------------------------------------- record location
-- Keyed table: find the bucket count that is exactly twice the entities it holds and leaves
-- a record array of this build's stride with at most MAX_UNINDEXED_RECORDS spare records.
-- Record bytes can look like buckets, so every candidate count is checked and exactly one
-- must fit.
local function locate_keyed(blob, target)
    local total, stride, entity = #blob, target.stride, target.entity
    local offset, count, live, top, index = 0, 0, 0, -1, nil
    local found = {}
    while offset + 16 <= total do
        local low, high = u32(blob, offset), u32(blob, offset + 4)
        local slot, pad = u32(blob, offset + 8), u32(blob, offset + 12)
        if pad ~= 0 or slot > 100000 then break end
        count = count + 1
        offset = offset + 16
        if low ~= 0 or high ~= 0 then
            live = live + 1
            if slot > top then top = slot end
            if index == nil and low == entity.lo and high == entity.hi then index = slot end
        end
        local array = total - count * 16
        if index ~= nil and count == 2 * live and array > 0 and array % stride == 0 then
            local records = array / stride
            if records > top and records <= live + MAX_UNINDEXED_RECORDS then
                found[#found + 1] = count * 16 + index * stride
            end
        end
    end
    if index == nil then return nil, target.label .. ': entity not in this table' end
    if #found ~= 1 then return nil, target.label .. ': ' .. #found .. ' layouts fit (need exactly 1)' end
    return found[1]
end

-- Row table: u64 descriptor, u32 row count, u32 0, then rows of `stride` bytes that start
-- with a unique u32 id.
local function locate_row(blob, target)
    local stride, rows = target.stride, u32(blob, 8)
    local wanted = target.row_id
    if wanted == nil and target.row_source then wanted = state.sources[target.row_source] end
    if wanted == nil then return nil, target.label .. ': waiting for linked row id' end
    local size = rows and 16 + rows * stride
    local size_ok = size and (target.tail and size <= #blob or (not target.tail and size == #blob))
    if not rows or u32(blob, 12) ~= 0 or not size_ok then
        return nil, target.label .. ': row table size does not match this build'
    end
    local hits = {}
    local id_at = target.id_at or 0
    for row = 0, rows - 1 do
        if u32(blob, 16 + row * stride + id_at) == wanted then hits[#hits + 1] = 16 + row * stride end
    end
    if #hits ~= 1 then return nil, target.label .. ': ' .. #hits .. ' rows with id ' .. tostring(wanted) end
    return hits[1]
end

-- ---------------------------------------------------------------- sites
-- A site is one applied record: the table block it lives in (to notice the table going
-- away) and the record address (to keep the values applied).
local sites = {}

local function count_sites(target)
    local n = 0
    for _, site in ipairs(sites) do if site.target == target then n = n + 1 end end
    return n
end

local function complete()
    for _, target in ipairs(MOD.targets) do
        if count_sites(target) == 0 then return false end
    end
    return true
end

local function summary()
    local parts = {}
    for _, target in ipairs(MOD.targets) do parts[#parts + 1] = target.label .. ' ' .. count_sites(target) end
    return table.concat(parts, ', ')
end

local function same_record(a, b)
    return a.table == b.table and a.stride == b.stride and a.row_id == b.row_id
        and (a.entity == nil) == (b.entity == nil)
        and (a.entity == nil or (a.entity.hi == b.entity.hi and a.entity.lo == b.entity.lo))
end

-- A record is only trusted if every field any target edits in it holds a plausible value:
-- one implausible field means the layout moved, so no target may write to that record.
local function record_trusted(record, target)
    local blob = api.read(record, target.stride)
    if not blob then return false, 'unreadable' end
    for _, other in ipairs(MOD.targets) do
        if same_record(other, target) then
            for _, edit in ipairs(other.edits) do
                local wanted = desired_bytes(edit)
                if not wanted then
                    return false, 'waiting for source ' .. tostring(edit.source_key)
                end
                local current = blob:sub(edit.offset + 1, edit.offset + 4)
                if current ~= wanted and not plausible(edit, current) then
                    return false, 'implausible value at +' .. edit.offset .. ' (' .. other.label .. ')'
                end
            end
        end
    end
    return true
end

local function capture_target(record, target)
    local blob = api.read(record, target.stride)
    if not blob then return false, 'unreadable' end
    if target.capture == 'warp_links' then
        local explosion = u32(blob, 56)
        if not explosion or explosion <= 0 or explosion > 100000 then
            return false, 'Warp explosion id is implausible'
        end
        if state.sources.warp_explosion ~= explosion then
            state.sources.warp_explosion = explosion
            log('Warp explosion row id=' .. tostring(explosion))
        end
        return true
    elseif target.capture == 'explosion_link' then
        local damage = u32(blob, 4)
        if not damage or damage <= 0 or damage > 100000 then
            return false, 'Warp explosion damage id is implausible'
        end
        if state.sources.warp_damage ~= damage then
            state.sources.warp_damage = damage
            log('Warp explosion damage row id=' .. tostring(damage))
        end
        return true
    end
    return false, 'unknown capture target'
end

local function add_site(target, block, payload, record)
    for _, site in ipairs(sites) do
        if site.record == record and site.target == target then return end
    end

    if target.capture then
        local ok, reason = capture_target(record, target)
        if not ok then
            state.refused = state.refused + 1
            log(target.label .. ' at ' .. hex(record) .. ' left alone: ' .. tostring(reason))
            return
        end
    end

    local result = 'already'
    if #target.edits > 0 then
        local trusted, reason = record_trusted(record, target)
        result = trusted and apply_edits(record, target.stride, target) or reason
    end
    if result == 'applied' or result == 'already' then
        if target.label == 'Warp Pack' or target.label == 'Warp Explosion' or target.label == 'G-3 Smoke Explosion' then
            local record_bytes = api.read(record, target.stride)
            if record_bytes then
                local chunks = {}
                for off = 0, target.stride-1, 16 do
                    local section=record_bytes:sub(off+1, math.min(off+16,target.stride))
                    chunks[#chunks+1] = string.format('+%03d %s', off, (section:gsub('.',function(c) return string.format('%02X ',string.byte(c)) end)))
                end
                log(target.label .. ' RECORD HEX: ' .. table.concat(chunks, ' | '))
                local bytes = record_bytes
                if target.table == T_EXPLOSION then
                    log(target.label .. ' decoded id=' .. tostring(u32(bytes,0)) ..
                        ' damage_row=' .. tostring(u32(bytes,4)) ..
                        ' radii_hex_u32=' .. tostring(u32(bytes,16)) .. '/' .. tostring(u32(bytes,20)) .. '/' .. tostring(u32(bytes,24)))
                end
            end
        end
        sites[#sites + 1] = { target = target, block = block, payload = payload, record = record }
        state.applied = state.applied + 1
        log(target.label .. ' ' .. (target.capture and 'resolved/' or '') .. result .. ' at ' .. hex(record))
    elseif type(result) == 'string' and result:find('waiting for source', 1, true) then
        log(target.label .. ' waiting: ' .. result)
    else
        state.refused = state.refused + 1
        log(target.label .. ' at ' .. hex(record) .. ' left alone: ' .. tostring(result))
    end
end

-- ---------------------------------------------------------------- scanning
local self_addresses = {}
local seen_blocks = {}
-- Every Lua read of a table leaves a stale copy in the Lua heap, and a sweep would find
-- those too. When this Lua state allocates below 2 GiB (LuaJIT without GC64), nothing down
-- there is a real settings table: the game lays those down high.
local LUA_HEAP_LIMIT = 0x80000000
local skip_low = false

local function handle_block(address)
    if seen_blocks[address] then return end
    seen_blocks[address] = true
    if skip_low and address < LUA_HEAP_LIMIT then return end
    local header = api.read(address, HEADER_BYTES)
    if not header or header:sub(1, 8) ~= NEEDLE then return end
    local kind, payload = u32(header, 8), u32(header, 12)
    if not payload or payload < 16 or payload > MAX_PAYLOAD then return end
    local wanted = false
    for _, target in ipairs(MOD.targets) do
        if target.table == kind then wanted = true end
    end
    if not wanted then return end
    -- read the payload only, so our own copy carries no LDLD header for a later sweep to find
    local blob = api.read(address + HEADER_BYTES, payload)
    if not blob then return end
    for _, target in ipairs(MOD.targets) do
        if target.table == kind then
            local locate = target.entity and locate_keyed or locate_row
            local offset, reason = locate(blob, target)
            if offset then
                add_site(target, address, payload, address + HEADER_BYTES + offset)
            else
                log(reason .. ' (table at ' .. hex(address) .. ')')
            end
        end
    end
end

local function scan_chunk(addr, size)
    local blob = api.read(addr, size)
    if not blob then return end
    local position = 1
    while true do
        local hit = blob:find(NEEDLE, position, true)
        if not hit then break end
        local address = addr + hit - 1
        local skip = false
        for _, own in ipairs(self_addresses) do
            if own and math.abs(address - own) <= SELF_MARGIN then skip = true break end
        end
        if not skip then pcall(handle_block, address) end
        position = hit + 1
    end
end

local probe, scan

local function begin_round()
    probe = { regions = {}, index = 1, seen = {}, done = false }
    scan = { regions = {}, index = 1, cursor = 0, overlap = #NEEDLE - 1 }
    seen_blocks = {}
    state.rounds = state.rounds + 1
    for _, region in ipairs(api.regions()) do
        if region.allocation_base and region.size >= PROBE_MIN_ALLOC then
            probe.regions[#probe.regions + 1] = region
        end
        scan.regions[#scan.regions + 1] = region
    end
end

-- Returns true once this round is finished. The settings tables sit near the start of their
-- allocations, so allocation heads are probed first; the full sweep follows unless the probe
-- already found everything with Lua-heap copies filtered out.
local function scan_step()
    local deadline = os.clock() + FRAME_BUDGET
    while not probe.done and probe.index <= #probe.regions do
        local region = probe.regions[probe.index]
        probe.index = probe.index + 1
        local key = string.format('%X', region.allocation_base)
        if not probe.seen[key] then
            probe.seen[key] = true
            pcall(scan_chunk, region.allocation_base, math.min(PROBE_BYTES, region.size))
        end
        if os.clock() >= deadline then return false end
    end
    probe.done = true
    if complete() and skip_low then return true end
    while scan.index <= #scan.regions do
        local region = scan.regions[scan.index]
        if scan.cursor >= region.size then
            scan.index = scan.index + 1
            scan.cursor = 0
        else
            local take = math.min(CHUNK, region.size - scan.cursor)
            pcall(scan_chunk, region.base + scan.cursor, take)
            scan.cursor = scan.cursor + math.max(take - scan.overlap, 1)
            if os.clock() >= deadline then return false end
        end
    end
    return true
end

-- ---------------------------------------------------------------- single-purpose 20m tests
-- Mode LINK: re-point *only the LIFT-182 component* from ExplosionInfo 254 to
-- the actual G-3 smoke ExplosionInfo 28. This replaces the original arrival
-- damage; it does NOT emit a second simultaneous explosion.
-- We also widen the shared G-3 Smoke record to 20m. WARNING: affects all
-- G-3 smoke blasts on this client, not just the Warp Pack.
-- Mode FUSION: keep explosion 254 and its DamageInfo 480, attach Smoke volume
-- fields using the minimal Shellshock-proven +100/+104 pair and optionally
-- display the smoke particle resource. Outer radius becomes 20m, so the
-- original explosion's damage falloff may now reach out to 20m! Solo tests ONLY.
-- No teleport range/geometry/heat/collision/large-unit safety fields touched.
local function site_for(label)
    for _, site in ipairs(sites) do
        if site.target.label == label then return site end
    end
end
local function chunk(blob, off, len)
    return blob:sub(off + 1, off + len)
end
local function hexbytes(blob)
    return (blob:gsub('.', function(c) return string.format('%02X ', string.byte(c)) end))
end
local function patch_transaction(edits)
    -- Refuse unexpected baselines; multiple independent records verified and
    -- rollback attempted if a write/read-back fails. Does not guard gameplay.
    local done={}
    for i,e in ipairs(edits) do
        local current=api.read(e.address, #e.before)
        if current ~= e.before then
            for j=#done,1,-1 do api.write(done[j].address, done[j].before) end
            return false, 'concurrent data change before '..e.reason
        end
        if not api.write(e.address, e.after) then
            for j=#done,1,-1 do api.write(done[j].address, done[j].before) end
            return false, 'write failed at '..e.reason
        end
        if api.read(e.address, #e.after) ~= e.after then
            api.write(e.address, e.before)
            for j=#done,1,-1 do api.write(done[j].address, done[j].before) end
            return false, 'readback mismatch at '..e.reason
        end
        done[#done+1]=e
        log('VERIFIED '..e.reason..' before='..hexbytes(e.before)..' after='..hexbytes(e.after))
    end
    return true, 'all '..#done..' guarded writes verified'
end
local function apply_fusion()
    local a, w, s=site_for('Warp Pack'),site_for('Warp Explosion'),site_for('G-3 Smoke Explosion')
    if not a or not w or not s then return false,'incomplete record discovery' end
    local ab=api.read(a.record,632)
    local wb=api.read(w.record,152)
    local sb=api.read(s.record,152)
    if not ab or not wb or not sb then return false,'record readback failed' end
    if u32(ab,56) ~= 254 then return false,'warp component no longer points at ExplosionInfo 254; disable conflicting mods and restart' end
    if u32(wb,0) ~= 254 or u32(wb,4) ~= 480 then return false,'unexpected original explosion/damage identity' end
    if u32(sb,0) ~= 28 or u32(sb,4) ~= 0
        or u32(sb,16) ~= 0x41000000 or u32(sb,20) ~= 0x41000000
        or u32(sb,100) ~= 14 or u32(sb,104) ~= 0x41F00000 then
        return false,'G-3 explosion record differs from the probed 1.007.100 layout; no edits made'
    end
    if u32(wb,116) ~= 1 then return false, 'Warp Explosion record +116 changed; no edits made' end
    for _,off in ipairs({16,20,24}) do
        local val=bits_to_f32(u32(wb,off))
        if val ~= val or val < 0 or val > 150 then
            return false,'implausible Warp radius at +'..off
        end
    end
    if SMOKE_MODE == 'link' then
        -- 0x41A00000 = 20.0f; source G-3 smoke radius is 8m.
        -- Keep shockwave member untouched; smoke radius is not a collision rule.
        local edits={
            {address=s.record+16,before=chunk(sb,16,4),after=f32_bytes(20.0),reason='G3_SMOKE_INNER_RADIUS_20M'},
            {address=s.record+20,before=chunk(sb,20,4),after=f32_bytes(20.0),reason='G3_SMOKE_OUTER_RADIUS_20M'},
            {address=a.record+56,before=chunk(ab,56,4),after=u32_bytes(28),reason='WARP_EXPLOSION_LINK_254_TO_28'},
        }
        local ok,why=patch_transaction(edits)
        if not ok then return false,why end
        if u32(api.read(a.record+56,4),0) ~= 28
           or u32(api.read(s.record+16,4),0) ~= 0x41A00000
           or u32(api.read(s.record+20,4),0) ~= 0x41A00000 then
            return false,'post-transaction values changed unexpectedly'
        end
        log('SMOKE20_LINK_VERIFIED: Warp now directly uses native G-3 Smoke Explosion 28; original Warp blast damage NOT delivered')
        log('WARNING: shared G-3 smoke radii now 20m; ALL G-3 grenades on this client may be affected; owner filtering NOT implemented')
        log('CAUTION: visible particle radius and actual AI occlusion MUST be verified in gameplay')
        return true,'SMOKE20_LINK_VERIFIED - test the actual smoke cloud in-game'
    elseif SMOKE_MODE == 'fusion' then
        -- Preserve inner radius. Enlarge only outer, which may increase damage range.
        if u32(wb,100) ~= 0 or u32(wb,104) ~= 0 then
            return false,'Warp persistent effect already set; remove v0.2.0 and retry'
        end
        local edits={
            {address=w.record+100,before=chunk(wb,100,4),after=u32_bytes(14),reason='WARP_NATIVE_SMOKE_TEMPLATE_14'},
            {address=w.record+104,before=chunk(wb,104,4),after=f32_bytes(30),reason='WARP_PERSISTENCE_30S'},
            {address=w.record+20,before=chunk(wb,20,4),after=f32_bytes(20),reason='WARP_OUTER_RADIUS_20M'},
            {address=w.record+56,before=chunk(wb,56,8),after=chunk(sb,56,8),reason='WARP_PARTICLE_SWAP_SMOKE'},
        }
        local ok,why=patch_transaction(edits)
        if not ok then return false,why end
        if u32(api.read(w.record,8),4)~=480 then
            return false,'DamageInfo reference changed unexpectedly'
        end
        log('FUSION20_WRITE_VERIFIED: Warp Explosion 254 & DamageInfo 480 preserved; SMOKE EFFECT NOT GUARANTEED')
        log('DANGER: original blast outer radius is now 20m; collateral damage possible')
        log('CAUTION: this does not spawn a second explosion, does not implement player ownership')
        return true,'FUSION20_WRITE_VERIFIED - experimental, may yield no smoke'
    end
    return false,'unknown mode'
end

-- ---------------------------------------------------------------- one-shot scan and guarded write
local BUS=nil
local next_action=0
local function tick()
    state.frame=state.frame+1
    if state.frame<START_FRAME or state.phase=='gave_up' then return end
    local now=os.time()
    if state.phase=='searching' then
        local ok,finished=pcall(scan_step)
        if not ok then
            set_status('gave_up','scan error: '..tostring(finished))
            if BUS then BUS.jobs[MOD.global]=nil end
            return
        end
        if not finished then return end
        if complete() then
            local ran,success,reason=pcall(apply_fusion)
            if not ran then
                state.refused=state.refused+1
                set_status('gave_up','fusion runtime error: '..tostring(success))
            elseif not success then
                state.refused=state.refused+1
                set_status('gave_up','fusion refused: '..tostring(reason))
            else
                set_status('active',tostring(reason))
            end
            if BUS then BUS.jobs[MOD.global]=nil end
        elseif state.rounds>=MAX_ROUNDS then
            set_status('gave_up','scan exhausted: '..summary())
            if BUS then BUS.jobs[MOD.global]=nil end
        else
            set_status('waiting','round '..state.rounds..' incomplete ('..summary()..')')
            next_action=now+ROUND_DELAY_SECONDS
        end
        return
    end
    if now<next_action then return end
    begin_round()
    state.phase='searching'
end
-- ---------------------------------------------------------------- startup
local ok, failure = pcall(function()
    local loader = rawget(_G, 'CowboyBingusModLoader')
    assert(type(loader) == 'table' and type(loader.api) == 'number' and loader.api >= 1,
           'Bingus Shared Loader v15 or newer (API 1) is required')
    assert(ffi_ok and ffi, 'LuaJIT FFI is unavailable')
    assert(ffi.abi('64bit'), 'Windows x64 is required')
    assert(type(update) == 'function', 'the game update hook is unavailable')
    api = build_api()
    log('LOADED v0.3.1 20m smoke experiment; mode='..SMOKE_MODE)
    local cell = ffi.new('float[1]')
    f32_bytes = function(value)
        cell[0] = value
        return ffi.string(cell, 4)
    end
    prepare_edits()
    self_addresses = { api.address_of(NEEDLE) }
    skip_low = (self_addresses[1] or LUA_HEAP_LIMIT) < LUA_HEAP_LIMIT
end)

if not ok then
    state.phase, state.status = 'gave_up', tostring(failure)
    print('[' .. MOD.global .. '] ' .. tostring(failure))
    if api then pcall(flush_log) end
    return
end

pcall(flush_log)
set_status('starting', 'mode='..SMOKE_MODE..'; waiting for game data')

-- Shared frame dispatcher used by the Bingus Shared Loader addon family, so the game's
-- update chain stays intact however many of these mods are installed.
BUS = rawget(_G, 'OCLAW_UPDATE_BUS')
if not BUS then
    BUS = { jobs = {}, base = update }
    if type(BUS.base) ~= 'function' then return end
    local dispatcher
    dispatcher = function(...)
        local ok, first, second = pcall(BUS.base, ...)
        for _, job in pairs(BUS.jobs) do pcall(job) end
        if ok then return first, second end
    end
    BUS.dispatcher = dispatcher
    _G.OCLAW_UPDATE_BUS = BUS
    update = dispatcher
end
BUS.jobs[MOD.global] = tick
