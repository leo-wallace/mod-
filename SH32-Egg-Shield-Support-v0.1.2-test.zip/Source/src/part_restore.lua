-- Independent implementation of state-snapshot recovery identified in
-- Vehicle Supply Tower 1.2.7. No compiled third-party code is included.
return function(N,W,R,log,read_record)
    local P={samples={},reported={}}
    local bit=require('bit')
    local function key(d)return d.entity..':'..d.unit..':'..d.goid..':'..d.resource end
    local function mask_address(g,d,rec)
        -- Locator and schema recovered from the supplied tower's MASK resolver.
        local p=N.base+16620864
        local b=N.win.read(p,211)
        if not b or b:sub(1,4)~='\072\131\236\008'
            or b:sub(19,21)~='\076\139\021'
            or b:sub(205,207)~='\072\139\077'
            or N.u32(b,83)~=24 or N.u32(b,60)~=32
            or N.u32(b,207)~=64 then return nil end
        local root=p+18+7+N.i32(b,21)
        local mgr=N.ptr(g:watch(root,8),0)
        if mgr<65536 then return nil end
        local idx=g:lookup(g:table(mgr+24),d.entity)
        if idx==nil then return nil end
        local refs=N.ptr(g:watch(mgr+48,8),0)
        local rows=N.ptr(g:watch(mgr+64,8),0)
        if refs<65536 or rows<65536 or N.ptr(g:watch(refs+idx*8,8),0)~=rec then return nil end
        return rows+idx*8
    end
    local function access(v)
        local rec,data,zc,hd,cfg=read_record(v)
        if hd.flags%2~=1 then return nil end
        local g=N.sample_graph();local hm=g:root('health');g:roundtrip(g:root('network'),v.d)
        local idx,d=g:component(hm,v.d.entity,0x1030,0x1048)
        if idx==nil or not N.same(d,v.d) or d.flags%2~=1 then return nil end
        if N.ptr(g:watch(hm+0x1058,8),0)+idx*0x1B8~=rec then return nil end
        local ext=N.ptr(g:watch(hm+0x1060,8),0)+idx*28
        local ep=g:watch(ext,28)
        local ma=mask_address(g,v.d,rec)
        local mask=ma and N.u32(g:watch(ma,4),0)
        local fresh=g:watch(rec,0x1B8)
        if fresh~=data then return nil end
        g:validate()
        return {rec=rec,data=data,zc=zc,cfg=cfg,ext=ext,ep=ep,ma=ma,mask=mask,g=g}
    end
    local function full(a)
        if N.u32(a.data,0x19C)~=0 or N.i32(a.data,0x14)<a.zc.mx then return false end
        for _,z in ipairs(a.zc.zones) do
            if z.max>0 and N.i32(a.data,0xF8+4*z.i)<z.max then return false end
        end
        return true
    end
    function P.observe(v)
        if v.kind~='arm' and v.kind~='exo' and v.kind~='frv' and v.kind~='tank' then return end
        local a=access(v);if not a then return end
        local k=key(v.d);local s=P.samples[k]
        if s and (s.rec~=a.rec or s.ext~=a.ext or s.cfg~=a.cfg) then P.samples[k]=nil;s=nil end
        if not s and full(a) then
            P.samples[k]={rec=a.rec,ext=a.ext,cfg=a.cfg,ep=a.ep,
                head=a.data:sub(17,32),tail=a.data:sub(417,432),mask=a.mask}
            log('part snapshot %s ent=%d model=%s',v.kind,v.d.entity,a.mask and 'ready' or 'unavailable')
        end
    end
    local function write_chunk(addr,raw)
        for i=0,#raw-1,4 do
            local old=N.win.read(addr+i,4);local new=raw:sub(i+1,i+4)
            if not old then return false end
            if old~=new and not W.i32(addr+i,N.i32(old,0),N.i32(new,0)) then return false end
        end
        return true
    end
    function P.restore(v)
        local a=access(v);if not a then return false end
        local k=key(v.d);local s=P.samples[k]
        if not s or s.rec~=a.rec or s.ext~=a.ext or s.cfg~=a.cfg then return false end
        local life=N.u32(a.data,0x19C)
        if life~=0 then
            if v.kind~='arm' or not R.arm_types[v.d.resource] then return false end
            local parent,why=R.arm_parent(v.d,a.g,true)
            if not parent then
                if not P.reported[k] then log('arm restore skip ent=%d: %s',v.d.entity,tostring(why));P.reported[k]=true end
                return false
            end
            a.g:validate()
            -- Same record chunks as the reference; never copy pointers or zone arrays.
            if not write_chunk(a.ext,s.ep) or not write_chunk(a.rec+0x10,s.head)
                or not write_chunk(a.rec+0x1A0,s.tail) then return false end
            local hp=N.i32(N.win.read(a.rec+0x14,4),0)
            if hp<=0 and not W.i32(a.rec+0x14,hp,1) then return false end
            if not W.u32(a.rec+0x19C,life,0) then return false end
            log('arm restored %s ent=%d life=%d->0 (snapshot; native repair follows)',v.d.resource,v.d.entity,life)
            a=access(v);if not a then return true end
        elseif v.kind=='arm' and N.i32(a.data,0x14)<=0 then
            local parent=R.arm_parent(v.d,a.g,true);if not parent then return false end
            a.g:validate()
            if not W.i32(a.rec+0x14,N.i32(a.data,0x14),1) then return false end
            log('arm restored %s ent=%d hp->1',v.d.resource,v.d.entity)
            a=access(v);if not a then return true end
        end
        if N.u32(a.data,0x19C)~=0 then return false end
        -- Clear only two-bit zone damage states whose corresponding HP is positive.
        local state=N.u32(a.data,0x20);local repaired=state
        for _,z in ipairs(a.zc.zones) do
            if z.i<16 and N.i32(a.data,0xF8+4*z.i)>0 then
                repaired=bit.band(repaired,bit.bnot(bit.lshift(3,2*z.i)))%4294967296
            end
        end
        a.g:validate()
        if repaired~=state and W.u32(a.rec+0x20,state,repaired) then
            log('part damage states restored ent=%d',v.d.entity)
        end
        if full(a) and a.ma and s.mask and a.mask~=s.mask then
            if W.u32(a.ma,a.mask,s.mask) then log('part model restored %s ent=%d mask=%08x->%08x',v.kind,v.d.entity,a.mask,s.mask) end
        end
        return life~=0
    end
    function P.prune(vehicles)
        local live={};for _,v in ipairs(vehicles) do live[key(v.d)]=true end
        for k in pairs(P.samples) do if not live[k] then P.samples[k]=nil;P.reported[k]=nil end end
    end
    function P.reset()P.samples={};P.reported={} end
    return P
end
