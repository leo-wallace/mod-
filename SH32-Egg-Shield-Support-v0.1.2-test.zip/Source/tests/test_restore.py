from pathlib import Path
from lupa import luajit21
import struct
L=luajit21.LuaRuntime(encoding=None); mem={}
def read(p,n):return bytes(mem.get(int(p)+i,0) for i in range(int(n)))
def write(p,b):
 for i,x in enumerate(b):mem[int(p)+i]=x
I=lambda x:struct.pack('<i',x);Q=lambda x:struct.pack('<Q',x)
L.globals().rd=read;L.globals().wr=write
L.execute(b'''
function u(s,o)local a,b,c,d=s:byte(o+1,o+4);return a+b*256+c*65536+d*16777216 end
function si(s,o)local x=u(s,o);return x>=2147483648 and x-4294967296 or x end
N={base=0,win={read=rd},u32=u,i32=si,ptr=function(s,o)return u(s,o)+u(s,o+4)*4294967296 end,same=function(a,b)return a==b end}
d={entity=1,unit=2,goid=3,resource='flame',flags=1};v={d=d,kind='arm'}
g={watch=function(self,p,n)return rd(p,n)end,root=function(self,n)return n=='health' and 1000 or 2000 end,
 roundtrip=function()end,component=function()return 0,d end,validate=function()end,
 table=function()return {} end,lookup=function()return 0 end}
N.sample_graph=function()return g end
W={i32=function(p,old,new)if si(rd(p,4),0)~=old then return false end;local ffi=require('ffi');local b=ffi.new('int32_t[1]',new);wr(p,ffi.string(b,4));return true end}
W.u32=function(p,old,new) return W.i32(p,old>=2147483648 and old-4294967296 or old,new>=2147483648 and new-4294967296 or new) end
parent_alive=true;R={arm_types={flame=true},arm_parent=function()return parent_alive and d or nil,'dead parent'end}
function record()return 10000,rd(10000,440),{mx=800,zones={{i=0,max=800}}},d,30000 end
logs={};function log(fmt,...)logs[#logs+1]=string.format(fmt,...)end
''')
# Real resolver signature fragments and immediate offsets, synthetic manager.
p=16620864;b=bytearray(211);b[:4]=bytes([72,131,236,8]);b[18:21]=bytes([76,139,21]);b[21:25]=I(50000-(p+25));b[204:207]=bytes([72,139,77]);b[83:87]=I(24);b[60:64]=I(32);b[207:211]=I(64);write(p,b)
write(50000,Q(70000));write(70048,Q(71000));write(70064,Q(72000));write(71000,Q(10000));write(72000,I(15))
write(1000+0x1058,Q(10000));write(1000+0x1060,Q(20000));write(10020,I(800));write(10000+0xF8,I(800));write(20020,I(800));write(10000+0x1A0,I(123))
L.globals().factory=L.execute((Path(__file__).resolve().parents[1]/'src/part_restore.lua').read_bytes())
L.execute(b'P=factory(N,W,R,log,record);P.observe(v)')
write(10020,I(0));write(10000+0x19C,I(2));write(10000+0x1A0,I(999));write(72000,I(0))
L.execute(b'assert(P.restore(v))')
assert read(10000+0x19C,4)==I(0) and read(10020,4)==I(800)
assert read(10000+0x1A0,4)==I(123) and read(72000,4)==I(15)
print('PASS dead attached arm state recovery, snapshot fields and model mask restoration')
write(10000+0x19C,I(2));L.execute(b'parent_alive=false;assert(not P.restore(v))');assert read(10000+0x19C,4)==I(2)
L.execute(b'parent_alive=true;v.kind="exo";assert(not P.restore(v))');assert read(10000+0x19C,4)==I(2)
L.execute(b'v.kind="arm";d.goid=4;assert(not P.restore(v))');assert read(10000+0x19C,4)==I(2)
print('PASS dead parent, whole vehicle death and recycled entity rejection')
L.execute(b'd.goid=3');write(10000+0x19C,I(0));write(10000+0x20,I(2));write(10000+0xF8,I(-10));write(72000,I(0));L.execute(b'P.restore(v)');assert read(10000+0x20,4)==I(2) and read(72000,4)==I(0)
write(10000+0xF8,I(1));L.execute(b'P.restore(v)');assert read(10000+0x20,4)==I(0) and read(72000,4)==I(0)
write(10000+0xF8,I(800));L.execute(b'P.restore(v)');assert read(72000,4)==I(15)
L.execute(b'P.reset();assert(not P.restore(v))')
print('PASS negative zone remains damaged, recovered zone clears state, model waits for full repair, context reset')
