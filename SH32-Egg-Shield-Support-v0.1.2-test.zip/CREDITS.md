# Credits / 致谢

- **Shield Vehicle Resupply v0.25-menu-perf3**, by abaabaaba234, MIT License.
  https://github.com/abaabaaba234/shield-vehicle-resupply
  Commit: e06e88e4fcc68b53222a9f97dbb6cabe3ef0844f. Main service, repair, weapon/tyre fault modules and offline harness are adapted here; LICENSE retains the upstream notice. Changes: SH-32 equipment/life gating, moving centers, fast guard patrol gated by living SH-32 wearers, separate logs, fixed settings, independent wearer HP module.
- **Uses research from HD2Runtime by SkyeShade**
  https://github.com/SkyeShade/HD2Runtime
  User-provided HD2Runtime-master snapshot: domains/player_equipment.lua, domains/event_natives.lua, runtime/event_world.lua and scripts/generate_event_natives.py. Used facts: inventory ownership/SH-32 identity and layout guards; per-entity HealthExt maximum and its engine read guards; AddHealthFraction interface. No Runtime module or complete SDK is redistributed or required. This is an independent experimental integration, not an upstream endorsement.
- User-provided Health Rework (Casual, 160 hp, 3 regen) supplies the requested tuning only. Its stim and limb edits are not included. HUD Plus and Marie's Stronger Shields were reference inputs; neither is a dependency or redistributed.

- **DRIVER HUD 1.4.5** and **HUD 1.11.1**, by FireScallion, Copyright (c) 2026, MIT License
  https://github.com/FireScallion/DRIVER-HUD---HD2-Vehicle-HUD
  - `src/vendor/native_hud.lua`: HUD 1.11.1's `native.lua` (itself adapted from DRIVER HUD). It is used **unmodified**: the read-only native reader, code guards, Health record/config layout, and network entity round-trip checks.
  - `src/vendor/weapon_driverhud.lua`: the Magazine/Rounds weapon component layout and its code guards, from DRIVER HUD 1.4.5.
  - The vehicle/arm resource hashes in `src/body.lua` also come from these two mods.
  - The license text is included verbatim in `third_party/LICENSE-DRIVER-HUD.txt`.
- **Bingus Shared Loader v17**, by CowboyBingus. This is a required dependency and is **not** redistributed here. https://www.nexusmods.com/helldivers2/mods/16292
- Ammo capacities come from [helldivers.wiki.gg](https://helldivers.wiki.gg/) (checked 2026-09) and from in-game measurement.
- **filediver** by xypwn and contributors, BSD-3-Clause License — https://github.com/xypwn/filediver
  - The v0.13 healing uses the game's own regeneration; the `HealthComponent` field layout (offsets of
    `Health` / `HeathChangerate` / `HealthChangerateDisabled` / `HeathChangerateCooldown` /
    `RegenerationSegments` / `RegenerationChangerate`, and `DamageableZoneInfo.RegenerationEnabled`) comes from
    filediver's `datalibrary` package, which mirrors the game's plaintext data. No filediver code is redistributed here.
  - v0.15 corrects the per-zone offsets using the 64-bit metadata in
    [dl_library.dl_typelib.gz](https://github.com/xypwn/filediver/blob/master/datalibrary/dl_library.dl_typelib.gz),
    with a regression fixture extracted from its public generated_entities.dl_bin.gz.
    v0.14 incorrectly derived the offset from an incomplete hand-written Go structure.
    Its `OnHealScriptEvent` and `OnDeadDisableAllActors` fields are exposed as diagnostics; their presence
    is not treated as proof that detached models or physics actors can be restored.
  - v0.17 uses the same binary type metadata and public arm Health records to identify
    separate weapon HP pools, `Immortal`, `CausesDeathOnDeath` and `AffectsMainHealth`.
    [health_component.go](https://github.com/xypwn/filediver/blob/master/datalibrary/health_component.go)
    documents the immortal-zone behavior. Exact live engine clamping, damage routing
    and ongoing-fire suppression are not established by these data definitions.
- Helldivers 2 and its assets, names and identifiers belong to their respective owners. This project is not affiliated with or endorsed by Arrowhead, Sony, or the upstream authors.

- **Vehicle Supply Tower 1.0.1**, user-provided local reference (`mods/codex/vehicle_supply_tower`): its Lua implementation identifies the repair-drone wrapper, game repair ABI, VehicleApi getter/setter slots, four-wheel resource header and 48-byte intact tyre restoration. v0.16 also uses its guarded StatModifier locator/13-float stride, 0.75 leg-speed recovery, Attachable parent layout and upgraded arm resource identifiers. `src/repair_native.lua` implements these interfaces for the existing shield service, with its own ownership, configuration, selection, mapping and readback logic. The full supply-tower addon is not redistributed; its Tesla and ammo engine calls are not included. The reference has no detached-arm respawn/reattachment implementation.

- Vehicle Supply Tower 1.2.7, by M!ni$try0fSc!eиce, user-supplied release. Runtime layout and snapshot recovery observations informed the independent part_restore.lua implementation; no tower bytecode or source is redistributed. https://ayakamods.com/mods/vehicle-supply-tower-%E8%BD%BD%E5%85%B7%E8%A1%A5%E7%BB%99%E5%A1%94%EF%BC%81.4335/
