# P33 S11 unguided + S11 assets + reserve/refill 6 (0.1.2)

See README.zh-CN.md for installation and verification.

- Unguided mode: S11 projectile 125. Guided mode: original P33 projectile 152.
- Maximum spare rounds: 6. Refill: 6. Single-round chamber and starting reserve unchanged.
- Requests one S11 loadout package reference through a fingerprinted game interface, attempting to fix missing projectile and gas visuals.
- Requires the working Bingus Shared Loader v17/API 1 setup and game build 25480438. Replace the previous P33-S11 addon and restart the game.
- No model/particle assets or separate Armory Preview Cache installation required.
- Offline checks pass; the new asset loading and ammo changes require in-game testing.

Log: `%LOCALAPPDATA%/CowboyBingus/Helldivers2/Logs/P33S11Projectile.log`.
Resource reference readback is distinct from verified visual output.
