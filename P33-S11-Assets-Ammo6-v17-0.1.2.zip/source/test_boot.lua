local function scenario(option)
    local logs,cores,order={},{},{}
    local now,forwarded,asset_steps,asset_stops,asset_created=100,0,0,0,0
    local env=setmetatable({}, {__index=_G});env._G=env
    env.SPECS={{module_sha256='game',label='Projectile'},{module_sha256='game',label='Magazine'}}
    env.ASSET_SPEC={exe_sha256='exe'}
    env.print=function()end
    env.CowboyBingusModLoader={api=1,open_log=function(name)
        assert(name=='P33S11Projectile.log')
        return {write=function(_,s)logs[#logs+1]=s;return true end,flush=function()return true end,close=function()end}
    end}
    env.update=function(...)forwarded=forwarded+1;return select('#',...),... end
    env.shutdown=function(...)order[#order+1]='game_shutdown';return 'result',nil,select('#',...)end
    env.WindowsRead=function()return {
        module=function(n)return n and 0x10000000 or 0x20000000 end,
        module_hash=function(m)
            if m==0x10000000 then return option=='bad_game' and 'wrong' or 'game' end
            return option=='bad_exe' and 'wrong' or 'exe'
        end,
        time=function()return now end,read=function()return nil end}end
    env.WindowsWrite=function()return function()error('unexpected write')end end
    env.Core={new=function(_,_,s)
        local c={steps=0,stops=0}
        c.step=function()
            c.steps=c.steps+1
            if option=='mag_conflict' and s.label=='Magazine' then c.disabled=true;c.status='conflict'
            else c.lease={}end
        end
        c.stop=function()c.stops=c.stops+1;order[#order+1]='core_stop' end
        cores[#cores+1]=c;return c
    end}
    env.WindowsAssets=function()asset_created=asset_created+1;return {}end
    env.AssetLease={new=function()return {
        step=function()asset_steps=asset_steps+1 end,
        stop=function()asset_stops=asset_stops+1;order[#order+1]='asset_stop' end}end}
    local file=assert(io.open('p33_s11_012/source/boot.lua'));local source=file:read('*a');file:close()
    local m=assert(load(source,'@boot','t',env))()
    if option=='bad_game' then
        assert(m.disabled and #cores==0 and asset_created==0)
        assert(table.concat(logs):find('unsupported_game_dll_no_write',1,true));return
    end
    assert(env.update()==0)
    now=now+2.1
    local n,a,b=env.update('context',nil)
    assert(n==2 and a=='context' and b==nil and forwarded==2)
    if option=='mag_conflict' then
        assert(m.disabled and asset_created==0 and cores[1].stops==1);return
    end
    assert(cores[1].steps==2 and cores[2].steps==2 and not m.disabled)
    assert(table.concat(logs):find('reserve_max=6 refill=6',1,true))
    if option=='bad_exe' then
        assert(asset_created==0 and table.concat(logs):find('ASSET_DISABLED',1,true))
    else assert(asset_created==1 and asset_steps==2) end
    local first,second,third=env.shutdown('context',nil)
    assert(first=='result' and second==nil and third==2)
    assert(m.disabled and cores[1].stops==1 and cores[2].stops==1)
    if option~='bad_exe' then
        assert(asset_stops==1 and order[#order-1]=='game_shutdown' and order[#order]=='asset_stop')
    end
end
scenario('normal');scenario('bad_game');scenario('bad_exe');scenario('mag_conflict')
print('PASS API1 update arguments, two component patches, shutdown ordering/returns, build guards and conflict rollback')
