-- Synthetic memory + fake FFI verifies the native-call guards without calling a game.
local function fixture(mode)
    local lib=dofile('p33_s11_012/source/test_spec.lua')
    local spec=lib.ASSET_SPEC
    local game,exe=0x10000000,0x20000000
    local app,owner,tab,manager,allocator=0x30000000,0x31000000,0x32000000,0x40000000,0x41000000
    local regions={}
    local function put(at,bytes)regions[#regions+1]={at=at,bytes=bytes}end
    local function pointer(at,n)put(at,string.pack('<I8',n))end
    for i,sig in ipairs(spec.signatures)do
        local b=sig.bytes
        if mode=='bad_signature' and i==1 then b='\0'..b:sub(2) end
        put(game+sig.rva,b)
    end
    pointer(game+0x3326308,exe+0x27c8d80)
    pointer(exe+0x27c8d80+16,app)
    pointer(app+752,exe+0x320dd0);pointer(app+768,exe+0x321030)
    pointer(game+spec.owner_rva,owner);pointer(owner+spec.candidate_slot,tab)
    local map=spec.hashmap
    if mode=='bad_catalog' then map=map:sub(1,1000)..'\255'..map:sub(1002)end
    put(tab,map);put(tab+#map+spec.record_index*32,spec.original)
    pointer(game+0x347ceb0,manager);pointer(manager+16416,allocator)
    put(manager,string.pack('<I8I4I4I8I4I4',manager+32,mode=='bad_header' and 1000 or 1024,0,0,2,0))
    local state={count=2,calls=0,thread=7}
    local api={}
    function api.read(at,n)
        if at==manager+32 and n==16384 then
            local first=state.count>0 and (spec.package_bytes..string.pack('<I8',state.count)) or string.rep('\0',16)
            return first..string.pack('<I8I8',17,4)..string.rep('\0',16352)
        end
        for _,r in ipairs(regions)do
            if at>=r.at and at+n<=r.at+#r.bytes then return r.bytes:sub(at-r.at+1,at-r.at+n)end
        end
    end
    function api.pointer(b)
        if not b then return nil end
        local p=string.unpack('<I8',b)
        if p>=65536 and p<0x800000000000 then return p end
    end
    local ffi={cdef=function()end,new=function()return {}end,copy=function(out,b,n)assert(n==8);out.bytes=b end}
    function ffi.load(name)
        assert(name=='kernel32');return {GetCurrentThreadId=function()return state.thread end}
    end
    function ffi.cast(kind,value)
        if kind=='void *' then return value end
        assert(kind=='void (*)(void *,const uint64_t *,uint32_t)')
        local delta=value==game+0x12fe350 and 1 or value==game+0x12fe4e0 and -1
        assert(delta)
        return function(p,arg,n)
            assert(p==manager and arg.bytes==spec.package_bytes and n==1)
            state.calls=state.calls+1;state.count=state.count+delta
        end
    end
    local env=setmetatable({require=function(name)assert(name=='ffi');return ffi end},{__index=_G})
    local f=assert(io.open('p33_s11_012/source/windows_assets.lua'));local src=f:read('*a');f:close()
    local constructor=assert(load(src,'@windows_assets','t',env))()
    local ok,backend=pcall(constructor,api,game,exe,spec)
    return state,ok,backend
end
do
    local s,ok,b=fixture();assert(ok)
    local snap=b.snapshot();assert(snap and snap.count==2 and snap.total==2)
    assert(b.acquire(snap) and s.count==3 and s.calls==1)
    local outdated=snap
    local success=pcall(b.acquire,outdated);assert(not success and s.calls==1)
    assert(b.release(b.snapshot()) and s.count==2 and s.calls==2)
    s.thread=8;assert(not pcall(b.snapshot) and s.calls==2)
    print('PASS native adapter verified call arguments/counts; stale-count and wrong-thread guards')
end
do
    local s,ok=fixture('bad_signature');assert(not ok and s.calls==0)
    for _,mode in ipairs({'bad_catalog','bad_header'})do
        local t,success,b=fixture(mode);assert(success and not b.snapshot() and t.calls==0)
    end
    print('PASS native adapter refuses wrong instructions, full S11 catalogue mismatch, wrong manager layout')
end
