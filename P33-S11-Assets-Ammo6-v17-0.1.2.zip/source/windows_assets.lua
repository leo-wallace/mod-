-- Minimal S-11-only adapter for the game's existing package reference manager.
-- Interface evidence: CowboyBingus/ArmoryPreviewCache src/native.lua and
-- src/signatures.lua, build 25480438. This adapter does not copy its UI/cache code.
return function(api,game,exe,spec)
    local ffi=require('ffi')
    ffi.cdef[[uint32_t GetCurrentThreadId(void);]]
    local kernel=ffi.load('kernel32')
    local thread=tonumber(kernel.GetCurrentThreadId())
    local function main_thread()
        assert(tonumber(kernel.GetCurrentThreadId())==thread,'asset_wrong_thread')
    end
    local function u32(bytes,offset)
        assert(bytes and #bytes>=offset+4,'asset_short_read')
        local a,b,c,d=bytes:byte(offset+1,offset+4)
        return a+b*256+c*65536+d*16777216
    end
    local function ptr(at)
        return api.pointer(api.read(at,8))
    end
    for _,sig in ipairs(spec.signatures) do
        assert(api.read(game+sig.rva,#sig.bytes)==sig.bytes,'asset_native_signature_mismatch')
    end
    local function api_matches()
        local root=ptr(game+0x3326308)
        if root~=exe+0x27c8d80 then return false end
        local app=ptr(root+16)
        return app and ptr(app+752)==exe+0x320dd0 and ptr(app+768)==exe+0x321030
    end
    assert(api_matches(),'asset_engine_api_mismatch')
    local function catalog_matches()
        local owner=ptr(game+spec.owner_rva)
        if not owner then return false end
        local tab=ptr(owner+spec.candidate_slot)
        if not tab then return false end
        for offset=0,#spec.hashmap-1,2048 do
            local bytes=spec.hashmap:sub(offset+1,offset+2048)
            if api.read(tab+offset,#bytes)~=bytes then return false end
        end
        return api.read(tab+#spec.hashmap+spec.record_index*32,32)==spec.original
    end
    local argument=ffi.new('uint64_t[1]')
    ffi.copy(argument,spec.package_bytes,8)
    local acquire_fn=ffi.cast('void (*)(void *,const uint64_t *,uint32_t)',game+0x12fe350)
    local release_fn=ffi.cast('void (*)(void *,const uint64_t *,uint32_t)',game+0x12fe4e0)
    local zero=string.rep('\0',8)
    local backend={}
    function backend.snapshot()
        main_thread()
        if not api_matches() then return nil,'engine_api_unavailable' end
        if not catalog_matches() then return nil,'S11_catalog_not_ready_or_mismatch' end
        local manager=ptr(game+0x347ceb0)
        if not manager then return nil,'package_manager_not_ready' end
        local header=api.read(manager,32)
        if not header or api.pointer(header)~=manager+32 or u32(header,8)~=1024
            or header:sub(17,24)~=zero or u32(header,24)~=2 then
            return nil,'package_manager_layout_mismatch'
        end
        local allocator=ptr(manager+16416)
        if not allocator then return nil,'package_allocator_not_ready' end
        local rows=api.read(manager+32,16384)
        if not rows then return nil,'package_rows_unreadable' end
        local count,total,seen=0,0,{}
        for i=0,1023 do
            local offset=i*16
            local id=rows:sub(offset+1,offset+8)
            if id~=zero then
                local n=u32(rows,offset+8)
                if seen[id] or u32(rows,offset+12)~=0 or n<1 or n>=1000000 then
                    return nil,'package_reference_table_mismatch'
                end
                seen[id]=true;total=total+1
                if id==spec.package_bytes then count=n end
            end
        end
        if ptr(game+0x347ceb0)~=manager or ptr(manager+16416)~=allocator then
            return nil,'package_manager_changed_during_read'
        end
        return {owner=string.format('%.0f:%.0f',manager,allocator),pointer=manager,count=count,total=total}
    end
    local function change(before,delta)
        main_thread()
        local current=assert(backend.snapshot())
        assert(current.owner==before.owner and current.count==before.count,'asset_context_changed')
        if delta==1 then
            assert(current.count>0 or current.total<1008,'asset_reference_capacity')
            acquire_fn(ffi.cast('void *',current.pointer),argument,1)
        else
            assert(current.count>0,'asset_reference_missing')
            release_fn(ffi.cast('void *',current.pointer),argument,1)
        end
        local after=assert(backend.snapshot())
        assert(after.owner==before.owner and after.count==before.count+delta,'asset_reference_readback_mismatch')
        return true
    end
    function backend.acquire(before)return change(before,1)end
    function backend.release(before)return change(before,-1)end
    return backend
end
