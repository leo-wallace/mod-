-- Hold exactly one S-11 package reference while this addon is running.
-- Engine function addresses/layouts are checked by WindowsAssets before use.
local AssetLease = {}
function AssetLease.new(backend, emit)
    local self={held=nil, disabled=false, status='waiting', polls=0}
    local function status(value)
        if self.status~=value then self.status=value;emit(value) end
    end
    function self.step()
        if self.disabled then return end
        local snapshot,why=backend.snapshot()
        if not snapshot then
            self.polls=self.polls+1
            status('ASSET_WAIT '..tostring(why))
            if self.polls>=150 then
                self.disabled=true;status('ASSET_TIMEOUT no_new_reference visual_fix_UNVERIFIED')
            end
            return
        end
        if self.held then
            if self.held.owner==snapshot.owner and snapshot.count>0 then return end
            -- A retired manager owns its old references; never release via a stale pointer.
            self.held=nil
            status('ASSET_MANAGER_CHANGED old_reference_retired')
        end
        if snapshot.total>=1008 and snapshot.count==0 then
            self.disabled=true;status('ASSET_TABLE_FULL no_acquire');return
        end
        -- No retries after an uncertain native call: they could duplicate a reference.
        local ok,result=pcall(backend.acquire,snapshot)
        if not ok or result~=true then
            self.disabled=true;status('ASSET_ACQUIRE_FAILED '..tostring(result));return
        end
        self.held={owner=snapshot.owner}
        self.polls=0
        status('ASSET_REFERENCE_HELD package=70d708e5fd627493 reference_delta=1 visual_fix_UNVERIFIED')
    end
    function self.stop()
        self.disabled=true
        if not self.held then return true end
        local held=self.held
        local ok,snapshot=pcall(backend.snapshot)
        if not ok or not snapshot or snapshot.owner~=held.owner or snapshot.count==0 then
            self.held=nil;status('ASSET_STOP manager_retired_no_release');return false
        end
        local success,result=pcall(backend.release,snapshot)
        if success and result==true then
            self.held=nil;status('ASSET_REFERENCE_RELEASED reference_delta=-1');return true
        end
        status('ASSET_RELEASE_FAILED '..tostring(result));return false
    end
    return self
end
return AssetLease
