local function fixture(mode)
    local lib=dofile('p33_s11_012/source/test_spec.lua')
    local s=lib.SPECS[2]
    local game,owner,tab=0x10000000,0x20000000,0x31000000
    s.game=game
    local row=tab+#s.hashmap+s.record_index*s.record_size
    local data=s.original
    if mode=='conflict' then data=data:sub(1,136)..string.pack('<I4',2)..data:sub(141) end
    local slot,fail,writes=tab,mode=='partial',{}
    local api={}
    function api.read(at,n)
        if at==game+s.owner_rva then return string.pack('<I8',owner) end
        if at==owner+s.candidate_slot then return string.pack('<I8',slot) end
        if at>=tab and at+n<=tab+#s.hashmap then return s.hashmap:sub(at-tab+1,at-tab+n) end
        if at>=row and at+n<=row+#data then return data:sub(at-row+1,at-row+n) end
    end
    function api.pointer(b)if b then return string.unpack('<I8',b)end end
    function api.write(at,b)
        assert(at==row+144 and #b==8,'outside refill/max fields')
        writes[#writes+1]=b
        if fail then fail=false;data=data:sub(1,144)..b:sub(1,4)..data:sub(149);return false end
        data=data:sub(1,144)..b..data:sub(153);return true
    end
    return {s=s,c=lib.Core.new(api,function()end,s),writes=writes,data=function()return data end,
            relocate=function()slot=0x50000000 end}
end
do
    local f=fixture();f.c.step()
    assert(f.c.lease and not f.c.disabled and #f.writes==1)
    assert(string.unpack('<I4',f.data(),145)==6 and string.unpack('<I4',f.data(),149)==6)
    assert(f.data():sub(1,144)==f.s.original:sub(1,144) and f.data():sub(153)==f.s.original:sub(153))
    assert(string.unpack('<I4',f.data(),137)==1 and string.unpack('<I4',f.data(),141)==1)
    f.c.step();assert(#f.writes==1)
    assert(f.c.stop() and f.data()==f.s.original and #f.writes==2)
    print('PASS P33 reserve max 3->6, refill 2->6; chamber/starting reserve unchanged; restore/idempotence')
end
do
    local f=fixture('conflict');f.c.step();assert(f.c.disabled and #f.writes==0)
    local p=fixture('partial');p.c.step();assert(p.c.disabled and p.data()==p.s.original)
    local r=fixture();r.c.step();r.relocate();r.c.step();assert(r.c.disabled and not r.c.stop() and #r.writes==1)
    print('PASS magazine conflict refusal, partial-write rollback, stale-pointer refusal')
end
