local function fixture(mode)
    local lib=dofile('p33_s11_012/source/test_spec.lua')
    local s=lib.SPEC
    local game,owner,tab=0x10000000,0x20000000,0x30000000
    s.game=game
    local row_at=tab+#s.hashmap+s.record_index*s.record_size
    local data=s.original
    if mode=='mismatch' then data=data:sub(1,8)..'\255'..data:sub(10) end
    local map=s.hashmap
    if mode=='wrongmap' then map=map:sub(1,100)..'\255'..map:sub(102) end
    local writes,logs={},{}
    local slot=tab
    local fail=mode=='partial'
    local api={}
    function api.read(at,n)
        if at==game+s.owner_rva and n==8 then return string.pack('<I8',owner) end
        if at==owner+s.candidate_slot and n==8 then return string.pack('<I8',slot) end
        if at>=tab and at+n<=tab+#map then return map:sub(at-tab+1,at-tab+n) end
        if at>=row_at and at+n<=row_at+#data then return data:sub(at-row_at+1,at-row_at+n) end
    end
    function api.pointer(b)if b and #b==8 then return string.unpack('<I8',b)end end
    function api.write(at,b)
        writes[#writes+1]={at,b}
        assert(at==row_at+576 and #b==4,'write outside authorized mode field')
        if fail then fail=false;data=data:sub(1,576)..b:sub(1,1)..data:sub(578);return false end
        data=data:sub(1,576)..b..data:sub(581);return true
    end
    local c=lib.Core.new(api,function(x)logs[#logs+1]=x end,s)
    return {c=c,s=s,read=function()return data end,writes=writes,logs=logs,relocate=function()slot=0x50000000 end}
end
do
    local f=fixture();f.c.step()
    assert(f.c.lease and not f.c.disabled and #f.writes==1)
    assert(string.unpack('<I4',f.read())==152,'guided/base projectile changed')
    assert(string.unpack('<I4',f.read(),577)==125,'unguided mode not changed')
    assert(f.read():sub(1,576)==f.s.original:sub(1,576) and f.read():sub(581)==f.s.original:sub(581),'other weapon fields changed')
    assert(string.unpack('<f',f.read(),573)==150,'alternate velocity changed')
    assert(string.unpack('<I8',f.read(),41)==0xa1470a4dab237264,'missile entity changed')
    f.c.step();assert(#f.writes==1,'duplicate write')
    assert(f.c.stop());assert(f.read()==f.s.original and #f.writes==2)
    print('PASS exactly one 4-byte field write, mode 127->125; guided 152, velocity 150, entity and other fields unchanged; idempotent; restore')
end
do
    local f=fixture('mismatch');f.c.step();assert(f.c.disabled and #f.writes==0)
    print('PASS conflicting weapon data: no write')
end
do
    local f=fixture('wrongmap');f.c.step();assert(not f.c.lease and #f.writes==0)
    print('PASS wrong full component map: no write')
end
do
    local f=fixture('partial');f.c.step();assert(f.c.disabled and f.read()==f.s.original)
    print('PASS failed OS write with copied prefix: restored')
end
do
    local f=fixture();f.c.step();f.relocate();f.c.step();assert(f.c.disabled)
    assert(not f.c.stop() and #f.writes==1,'wrote through stale slot')
    print('PASS relocated table: no stale-address restore')
end
print('OFFLINE ONLY: guidance, gas triggering, gas damage and flight require live testing.')
