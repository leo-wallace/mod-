local key='P33S11ProjectileTest'
if rawget(_G,key) then return rawget(_G,key) end
local M={version='0.1.2-assets-ammo6',status='starting',disabled=false}
rawset(_G,key,M)
local loader=rawget(_G,'CowboyBingusModLoader')
local previous_update=rawget(_G,'update')
if type(loader)~='table' or loader.api~=1 or type(loader.open_log)~='function' or type(previous_update)~='function' then
    M.disabled=true;M.status='unsupported_loader_or_update';print('[P33S11Projectile] '..M.status);return M
end
local log,api,game,assets
local cores={}
local function emit(s)
    M.status=s
    if log then assert(log:write(os.date('!%Y-%m-%dT%H:%M:%SZ')..' '..s..'\n'));assert(log:flush()) end
    print('[P33S11Projectile] '..s)
end
local function stop_cores()
    for _,c in ipairs(cores) do pcall(c.core.stop) end
end
local ok,why=pcall(function()
    log=assert(loader.open_log('P33S11Projectile.log'))
    emit('startup version='..M.version..' loader_api='..tostring(loader.api)..' new_features_gameplay=UNVERIFIED')
    api=WindowsRead()
    game=assert(api.module('game.dll'),'game_dll_missing')
    assert(api.module_hash(game)==SPECS[1].module_sha256,'unsupported_game_dll_no_write')
    emit('game_hash_verified build=25480438')
    local raw_read=api.read
    api.read=function(at,n)
        if type(at)~='number' or type(n)~='number' or at<65536 or at+n>=0x800000000000
            or n<=0 or n>32768 or n%1~=0 then return nil end
        local chunks={}
        for i=0,n-1,2048 do
            local b=raw_read(at+i,math.min(2048,n-i));if not b then return nil end
            chunks[#chunks+1]=b
        end
        return table.concat(chunks)
    end
    api.write=WindowsWrite(api,emit)
    for _,s in ipairs(SPECS) do
        s.game=game
        local label=s.label
        cores[#cores+1]={label=label,core=Core.new(api,function(v)emit(label..' '..v)end,s)}
    end
end)
if not ok then
    M.disabled=true;stop_cores();pcall(emit,'startup_failed_no_write '..tostring(why))
    if log then pcall(function()log:close()end) end
    return M
end
local next_tick=0
local applied=false
local asset_attempted=false
local asset_unit_state
local function asset_step()
    if not asset_attempted then
        asset_attempted=true
        local success,err=pcall(function()
            local exe=assert(api.module(nil),'exe_missing')
            assert(api.module_hash(exe)==ASSET_SPEC.exe_sha256,'unsupported_exe_no_asset_call')
            assets=AssetLease.new(WindowsAssets(api,game,exe,ASSET_SPEC),emit)
            M.assets=assets
            emit('ASSET_API_VERIFIED build=25480438 S11_package=70d708e5fd627493')
        end)
        if not success then emit('ASSET_DISABLED '..tostring(err)..' projectile_and_ammo_continue');return end
    end
    if not assets or assets.disabled then return end
    local success,err=pcall(assets.step)
    if not success then
        assets.disabled=true;emit('ASSET_ERROR '..tostring(err));return
    end
    if assets.held then
        local engine=rawget(_G,'stingray')
        local app=type(engine)=='table' and engine.Application
        if type(app)=='table' and type(app.can_get)=='function' then
            local success,available=pcall(app.can_get,'unit','content/fac_helldivers/equipment/support_weapons/harpoon_gun/harpoon_gun')
            local state=success and tostring(available) or 'query_failed'
            if state~=asset_unit_state then
                asset_unit_state=state
                emit('ASSET_S11_WEAPON_AVAILABLE='..state..' projectile_and_gas_visuals_require_live_check')
            end
        end
    end
end
update=function(...)
    if not M.disabled then
        local success,err=pcall(function()
            local now=api.time()
            if now<next_tick then return end
            next_tick=now+2
            local all=true
            for _,c in ipairs(cores) do
                c.core.step()
                if c.core.disabled then
                    M.disabled=true;stop_cores()
                    emit('disabled component='..c.label..' reason='..tostring(c.core.status)..' send_this_log');return
                end
                if not c.core.lease then all=false end
            end
            if all then
                if not applied then
                    applied=true
                    emit('APPLIED_READBACK_OK guided_projectile=152 unguided_projectile=125 chamber_capacity=1 reserve_max=6 refill=6 starting_reserve=unchanged new_features_gameplay=UNVERIFIED')
                end
                asset_step()
            end
        end)
        if not success then
            M.disabled=true;stop_cores();pcall(emit,'runtime_error '..tostring(err))
        end
    end
    return previous_update(...)
end
local previous_shutdown=rawget(_G,'shutdown')
local unpack_values=unpack or table.unpack
local function packed(...)return {n=select('#',...),...}end
shutdown=function(...)
    M.disabled=true;stop_cores()
    -- Keep the S-11 reference while the game's own shutdown disposes of live units.
    local result
    if type(previous_shutdown)=='function' then result=packed(pcall(previous_shutdown,...)) end
    if assets then pcall(assets.stop) end
    if log then pcall(function()log:close()end) end
    if result then
        if not result[1] then error(result[2]) end
        return unpack_values(result,2,result.n)
    end
end
return M
