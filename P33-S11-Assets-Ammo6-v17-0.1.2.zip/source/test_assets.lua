local Lease=dofile('p33_s11_012/source/assets.lua')
local function fixture()
    local state={owner='A',count=2,total=10,ready=false,acquires=0,releases=0,logs={}}
    local backend={}
    function backend.snapshot()
        if not state.ready then return nil,'not_ready' end
        return {owner=state.owner,count=state.count,total=state.total}
    end
    function backend.acquire(s)
        state.acquires=state.acquires+1
        if state.fail then error('uncertain call') end
        assert(s.owner==state.owner and s.count==state.count)
        state.count=state.count+1;return true
    end
    function backend.release(s)
        state.releases=state.releases+1
        assert(s.owner==state.owner and s.count==state.count)
        state.count=state.count-1;return true
    end
    state.lease=Lease.new(backend,function(s)state.logs[#state.logs+1]=s end)
    return state
end
do
    local f=fixture();f.lease.step();assert(f.acquires==0)
    f.ready=true;f.lease.step();assert(f.count==3 and f.acquires==1 and f.lease.held)
    for _=1,10 do f.lease.step()end
    assert(f.acquires==1)
    f.count=8 -- Another mod/game owns additional references now.
    assert(f.lease.stop() and f.count==7 and f.releases==1)
    assert(f.lease.stop() and f.releases==1)
    print('PASS package initialization wait, one owned reference, external references preserved, balanced release')
end
do
    local f=fixture();f.ready=true;f.lease.step()
    f.owner='B';f.count=0;f.lease.step()
    assert(f.acquires==2 and f.releases==0 and f.count==1 and f.lease.held.owner=='B')
    f.owner='C';assert(not f.lease.stop() and f.releases==0)
    print('PASS retired manager: new acquisition, no stale-manager release')
end
do
    local f=fixture();f.ready=true;f.fail=true;f.lease.step();f.lease.step()
    assert(f.lease.disabled and not f.lease.held and f.acquires==1 and f.releases==0)
    local full=fixture();full.ready=true;full.total=1008;full.count=0;full.lease.step()
    assert(full.lease.disabled and full.acquires==0)
    local wait=fixture();for _=1,150 do wait.lease.step()end
    assert(wait.lease.disabled and wait.acquires==0)
    print('PASS uncertain-call no-retry, capacity guard, bounded initialization wait')
end
