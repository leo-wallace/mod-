Standalone BSL v17 addon for shared Fire, BurningHeavy, and Gas DoT x4. GasVar2 row 533 is intentionally excluded pending verification. See README.zh-CN.md.
