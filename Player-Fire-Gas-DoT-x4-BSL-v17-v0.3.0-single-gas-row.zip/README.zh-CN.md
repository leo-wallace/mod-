# 火焰与毒气 DoT ×4（BSL v17，0.3.0）

本版只修改三条已在游戏运行日志中成功匹配的共享 DoT 记录，不按玩家身份筛选；使用这些共享记录的其他单位也可能受影响。

| DoT 记录 | 原值（伤害 / 耐久伤害） | 新值 |
|---|---:|---:|
| Fire（519） | 100 / 100 | 400 / 400 |
| BurningHeavy（526） | 200 / 200 | 800 / 800 |
| Gas（532） | 25 / 25 | 100 / 100 |

**GasVar2（533）不修改。** 提取表中虽然存在 533 记录，但它是否是另一条实际生效的毒气 DoT、以及 75/75 字段含义尚未验证。Gas Mk2 持续时间不同，并不能单独证明它使用另一条伤害记录；本版不把该推断写入游戏内存。

武器直击、弹药、穿甲、硬直和电击直击保持原值。本次识别的数据表中没有确认独立电击 DoT 行。

## 安装
- 需要 Bingus Shared Loader v17 / API 1；不依赖 HD2Runtime。
- 在 MOD 管理器中停用并移除旧版 DoT ×4 包，只部署这一版，避免同一 BSL 模块入口重复。
- 部署后，BSL 日志中的 `mods/codex/gun_calibration` 应显示 `loaded`。

## 日志
日志名：`ElementalDotX4.log`，路径：`%LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\ElementalDotX4.log`。
启动行应包含 `startup version=0.3.0-fire-gas-single-row-x4`。三条记录都写入并读回后应出现：
`APPLIED_READBACK_OK rows=519,526,532 multiplier=4 gas_variant_533=NOT_MODIFIED_UNVERIFIED`
这只证明内存写入和读回完成，**不等于实战伤害已验证**。若出现 `ELEMENTAL_DOT_X4_DISABLED`，本 MOD 会恢复已由自身写入的记录并停止。
