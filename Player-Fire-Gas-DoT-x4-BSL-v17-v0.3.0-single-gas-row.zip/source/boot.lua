local key='CodexElementalDotX4'
if rawget(_G,key) then return rawget(_G,key) end
local M={version='0.3.0-fire-gas-single-row-x4',status='starting',disabled=false}
rawset(_G,key,M)
local loader=rawget(_G,'CowboyBingusModLoader')
local previous_update=rawget(_G,'update')
if type(loader)~='table' or loader.api~=1 or type(loader.open_log)~='function'
    or type(previous_update)~='function' then
    M.disabled=true;M.status='unsupported_loader_or_update'
    print('[ElementalDotX4] '..M.status);return M
end
local log,api
local cores={}
local function emit(message)
    local line=os.date('!%Y-%m-%dT%H:%M:%SZ')..' '..message
    if log then assert(log:write(line..'\n'));assert(log:flush()) end
    print('[ElementalDotX4] '..message)
    M.status=message
end
local function restore_all()
    for _,c in ipairs(cores) do pcall(c.core.stop) end
end
local ok,why=pcall(function()
    log=assert(loader.open_log('ElementalDotX4.log'),'log_unavailable')
    emit('startup version='..M.version..' build=25480438 scope=Fire+BurningHeavy+Gas_DoT gas_variant_533=NOT_MODIFIED_UNVERIFIED damage_pair=x4 direct_hit=UNCHANGED electric_DoT=NO_SEPARATE_ROW gameplay=UNVERIFIED')
    api=WindowsRead()
    local game=assert(api.module('game.dll'),'game_dll_missing')
    assert(api.module_hash(game)==SPEC.module_sha256,'unsupported_game_dll_no_write')
    emit('game_dll_hash_verified')
    local raw_read=api.read
    api.read=function(address,size)
        if type(address)~='number' or address<65536 or address+size>=0x800000000000
            or size<=0 or size>16384 or size%1~=0 then return nil end
        local parts={}
        for i=0,size-1,2048 do
            local data=raw_read(address+i,math.min(2048,size-i))
            if not data then return nil end
            parts[#parts+1]=data
        end
        return table.concat(parts)
    end
    api.write=WindowsWrite(api,emit)
    SPEC.game=game
    for _,component in ipairs(SPEC.components) do
        component.game=game;component.owner_rva=SPEC.owner_rva
        local label=component.label
        cores[#cores+1]={label=label,core=Core.new(api,function(s)emit(label..' '..s)end,component)}
    end
end)
if not ok then
    M.disabled=true;restore_all();pcall(emit,'startup_failed_no_write '..tostring(why))
    if log then pcall(function()log:close()end)end
    return M
end
local next_tick=0
local applied=false
update=function(...)
    if not M.disabled then
        local success,err=pcall(function()
            local now=api.time()
            if now<next_tick then return end
            next_tick=now+2
            local all=true
            for _,c in ipairs(cores) do
                c.core.step()
                if c.core.disabled then
                    M.disabled=true;restore_all()
                    emit('ELEMENTAL_DOT_X4_DISABLED component='..c.label..' reason='..tostring(c.core.status)..' no_partial_writes')
                    return
                end
                if not c.core.lease then all=false end
            end
            if all and not applied then
                applied=true
                emit('APPLIED_READBACK_OK rows=519,526,532 multiplier=4 gas_variant_533=NOT_MODIFIED_UNVERIFIED direct_hit=UNCHANGED electric_DoT=NOT_FOUND gameplay=UNVERIFIED')
            end
        end)
        if not success then
            M.disabled=true;restore_all();pcall(emit,'runtime_error '..tostring(err))
        end
    end
    return previous_update(...)
end
local previous_shutdown=rawget(_G,'shutdown')
shutdown=function(...)
    M.disabled=true;restore_all();pcall(emit,'shutdown')
    if log then pcall(function()log:close()end)end
    if type(previous_shutdown)=='function' then return previous_shutdown(...)end
end
return M
