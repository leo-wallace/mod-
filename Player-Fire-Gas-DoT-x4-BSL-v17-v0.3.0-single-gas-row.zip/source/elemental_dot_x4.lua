-- HD2-Addon: mods/codex/gun_calibration
local Core=(function()
-- Guarded static DamageSettings row patch.
-- No fixed address is sufficient evidence: the complete component map and
-- the complete target template must match before a write is allowed.
local Core = {}
function Core.new(api, emit, spec)
    local size=spec.record_size or 616
    assert(#spec.original==size and (spec.direct or #spec.hashmap%16==0))
    local edits=spec.edits or {{offset=spec.edit_offset or 136,
        replacement=spec.replacement or '\0\0\128\63\0\0\128\63'}}
    local modified=spec.original
    local last=0
    for _,edit in ipairs(edits) do
        local ending=edit.offset+#edit.replacement
        assert(edit.offset>=last and #edit.replacement>0 and ending<=size)
        edit.before=spec.original:sub(edit.offset+1,ending)
        modified=modified:sub(1,edit.offset)..edit.replacement..modified:sub(ending+1)
        last=ending
    end
    local self = {lease=nil, disabled=false, status=nil, scans=0}
    local function status(s)
        if self.status ~= s then emit(s); self.status=s end
    end
    local function pointer(at)
        local bytes=api.read(at,8)
        return bytes and api.pointer(bytes) or nil
    end
    local function owner()
        if spec.direct then return spec.game end
        return pointer(spec.game + spec.owner_rva)
    end
    local function map_matches(at)
        if not at then return false end
        if spec.direct then
            for _,guard in ipairs(spec.guards) do
                if api.read(at+guard.offset,#guard.bytes)~=guard.bytes then return false end
            end
            return true
        end
        -- Cheap non-zero fingerprint before comparing the entire map.
        local o=spec.map_probe_offset
        if api.read(at+o,32)~=spec.hashmap:sub(o+1,o+32) then return false end
        for i=0,#spec.hashmap-1,2048 do
            local chunk=spec.hashmap:sub(i+1,i+2048)
            if api.read(at+i,#chunk)~=chunk then return false end
        end
        return true
    end
    local function current(lease)
        return owner()==lease.owner and pointer(lease.slot)==lease.table
            and map_matches(lease.table)
    end
    local function write_ranges(lease,baseline,restore)
        local expected=baseline
        for _,edit in ipairs(edits) do
            if not current(lease) or api.read(lease.record,size)~=expected then return false end
            local bytes=restore and edit.before or edit.replacement
            emit(string.format('write_intent resource=%s index=%d slot=0x%x record=0x%x offset=%d bytes=%d',
                spec.resource,spec.record_index,lease.slot-lease.owner,lease.record,edit.offset,#bytes))
            local success,ok=pcall(api.write,lease.record+edit.offset,bytes)
            expected=expected:sub(1,edit.offset)..bytes..expected:sub(edit.offset+#bytes+1)
            if not success or not ok or api.read(lease.record,size)~=expected then return false end
        end
        return true
    end
    local function find(o)
        local candidate=pointer(o+spec.candidate_slot)
        if map_matches(candidate) then return o+spec.candidate_slot,candidate end
        if spec.direct then return nil end
        -- Build-specific direct slot, guarded by the complete map and target record.
        return nil
    end
    function self.stop()
        local lease=self.lease
        if not lease then return true end
        if not current(lease) then
            status('restore_context_changed_no_write'); return false
        end
        local row=api.read(lease.record,size)
        if row==spec.original then self.lease=nil; status('restored'); return true end
        if row~=modified then status('restore_record_changed_no_write'); return false end
        local ok=write_ranges(lease,modified,true)
        if not ok or api.read(lease.record,size)~=spec.original then
            status('restore_failed');return false
        end
        self.lease=nil;status('restored');return true
    end
    function self.step()
        if self.disabled then return end
        if self.lease then
            if not current(self.lease) or api.read(self.lease.record,size)~=modified then
                self.disabled=true;status('applied_template_changed_restart_required')
            end
            return
        end
        local o=owner()
        if not o then
            self.scans=self.scans+1
            if self.scans>=30 then self.disabled=true;status('entity_manager_timeout_no_write')
            else status('waiting_for_entity_manager') end
            return
        end
        local slot,table_at=find(o)
        if not table_at then
            self.scans=self.scans+1
            if self.scans>=30 then self.disabled=true;status('template_not_found_no_write')
            else status('waiting_for_matching_component_table') end
            return
        end
        local record=spec.direct and table_at or table_at+#spec.hashmap+spec.record_index*size
        local actual=api.read(record,size)
        if actual~=spec.original then
            self.disabled=true
            status(actual==modified and 'preexisting_modification_not_owned' or 'template_mismatch_no_write')
            if actual and actual~=modified then
                emit('observed_template_hex='..(actual:gsub('.',function(c) return string.format('%02x',c:byte()) end)))
            end
            return
        end
        local lease={owner=o,slot=slot,table=table_at,record=record}
        if not current(lease) or api.read(record,size)~=spec.original then
            status('context_changed_before_write');return
        end
        emit('original_template_hex='..(actual:gsub('.',function(c) return string.format('%02x',c:byte()) end)))
        self.lease=lease
        local ok=write_ranges(lease,spec.original,false)
        local after=api.read(record,size)
        if not ok or after~=modified then
            self.disabled=true
            -- A failed OS write can have copied a prefix. Roll back immediately
            -- only when every changed byte is one that this call intended.
            if after and current(lease) then
                local owned=true
                for i=1,size do
                    local v=after:byte(i)
                    if v~=spec.original:byte(i) and v~=modified:byte(i) then owned=false end
                end
                if owned then
                    write_ranges(lease,after,true)
                    if api.read(record,size)==spec.original then self.lease=nil end
                end
            end
            status('write_failed_or_readback_mismatch')
            -- Restore only if the entire expected record is present. Never
            -- overwrite an unexpected engine/mod configuration.
            self.stop()
            return
        end
        status('applied_template_gameplay_unverified')
    end
    return self
end
return Core

end)()
local WindowsRead=(function()
-- Adapted from HD2 C4 Quick Actions, MIT; see C4-LICENSE.txt.
-- Only OS read/hash APIs are declared. No game function pointer is invoked.
return function()
    local ffi=require('ffi')
    assert(ffi.os=='Windows' and ffi.abi('64bit'),'windows_x64_required')
    ffi.cdef [[
        void *GetModuleHandleA(const char *);
        uint32_t GetModuleFileNameW(void *,uint16_t *,uint32_t);
        void *GetCurrentProcess(void);
        int ReadProcessMemory(void *,const void *,void *,size_t,size_t *);
        uint64_t GetTickCount64(void);
        void *CreateFileW(const uint16_t *,uint32_t,uint32_t,void *,uint32_t,uint32_t,void *);
        int ReadFile(void *,void *,uint32_t,uint32_t *,void *);
        int CloseHandle(void *);
        int32_t BCryptOpenAlgorithmProvider(void **,const uint16_t *,const uint16_t *,uint32_t);
        int32_t BCryptCreateHash(void *,void **,void *,uint32_t,const void *,uint32_t,uint32_t);
        int32_t BCryptHashData(void *,const void *,uint32_t,uint32_t);
        int32_t BCryptFinishHash(void *,void *,uint32_t,uint32_t);
        int32_t BCryptDestroyHash(void *);
        int32_t BCryptCloseAlgorithmProvider(void *,uint32_t);
    ]]
    local k,b=ffi.load('kernel32'),ffi.load('bcrypt')
    local process=k.GetCurrentProcess()
    local api={}
    function api.time() return tonumber(k.GetTickCount64())/1000 end
    function api.module(name)
        local p=k.GetModuleHandleA(name)
        if p~=nil then return tonumber(ffi.cast('uintptr_t',p)) end
    end
    function api.pointer(data)
        if not data or #data<8 then return nil end
        local p=ffi.new('uintptr_t[1]')
        ffi.copy(p,data,8)
        if p[0]>=65536 and p[0]<0x800000000000 then return tonumber(p[0]) end
    end
    function api.read(address,size)
        assert(type(address)=='number' and address>=65536 and address+size<0x800000000000,'bad_read_address')
        assert(size>0 and size<=4096,'read_size_limit')
        local out,count=ffi.new('uint8_t[?]',size),ffi.new('size_t[1]')
        if k.ReadProcessMemory(process,ffi.cast('const void *',address),out,size,count)==0
            or tonumber(count[0])~=size then return nil end
        return ffi.string(out,size)
    end
    function api.module_hash(address)
        local path=ffi.new('uint16_t[32768]')
        local n=k.GetModuleFileNameW(ffi.cast('void *',address),path,32768)
        assert(n>0 and n<32768,'module_path_unavailable')
        local f=k.CreateFileW(path,0x80000000,7,nil,3,0x08000000,nil)
        assert(f~=ffi.cast('void *',-1),'module_file_unavailable')
        local algorithm,hash=ffi.new('void *[1]'),ffi.new('void *[1]')
        local ok,result=pcall(function()
            local name=ffi.new('uint16_t[7]',{83,72,65,50,53,54,0})
            assert(b.BCryptOpenAlgorithmProvider(algorithm,name,nil,0)==0,'sha256_provider')
            assert(b.BCryptCreateHash(algorithm[0],hash,nil,0,nil,0,0)==0,'sha256_create')
            local chunk,count=ffi.new('uint8_t[65536]'),ffi.new('uint32_t[1]')
            local total=0
            while true do
                assert(k.ReadFile(f,chunk,65536,count,nil)~=0,'module_file_read')
                if count[0]==0 then break end
                total=total+tonumber(count[0]);assert(total<=64*1024*1024,'module_file_size_limit')
                assert(b.BCryptHashData(hash[0],chunk,count[0],0)==0,'sha256_update')
            end
            local digest,parts=ffi.new('uint8_t[32]'),{}
            assert(b.BCryptFinishHash(hash[0],digest,32,0)==0,'sha256_finish')
            for i=0,31 do parts[#parts+1]=string.format('%02x',digest[i]) end
            return table.concat(parts)
        end)
        if hash[0]~=nil then b.BCryptDestroyHash(hash[0]) end
        if algorithm[0]~=nil then b.BCryptCloseAlgorithmProvider(algorithm[0],0) end
        k.CloseHandle(f)
        assert(ok,result)
        return result
    end
    return api
end


end)()
local WindowsWrite=(function()
-- Writes only the already identity-checked data ranges supplied by Core.
-- Read-only data may be writable briefly; original page protection is restored
-- before logging, returning, or allowing the original game update to resume.
return function(api,emit)
    local ffi=require('ffi')
    if not pcall(ffi.typeof,'STARM_FOUR_MEMORY_BASIC_INFORMATION') then ffi.cdef[[
        typedef struct {
            void *BaseAddress;
            void *AllocationBase;
            uint32_t AllocationProtect;
            uint16_t PartitionId;
            uint16_t Padding;
            size_t RegionSize;
            uint32_t State;
            uint32_t Protect;
            uint32_t Type;
        } STARM_FOUR_MEMORY_BASIC_INFORMATION;
        size_t VirtualQuery(const void *,void *,size_t);
        int VirtualProtect(void *,size_t,uint32_t,uint32_t *);
        int WriteProcessMemory(void *,void *,const void *,size_t,size_t *);
        uint32_t GetLastError(void);
    ]] end
    assert(ffi.sizeof('STARM_FOUR_MEMORY_BASIC_INFORMATION')==48,'unsupported_mbi_layout')
    local k=ffi.load('kernel32');local process=k.GetCurrentProcess()
    local query=ffi.cast('size_t (*)(const void *,void *,size_t)',k.VirtualQuery)
    return function(address,bytes)
        assert((#bytes==1 or #bytes==4 or #bytes==8 or #bytes==12 or #bytes==16 or #bytes==20) and address>=65536
            and address+#bytes<0x800000000000,'invalid_write')
        local at=ffi.cast('void *',address)
        local mbi=ffi.new('STARM_FOUR_MEMORY_BASIC_INFORMATION[1]')
        local n=ffi.new('size_t[1]')
        local old=ffi.new('uint32_t[1]')
        local unused=ffi.new('uint32_t[1]')
        local size=tonumber(query(at,mbi,ffi.sizeof(mbi[0])))
        local query_error=size==0 and tonumber(k.GetLastError()) or 0
        if size~=48 then emit('write_query_failed error='..query_error);return false end
        local base=tonumber(ffi.cast('uintptr_t',mbi[0].BaseAddress))
        local protection=tonumber(mbi[0].Protect)
        emit(string.format('write_page address=0x%x state=0x%x protect=0x%x type=0x%x bytes=%d',
            address,tonumber(mbi[0].State),protection,tonumber(mbi[0].Type),#bytes))
        if mbi[0].State~=0x1000 or address<base or address+#bytes>base+tonumber(mbi[0].RegionSize)
            or (protection~=0x02 and protection~=0x04) then
            emit('write_page_rejected_no_write');return false
        end
        local before=api.read(address,#bytes)
        if not before then emit('write_before_read_failed');return false end
        local changed=false
        if protection==0x02 then
            if k.VirtualProtect(at,#bytes,0x04,old)==0 then
                local err=tonumber(k.GetLastError())
                emit('write_make_writable_failed error='..err);return false
            end
            changed=true
        end
        -- No file/log calls in the temporary writable interval. Always restore
        -- the protection even if an FFI/read call raises a Lua error.
        local success,write_ok,count,write_error,readback=pcall(function()
            if changed and tonumber(old[0])~=protection then return false,0,0,'protection_changed' end
            if api.read(address,#bytes)~=before then return false,0,0,'data_changed' end
            local ok=k.WriteProcessMemory(process,at,bytes,#bytes,n)~=0
            local err=not ok and tonumber(k.GetLastError()) or 0
            return ok,tonumber(n[0]),err,api.read(address,#bytes)==bytes
        end)
        local restored=true
        local restore_error=0
        if changed then
            restored=k.VirtualProtect(at,#bytes,old[0],unused)~=0
            if not restored then
                restore_error=tonumber(k.GetLastError())
                restored=k.VirtualProtect(at,#bytes,old[0],unused)~=0
                if not restored then restore_error=tonumber(k.GetLastError()) end
            end
        end
        if not success then
            emit('write_exception '..tostring(write_ok)..' protection_restored='..tostring(restored))
            return false
        end
        emit(string.format('write_result ok=%s written=%d error=%d readback=%s protection_changed=%s protection_restored=%s restore_error=%d',
            tostring(write_ok),count,write_error,tostring(readback),tostring(changed),tostring(restored),restore_error))
        return write_ok and count==#bytes and readback==true and restored
    end
end

end)()
local function unhex(s) return (s:gsub("..",function(x) return string.char(tonumber(x,16)) end)) end
local SPEC={module_sha256="2e2c3b7c2500646dadd5f2b4c6e0504dbb7e7896139f64cddc0d1813c718f51e",owner_rva=54973760,components={
{group="ELEMENTAL_DOT_X4",label="DamageInfo.Fire_DoT",resource="damage:519",record_size=76,record_index=513,candidate_slot=58487032,original=unhex("07020000640000006400000004000000040000000400000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000"),direct=true,guards={{offset=-76,bytes=unhex("0602000096000000960000000500000005000000050000000000000014000000000000000000000007000000050000000000803f000000000000000000000000000000000000000000000000")},{offset=76,bytes=unhex("0802000064000000640000000700000007000000070000000000000000000000000000000000000001000000050000000000a040000000000000000000000000000000000000000000000000")}},edits={{offset=4,replacement=unhex("9001000090010000")}}},
{group="ELEMENTAL_DOT_X4",label="DamageInfo.BurningHeavy_DoT",resource="damage:526",record_size=76,record_index=521,candidate_slot=58487088,original=unhex("0e020000c8000000c800000004000000040000000400000000000000000000000000000000000000010000000000000000000000000000000000000000000000000000000000000000000000"),direct=true,guards={{offset=-76,bytes=unhex("0d020000e8030000e803000000000000000000000000000000000000140000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000")},{offset=76,bytes=unhex("0f0200000a0000000a00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000")}},edits={{offset=4,replacement=unhex("2003000020030000")}}},
{group="ELEMENTAL_DOT_X4",label="DamageInfo.Gas_DoT",resource="damage:532",record_size=76,record_index=527,candidate_slot=58487136,original=unhex("14020000190000001900000006000000060000000600000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000000000000"),direct=true,guards={{offset=-76,bytes=unhex("13020000020000000000000001000000010000000100000000000000000000000000000000000000040000000000000000000000000000000000000000000000000000000000000000000000")},{offset=76,bytes=unhex("150200004b0000004b00000006000000060000000600000000000000000000000000000000000000050000000000000000000000000000000000000000000000000000000000000000000000")}},edits={{offset=4,replacement=unhex("6400000064000000")}}},
}}
local key='CodexElementalDotX4'
if rawget(_G,key) then return rawget(_G,key) end
local M={version='0.3.0-fire-gas-single-row-x4',status='starting',disabled=false}
rawset(_G,key,M)
local loader=rawget(_G,'CowboyBingusModLoader')
local previous_update=rawget(_G,'update')
if type(loader)~='table' or loader.api~=1 or type(loader.open_log)~='function'
    or type(previous_update)~='function' then
    M.disabled=true;M.status='unsupported_loader_or_update'
    print('[ElementalDotX4] '..M.status);return M
end
local log,api
local cores={}
local function emit(message)
    local line=os.date('!%Y-%m-%dT%H:%M:%SZ')..' '..message
    if log then assert(log:write(line..'\n'));assert(log:flush()) end
    print('[ElementalDotX4] '..message)
    M.status=message
end
local function restore_all()
    for _,c in ipairs(cores) do pcall(c.core.stop) end
end
local ok,why=pcall(function()
    log=assert(loader.open_log('ElementalDotX4.log'),'log_unavailable')
    emit('startup version='..M.version..' build=25480438 scope=Fire+BurningHeavy+Gas_DoT gas_variant_533=NOT_MODIFIED_UNVERIFIED damage_pair=x4 direct_hit=UNCHANGED electric_DoT=NO_SEPARATE_ROW gameplay=UNVERIFIED')
    api=WindowsRead()
    local game=assert(api.module('game.dll'),'game_dll_missing')
    assert(api.module_hash(game)==SPEC.module_sha256,'unsupported_game_dll_no_write')
    emit('game_dll_hash_verified')
    local raw_read=api.read
    api.read=function(address,size)
        if type(address)~='number' or address<65536 or address+size>=0x800000000000
            or size<=0 or size>16384 or size%1~=0 then return nil end
        local parts={}
        for i=0,size-1,2048 do
            local data=raw_read(address+i,math.min(2048,size-i))
            if not data then return nil end
            parts[#parts+1]=data
        end
        return table.concat(parts)
    end
    api.write=WindowsWrite(api,emit)
    SPEC.game=game
    for _,component in ipairs(SPEC.components) do
        component.game=game;component.owner_rva=SPEC.owner_rva
        local label=component.label
        cores[#cores+1]={label=label,core=Core.new(api,function(s)emit(label..' '..s)end,component)}
    end
end)
if not ok then
    M.disabled=true;restore_all();pcall(emit,'startup_failed_no_write '..tostring(why))
    if log then pcall(function()log:close()end)end
    return M
end
local next_tick=0
local applied=false
update=function(...)
    if not M.disabled then
        local success,err=pcall(function()
            local now=api.time()
            if now<next_tick then return end
            next_tick=now+2
            local all=true
            for _,c in ipairs(cores) do
                c.core.step()
                if c.core.disabled then
                    M.disabled=true;restore_all()
                    emit('ELEMENTAL_DOT_X4_DISABLED component='..c.label..' reason='..tostring(c.core.status)..' no_partial_writes')
                    return
                end
                if not c.core.lease then all=false end
            end
            if all and not applied then
                applied=true
                emit('APPLIED_READBACK_OK rows=519,526,532 multiplier=4 gas_variant_533=NOT_MODIFIED_UNVERIFIED direct_hit=UNCHANGED electric_DoT=NOT_FOUND gameplay=UNVERIFIED')
            end
        end)
        if not success then
            M.disabled=true;restore_all();pcall(emit,'runtime_error '..tostring(err))
        end
    end
    return previous_update(...)
end
local previous_shutdown=rawget(_G,'shutdown')
shutdown=function(...)
    M.disabled=true;restore_all();pcall(emit,'shutdown')
    if log then pcall(function()log:close()end)end
    if type(previous_shutdown)=='function' then return previous_shutdown(...)end
end
return M
