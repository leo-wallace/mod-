local WindowsRead=(function()
-- Adapted from HD2 C4 Quick Actions, MIT; see C4-LICENSE.txt.
-- Only OS read/hash APIs are declared. No game function pointer is invoked.
return function()
    local ffi=require('ffi')
    assert(ffi.os=='Windows' and ffi.abi('64bit'),'windows_x64_required')
    ffi.cdef [[
        void *GetModuleHandleA(const char *);
        uint32_t GetModuleFileNameW(void *,uint16_t *,uint32_t);
        void *GetCurrentProcess(void);
        int ReadProcessMemory(void *,const void *,void *,size_t,size_t *);
        uint64_t GetTickCount64(void);
        void *CreateFileW(const uint16_t *,uint32_t,uint32_t,void *,uint32_t,uint32_t,void *);
        int ReadFile(void *,void *,uint32_t,uint32_t *,void *);
        int CloseHandle(void *);
        int32_t BCryptOpenAlgorithmProvider(void **,const uint16_t *,const uint16_t *,uint32_t);
        int32_t BCryptCreateHash(void *,void **,void *,uint32_t,const void *,uint32_t,uint32_t);
        int32_t BCryptHashData(void *,const void *,uint32_t,uint32_t);
        int32_t BCryptFinishHash(void *,void *,uint32_t,uint32_t);
        int32_t BCryptDestroyHash(void *);
        int32_t BCryptCloseAlgorithmProvider(void *,uint32_t);
    ]]
    local k,b=ffi.load('kernel32'),ffi.load('bcrypt')
    local process=k.GetCurrentProcess()
    local api={}
    function api.time() return tonumber(k.GetTickCount64())/1000 end
    function api.module(name)
        local p=k.GetModuleHandleA(name)
        if p~=nil then return tonumber(ffi.cast('uintptr_t',p)) end
    end
    function api.pointer(data)
        if not data or #data<8 then return nil end
        local p=ffi.new('uintptr_t[1]')
        ffi.copy(p,data,8)
        if p[0]>=65536 and p[0]<0x800000000000 then return tonumber(p[0]) end
    end
    function api.read(address,size)
        assert(type(address)=='number' and address>=65536 and address+size<0x800000000000,'bad_read_address')
        assert(size>0 and size<=4096,'read_size_limit')
        local out,count=ffi.new('uint8_t[?]',size),ffi.new('size_t[1]')
        if k.ReadProcessMemory(process,ffi.cast('const void *',address),out,size,count)==0
            or tonumber(count[0])~=size then return nil end
        return ffi.string(out,size)
    end
    function api.module_hash(address)
        local path=ffi.new('uint16_t[32768]')
        local n=k.GetModuleFileNameW(ffi.cast('void *',address),path,32768)
        assert(n>0 and n<32768,'module_path_unavailable')
        local f=k.CreateFileW(path,0x80000000,7,nil,3,0x08000000,nil)
        assert(f~=ffi.cast('void *',-1),'module_file_unavailable')
        local algorithm,hash=ffi.new('void *[1]'),ffi.new('void *[1]')
        local ok,result=pcall(function()
            local name=ffi.new('uint16_t[7]',{83,72,65,50,53,54,0})
            assert(b.BCryptOpenAlgorithmProvider(algorithm,name,nil,0)==0,'sha256_provider')
            assert(b.BCryptCreateHash(algorithm[0],hash,nil,0,nil,0,0)==0,'sha256_create')
            local chunk,count=ffi.new('uint8_t[65536]'),ffi.new('uint32_t[1]')
            local total=0
            while true do
                assert(k.ReadFile(f,chunk,65536,count,nil)~=0,'module_file_read')
                if count[0]==0 then break end
                total=total+tonumber(count[0]);assert(total<=64*1024*1024,'module_file_size_limit')
                assert(b.BCryptHashData(hash[0],chunk,count[0],0)==0,'sha256_update')
            end
            local digest,parts=ffi.new('uint8_t[32]'),{}
            assert(b.BCryptFinishHash(hash[0],digest,32,0)==0,'sha256_finish')
            for i=0,31 do parts[#parts+1]=string.format('%02x',digest[i]) end
            return table.concat(parts)
        end)
        if hash[0]~=nil then b.BCryptDestroyHash(hash[0]) end
        if algorithm[0]~=nil then b.BCryptCloseAlgorithmProvider(algorithm[0],0) end
        k.CloseHandle(f)
        assert(ok,result)
        return result
    end
    return api
end


end)()
local WindowsWrite=(function()
-- Writes only the already identity-checked data ranges supplied by Core.
-- Read-only data may be writable briefly; original page protection is restored
-- before logging, returning, or allowing the original game update to resume.
return function(api,emit)
    local ffi=require('ffi')
    if not pcall(ffi.typeof,'STARM_FOUR_MEMORY_BASIC_INFORMATION') then ffi.cdef[[
        typedef struct {
            void *BaseAddress;
            void *AllocationBase;
            uint32_t AllocationProtect;
            uint16_t PartitionId;
            uint16_t Padding;
            size_t RegionSize;
            uint32_t State;
            uint32_t Protect;
            uint32_t Type;
        } STARM_FOUR_MEMORY_BASIC_INFORMATION;
        size_t VirtualQuery(const void *,void *,size_t);
        int VirtualProtect(void *,size_t,uint32_t,uint32_t *);
        int WriteProcessMemory(void *,void *,const void *,size_t,size_t *);
        uint32_t GetLastError(void);
    ]] end
    assert(ffi.sizeof('STARM_FOUR_MEMORY_BASIC_INFORMATION')==48,'unsupported_mbi_layout')
    local k=ffi.load('kernel32');local process=k.GetCurrentProcess()
    local query=ffi.cast('size_t (*)(const void *,void *,size_t)',k.VirtualQuery)
    return function(address,bytes)
        assert((#bytes==1 or #bytes==4 or #bytes==8 or #bytes==12 or #bytes==16 or #bytes==20) and address>=65536
            and address+#bytes<0x800000000000,'invalid_write')
        local at=ffi.cast('void *',address)
        local mbi=ffi.new('STARM_FOUR_MEMORY_BASIC_INFORMATION[1]')
        local n=ffi.new('size_t[1]')
        local old=ffi.new('uint32_t[1]')
        local unused=ffi.new('uint32_t[1]')
        local size=tonumber(query(at,mbi,ffi.sizeof(mbi[0])))
        local query_error=size==0 and tonumber(k.GetLastError()) or 0
        if size~=48 then emit('write_query_failed error='..query_error);return false end
        local base=tonumber(ffi.cast('uintptr_t',mbi[0].BaseAddress))
        local protection=tonumber(mbi[0].Protect)
        emit(string.format('write_page address=0x%x state=0x%x protect=0x%x type=0x%x bytes=%d',
            address,tonumber(mbi[0].State),protection,tonumber(mbi[0].Type),#bytes))
        if mbi[0].State~=0x1000 or address<base or address+#bytes>base+tonumber(mbi[0].RegionSize)
            or (protection~=0x02 and protection~=0x04) then
            emit('write_page_rejected_no_write');return false
        end
        local before=api.read(address,#bytes)
        if not before then emit('write_before_read_failed');return false end
        local changed=false
        if protection==0x02 then
            if k.VirtualProtect(at,#bytes,0x04,old)==0 then
                local err=tonumber(k.GetLastError())
                emit('write_make_writable_failed error='..err);return false
            end
            changed=true
        end
        -- No file/log calls in the temporary writable interval. Always restore
        -- the protection even if an FFI/read call raises a Lua error.
        local success,write_ok,count,write_error,readback=pcall(function()
            if changed and tonumber(old[0])~=protection then return false,0,0,'protection_changed' end
            if api.read(address,#bytes)~=before then return false,0,0,'data_changed' end
            local ok=k.WriteProcessMemory(process,at,bytes,#bytes,n)~=0
            local err=not ok and tonumber(k.GetLastError()) or 0
            return ok,tonumber(n[0]),err,api.read(address,#bytes)==bytes
        end)
        local restored=true
        local restore_error=0
        if changed then
            restored=k.VirtualProtect(at,#bytes,old[0],unused)~=0
            if not restored then
                restore_error=tonumber(k.GetLastError())
                restored=k.VirtualProtect(at,#bytes,old[0],unused)~=0
                if not restored then restore_error=tonumber(k.GetLastError()) end
            end
        end
        if not success then
            emit('write_exception '..tostring(write_ok)..' protection_restored='..tostring(restored))
            return false
        end
        emit(string.format('write_result ok=%s written=%d error=%d readback=%s protection_changed=%s protection_restored=%s restore_error=%d',
            tostring(write_ok),count,write_error,tostring(readback),tostring(changed),tostring(restored),restore_error))
        return write_ok and count==#bytes and readback==true and restored
    end
end

end)()
