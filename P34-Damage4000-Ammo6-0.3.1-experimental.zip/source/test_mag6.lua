local f=assert(io.open('source/original_p34_mag.lua','rb'));local source=f:read('*a');f:close()
local a=assert(source:find('local api = (function()',1,true))
local b=assert(source:find('-- ⚠',a,true))
source=source:sub(1,a-1)..'local api = TEST_API\n'..source:sub(b)
local function pack(v)return string.char(v%256,math.floor(v/256)%256,math.floor(v/65536)%256,math.floor(v/16777216)%256)end
local function run(cap,refill,max,expected_writes)
 local game,owner,tab=100000,20000000,30000000
 local rec=tab+8640+235*160
 local row=string.rep('\0',136)..pack(cap)..pack(1)..pack(refill)..pack(max)..string.rep('\0',8)
 local original=row;local writes=0
 local api={time=function()return 0 end,module=function()return game end,pointer=tonumber,
 read=function(addr,n)
  if addr==game+0x346d540 then return tostring(owner)end
  if addr==owner-13616120 then return tostring(tab)end
  if addr>=rec and addr+n<=rec+160 then return row:sub(addr-rec+1,addr-rec+n)end
 end,
 write=function(addr,bytes)
  assert(addr==rec+144 and #bytes==8);assert(bytes==pack(6)..pack(6));writes=writes+1
  row=row:sub(1,144)..bytes..row:sub(153);return true
 end}
 local sink={write=function()return true end,flush=function()return true end,close=function()return true end}
 local env={TEST_API=api,os={getenv=function()return nil end,execute=function()return true end},io={open=function()return sink end},CowboyBingusModLoader={api=1,open_log=function()return sink end},update=function()end}
 env._G=env;setmetatable(env,{__index=_G})
 local M=assert(load(source,'mag6','t',env))()
 for i=1,650 do env.update(1/60)end
 assert(writes==expected_writes)
 if expected_writes==1 then assert(row==original:sub(1,144)..pack(6)..pack(6)..original:sub(153));assert(M.state.patched)
 else assert(row==original)end
end
run(1,1,2,1);run(1,6,6,0);run(2,1,2,0);run(1,2,3,0)
print('PASS ammo6: refill/max only, verified 6/6, idempotent, identity and old-mod conflicts refused')
