local make=dofile('source/thermite_core.lua')
local guards=dofile('source/test_guards.lua')
local function pack(v)return string.char(v%256,math.floor(v/256)%256,math.floor(v/65536)%256,math.floor(v/16777216)%256)end
local parts={};for _,v in ipairs({342,2000,2000,7,0,0,0,30,20,40,0,0,0,0,0,0,0,0,0})do parts[#parts+1]=pack(v)end
local original=table.concat(parts);assert(#original==76)
local function setup(opts)
 opts=opts or {};local game,p=100000,1000000;local at=p+212*76;local mem={};local writes=0
 local function put(a,s)for i=1,#s do mem[a+i-1]=s:sub(i,i)end end
 local function read(a,n)local out={};for i=0,n-1 do if not mem[a+i]then return nil end;out[#out+1]=mem[a+i]end;return table.concat(out)end
 put(game+58483808,'POINTER!');put(p-76,guards[1]);put(p+76,guards[2]);put(p,opts.pacmod and guards[4] or guards[3]);put(at,original)
 if opts.mismatch then put(at+12,pack(6))end
 if opts.duplicate then put(at+76,original)end
 if opts.badanchor then put(p-76,pack(999))end
 local api={read=read,pointer=function(s)if s=='POINTER!' then return p end end,write=function(a,s)
 writes=writes+1;assert(a==at+4 and #s==8);if opts.writefail then return false end;put(a,s);return true end}
 local core=make(api,function()end,game,guards)
 return core,function()return writes end,function()return read(at,76)end,put,at,game
end
for _,pacmod in ipairs({false,true})do
 local c,w,row=setup({pacmod=pacmod});c.step();assert(w()==1 and c.status=='applied_explosion4000_gameplay_UNVERIFIED');assert(row()==original:sub(1,4)..pack(4000)..pack(4000)..original:sub(13));c.step();assert(w()==1);assert(c.stop());assert(w()==2 and row()==original)
end
for _,case in ipairs({'mismatch','duplicate','badanchor'})do
 local c,w=setup({[case]=true});for i=1,31 do c.step()end;assert(w()==0 and c.disabled,case)
end
local c,w,row=setup({writefail=true});c.step();assert(c.disabled and w()==1 and row()==original)
local c,w,row,put,at=setup();c.step();put(at+4,pack(999));assert(not c.stop());assert(w()==1);c.step();assert(c.disabled)
local c,w,row,put,at,game=setup();c.step();put(game+58483808,'CHANGED!');assert(not c.stop() and w()==1)
print('PASS: exact 8-byte damage pair, EMS coexistence, idempotency, restore, mismatch/duplicate/anchor refusals, failed write, external mutation, stale pointer')
