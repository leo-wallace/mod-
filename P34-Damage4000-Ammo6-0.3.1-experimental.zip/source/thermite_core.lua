-- Bounded, anchored DamageInfo experiment. No per-hit Lua callback.
return function(api, emit, game, guards)
    local SIZE, SLOT = 76, 58483808
    local target = string.char(160,15,0,0,160,15,0,0)
    local function u32(s,o)
        if not s or #s<o+4 then return nil end
        return s:byte(o+1)+s:byte(o+2)*256+s:byte(o+3)*65536+s:byte(o+4)*16777216
    end
    local function hex(s)
        return (s:gsub('.',function(c)return string.format('%02x',c:byte())end))
    end
    local function ptr(at)
        local s=api.read(at,8);return s and api.pointer(s)
    end
    local function anchor()
        local p=ptr(game+SLOT)
        if not p then return nil end
        if api.read(p-76,76)~=guards[1] or api.read(p+76,76)~=guards[2] then return nil end
        local row=api.read(p,76)
        -- Pacifier may already have been modified by the supplied EMS addon.
        if row~=guards[3] and row~=guards[4] then return nil end
        return p
    end
    local prefix={342,2000,2000,7,0,0,0,30,20,40,0}
    local function matches(row)
        if not row or #row~=SIZE then return false end
        for i,v in ipairs(prefix) do if u32(row,(i-1)*4)~=v then return false end end
        -- Reject additional statuses/flags that are not in this experiment's profile.
        return row:sub(45)==string.rep('\0',32)
    end
    local self={disabled=false,lease=nil,tries=0,status='waiting'}
    local function status(s) if self.status~=s then self.status=s;emit(s) end end
    local function current(l) return anchor()==l.anchor end
    function self.stop()
        local l=self.lease
        if not l then return true end
        if not current(l) then status('restore_context_changed_no_write');return false end
        local row=api.read(l.record,SIZE)
        if row==l.original then self.lease=nil;return true end
        if row~=l.modified then status('restore_record_changed_no_write');return false end
        local ok,res=pcall(api.write,l.record+4,l.original:sub(5,12))
        if not ok or not res or api.read(l.record,SIZE)~=l.original then
            status('restore_failed_restart_game');return false
        end
        self.lease=nil;status('restored');return true
    end
    function self.step()
        if self.disabled then return end
        if self.lease then
            if not current(self.lease) or api.read(self.lease.record,SIZE)~=self.lease.modified then
                self.disabled=true;status('record_changed_restart_required')
            end
            return
        end
        self.tries=self.tries+1
        local p=anchor()
        if not p then
            status('anchor_not_verified_no_write')
            if self.tries>=30 then self.disabled=true;status('anchor_timeout_no_write') end
            return
        end
        local found={}
        -- These are offsets from the verified Pacifier row, NOT DamageInfo IDs.
        for delta=1,640 do
            local at=p+delta*SIZE
            local row=api.read(at,SIZE)
            if matches(row) then found[#found+1]={record=at,original=row,delta=delta} end
        end
        if #found~=1 then
            self.disabled=true;status('candidate_count_'..#found..'_no_write');return
        end
        local l=found[1];l.anchor=p
        l.modified=l.original:sub(1,4)..target..l.original:sub(13)
        if not current(l) or api.read(l.record,SIZE)~=l.original then
            status('context_changed_before_write');return
        end
        emit(string.format('candidate_verified delta=%d record=0x%x original_hex=%s',l.delta,l.record,hex(l.original)))
        self.lease=l
        local ok,res=pcall(api.write,l.record+4,target)
        local after=api.read(l.record,SIZE)
        if not ok or not res or after~=l.modified then
            self.disabled=true
            -- Restore only our own complete expected modification.
            if after==l.modified then self.stop() end
            status('write_failed_or_readback_mismatch_restart_game');return
        end
        status('applied_explosion4000_gameplay_UNVERIFIED')
    end
    return self
end
