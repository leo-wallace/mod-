-- HD2-Addon: mods/dsh/p34_mag_write
--
-- 目标：P-34 Breacher
--   magazines_refill (每次补给给几个): 1 -> 6
--   magazines_max    (最大备弹量)     : 2 -> 6
--   其余字段一律不动。
--
-- 坐标与偏移（全部实测闭环，见 PLAYBOOK.md）：
--   game   = GetModuleHandleA("game.dll")
--   owner  = *(game + 0x346d540)
--   table  = *(owner - 13616120)
--   record = table + 8640 + 235*160            (idx=235)
--   字段（实测校准，比 typelib 再靠后 4 字节）：
--     +136 magazine_capacity
--     +140 magazines
--     +144 magazines_refill   <- 要改
--     +148 magazines_max      <- 要改
--
-- P-34 现值的实机验证（verify-only 版读出）：
--   +136=1  +140=1  +144=1  +148=2
--   与用户实机描述（容量 1 / 补给 1 / 最大备弹 2）逐项吻合。
--
-- 安全纪律：
--   写前逐字段校验 -> 备份原始 160 字节 -> 只写 8 字节 -> 回读验证
--   幂等；被换图冲掉自动重打；全程只碰这一条记录的 8 字节，不做任何扫描。
--   仅在确认写入被游戏接受时，才把两处模板值一起更新。

local GAME_MODULE   = 'game.dll'
local OWNER_RVA     = 0x346d540
local SLOT_OFFSET   = -13616120
local DATA_START    = 8640
local RECORD_SIZE   = 160
local TARGET_INDEX  = 235

local OFF_CAPACITY  = 136
local OFF_MAGAZINES = 140
local OFF_REFILL    = 144
local OFF_MAX       = 148

local EXPECT_CAPACITY = 1
local EXPECT_MAGAZINES = 1
local EXPECT_REFILL = 1
local EXPECT_MAX    = 2
local NEW_REFILL    = 6
local NEW_MAX       = 6

local START_FRAMES = 300
local RECHECK_EVERY = 300
local TIMEOUT_FRAMES = 7200

local key = 'DSH_P34MagWrite'
if rawget(_G, key) then return rawget(_G, key) end
local M = { version = '1.2.0', phase = 'init', status = 'starting' }
rawset(_G, key, M)

local outdir
do
    local la = os.getenv('LOCALAPPDATA')
    outdir = (type(la) == 'string' and #la > 0)
        and (la .. '\\CowboyBingus\\Helldivers2\\P34MagWrite') or 'P34MagWrite'
    os.execute('mkdir "' .. outdir .. '" 2>nul')
end
local function write_file(n, c)
    local f = io.open(outdir .. '\\' .. n, 'wb')
    if not f then return false end
    f:write(c); f:close(); return true
end

local STATUS = {}
local function status(k, v) STATUS[#STATUS + 1] = string.format('%-20s = %s', k, tostring(v)) end

local api = (function()
    local ok, r = pcall(function()
        local ffi = require('ffi')
        assert(ffi.os == 'Windows' and ffi.abi('64bit'), 'windows_x64_required')
        ffi.cdef [[
            void *GetModuleHandleA(const char *);
            void *GetCurrentProcess(void);
            int ReadProcessMemory(void *, const void *, void *, size_t, size_t *);
            uint64_t GetTickCount64(void);
            int VirtualProtect(void *, size_t, uint32_t, uint32_t *);
            int WriteProcessMemory(void *, void *, const void *, size_t, size_t *);
            uint32_t GetLastError(void);
        ]]
        local k = ffi.load('kernel32')
        local proc = k.GetCurrentProcess()
        local a = {}
        a.time = function() return tonumber(k.GetTickCount64()) / 1000 end
        a.module = function(n)
            local p = k.GetModuleHandleA(n)
            if p ~= nil then return tonumber(ffi.cast('uintptr_t', p)) end
        end
        a.pointer = function(d)
            if not d or #d < 8 then return nil end
            local p = ffi.new('uintptr_t[1]')
            ffi.copy(p, d, 8)
            if p[0] >= 65536 and p[0] < 0x800000000000 then return tonumber(p[0]) end
        end
        a.read = function(addr, size)
            if type(addr) ~= 'number' or addr < 65536 or addr + size >= 0x800000000000 then return nil end
            if size <= 0 or size > 8192 then return nil end
            local out, cnt = ffi.new('uint8_t[?]', size), ffi.new('size_t[1]')
            if k.ReadProcessMemory(proc, ffi.cast('const void *', addr), out, size, cnt) == 0
                or tonumber(cnt[0]) ~= size then return nil end
            return ffi.string(out, size)
        end
        -- 写入：只在必要时改页保护，写完立刻还原
        a.write = function(addr, bytes)
            local n = #bytes
            local buf = ffi.new('uint8_t[?]', n)
            ffi.copy(buf, bytes, n)
            local at = ffi.cast('void *', addr)
            local old = ffi.new('uint32_t[1]')
            local changed = false
            if k.VirtualProtect(at, n, 0x40, old) ~= 0 then
                changed = (tonumber(old[0]) ~= 0x40)
            else
                return false, 'virtualprotect_failed'
            end
            local written = ffi.new('size_t[1]')
            local wr_ok = k.WriteProcessMemory(proc, at, buf, n, written) ~= 0
                and tonumber(written[0]) == n
            local err = wr_ok and 0 or tonumber(k.GetLastError())
            if changed then k.VirtualProtect(at, n, tonumber(old[0]), old) end
            if not wr_ok then return false, 'write_failed err=' .. tostring(err) end
            return true, nil
        end
        return a
    end)
    if not ok then return nil, tostring(r) end
    return r
end)()

-- ⚠ 关键：**不要**用 `s:byte(i, i+1, i+2, i+3)` 这种"一次取多个字节"的写法！
-- 实机诊断证明：在游戏的 LuaJIT 里，多返回值会被截断——
--   probe:byte(137,138,139,140) 返回 "1,0,nil,nil"（只要到 2 个值）
--   而 probe:byte(137) 单独调用返回 1，完全正常。
-- 结果是 u32 拿到 nil 就返回 nil，于是 validate 全部失败、mod 静默不生效。
-- 现在改成逐个 byte() 调用，绝不用多返回值。
local function byte_at(s, i)
    if type(s) ~= 'string' or i < 1 or i > #s then return nil end
    return s:byte(i)
end

local function u32(s, o)
    local a = byte_at(s, o + 1)
    local b = byte_at(s, o + 2)
    local c = byte_at(s, o + 3)
    local d = byte_at(s, o + 4)
    if not (a and b and c and d) then return nil end
    return a + b * 256 + c * 65536 + d * 16777216
end

local function u32le(v)
    v = v % 4294967296
    return string.char(v % 256, math.floor(v / 256) % 256,
                       math.floor(v / 65536) % 256, math.floor(v / 16777216) % 256)
end

local function hex(s)
    if type(s) ~= 'string' then return '' end
    local out = {}
    for i = 1, #s do out[#out + 1] = string.format('%02x', s:byte(i)) end
    return table.concat(out)
end

local loader = rawget(_G, 'CowboyBingusModLoader')
local loader_api = type(loader) == 'table' and tonumber(loader.api) or nil
local log
if type(loader) == 'table' and type(loader.open_log) == 'function' then
    local ok, h = pcall(loader.open_log, 'P34MagWrite.log')
    if ok then log = h end
end
local last_log = nil
local function emit(m)
    if m == last_log then return end
    last_log = m
    if log then log:write(string.format('%.3f %s\n', api and api.time() or 0, m)); log:flush() end
end

local game = api and api.module(GAME_MODULE) or nil
status('revision', M.version)
status('game_module', game and string.format('0x%x', game) or 'unavailable')
status('target_index', TARGET_INDEX)
status('expect', string.format('cap=%d mags=%d refill=%d max=%d',
    EXPECT_CAPACITY, EXPECT_MAGAZINES, EXPECT_REFILL, EXPECT_MAX))
status('target', string.format('refill=%d max=%d', NEW_REFILL, NEW_MAX))

if not api or not game or not loader_api or loader_api < 1 then
    M.phase = 'gave_up'; M.status = 'precondition_failed'
    write_file('STATUS.txt', table.concat(STATUS, '\n') .. '\n')
    return M
end

local state = { frames = 0, phase = 'observing', next_check = 0,
                record = nil, patched = false, refused = 0, backed_up = false,
                last_err = nil }

local function locate_record()
    local bo = api.read(game + OWNER_RVA, 8)
    local owner = bo and api.pointer(bo) or nil
    if not owner then return nil, 'owner_pointer_null' end
    local bt = api.read(owner + SLOT_OFFSET, 8)
    local table_at = bt and api.pointer(bt) or nil
    if not table_at then return nil, 'table_pointer_null' end
    local rec = table_at + DATA_START + TARGET_INDEX * RECORD_SIZE
    local row = api.read(rec, RECORD_SIZE)
    if not row then return nil, 'record_unreadable' end
    return rec, nil, row, table_at
end

local function read_four(row)
    return {
        cap = u32(row, OFF_CAPACITY),
        mags = u32(row, OFF_MAGAZINES),
        refill = u32(row, OFF_REFILL),
        max = u32(row, OFF_MAX),
    }
end

local function apply()
    local rec, err, row, table_at = locate_record()
    if not rec then
        state.last_err = err
        return false, err
    end
    state.record = rec
    local v = read_four(row)

    -- 身份校验：容量与枪内弹匣数必须吻合
    if v.cap ~= EXPECT_CAPACITY or v.mags ~= EXPECT_MAGAZINES then
        state.refused = state.refused + 1
        state.last_err = 'identity_mismatch'
        emit(string.format('identity_mismatch cap=%s mags=%s refill=%s max=%s',
            tostring(v.cap), tostring(v.mags), tostring(v.refill), tostring(v.max)))
        return false, 'identity_mismatch'
    end
    -- 值域校验：refill/max 必须是原值或目标值
    if not ((v.refill == EXPECT_REFILL or v.refill == NEW_REFILL)
        and (v.max == EXPECT_MAX or v.max == NEW_MAX)) then
        state.refused = state.refused + 1
        state.last_err = 'value_out_of_range'
        emit(string.format('value_out_of_range refill=%s max=%s',
            tostring(v.refill), tostring(v.max)))
        return false, 'value_out_of_range'
    end

    if v.refill == NEW_REFILL and v.max == NEW_MAX then
        if not state.patched then
            state.patched = true
            emit('already_patched (idempotent)')
        end
        return true, nil
    end

    if not state.backed_up then
        write_file('original_record.hex', hex(row) .. '\n')
        write_file('original_summary.txt', string.format(
            'record=0x%x table=0x%x index=%d\ncap=%d mags=%d refill=%d max=%d\n',
            rec, table_at, TARGET_INDEX, v.cap, v.mags, v.refill, v.max))
        state.backed_up = true
        emit(string.format('backup_written record=0x%x refill=%d max=%d', rec, v.refill, v.max))
    end

    -- 防竞态：写前再读一次
    local fresh = api.read(rec + OFF_REFILL, 8)
    if not fresh then
        state.last_err = 'reread_failed'
        return false, 'reread_failed'
    end
    local fr, fm = u32(fresh, 0), u32(fresh, 4)
    if not ((fr == EXPECT_REFILL or fr == NEW_REFILL)
        and (fm == EXPECT_MAX or fm == NEW_MAX)) then
        state.last_err = 'record_changed_before_write'
        return false, 'record_changed_before_write'
    end

    local payload = u32le(NEW_REFILL) .. u32le(NEW_MAX)
    emit(string.format('write_intent record=0x%x offset=%d bytes=8 refill %d->%d max %d->%d',
        rec, OFF_REFILL, fr, NEW_REFILL, fm, NEW_MAX))
    local wok, werr = api.write(rec + OFF_REFILL, payload)
    if not wok then
        state.last_err = 'write_failed'
        emit('write_failed ' .. tostring(werr))
        return false, 'write_failed'
    end

    local back = api.read(rec + OFF_REFILL, 8)
    local br = back and u32(back, 0) or nil
    local bm = back and u32(back, 4) or nil
    if br ~= NEW_REFILL or bm ~= NEW_MAX then
        state.last_err = 'readback_mismatch'
        emit(string.format('readback_mismatch got refill=%s max=%s', tostring(br), tostring(bm)))
        return false, 'readback_mismatch'
    end

    state.patched = true
    state.last_err = nil
    emit(string.format('applied refill %d->%d max %d->%d readback_ok',
        fr, NEW_REFILL, fm, NEW_MAX))
    return true, nil
end

local function finalize()
    status('patched', tostring(state.patched))
    status('refused', state.refused)
    if state.record then status('record_addr', string.format('0x%x', state.record)) end
    if state.last_err then status('last_error', state.last_err) end
    if state.patched then
        M.phase = 'done'
        M.status = string.format('OK - P-34 refill %d->%d, max %d->%d applied',
            EXPECT_REFILL, NEW_REFILL, EXPECT_MAX, NEW_MAX)
    else
        M.phase = 'gave_up'
        M.status = 'FAILED - ' .. tostring(state.last_err or 'unknown')
    end
    status('result', M.status)
    status('artifacts', outdir)
    write_file('STATUS.txt', table.concat(STATUS, '\n') .. '\n')
    emit(M.status)
end

local previous_update = rawget(_G, 'update')
if type(previous_update) ~= 'function' then
    M.phase = 'gave_up'; M.status = 'no_update_hook'
    write_file('STATUS.txt', table.concat(STATUS, '\n') .. '\n')
    return M
end

local my_update
my_update = function(...)
    if M.retired then return previous_update(...) end
    state.frames = state.frames + 1

    if state.phase == 'observing' then
        if state.frames < START_FRAMES then return previous_update(...) end
        local ok = apply()
        if ok then
            state.phase = 'maintaining'
            state.next_check = state.frames + RECHECK_EVERY
            status('applied_at_frame', state.frames)
        end
        if not state.patched and state.frames - START_FRAMES > TIMEOUT_FRAMES then
            finalize(); state.phase = 'finished'
        end
        return previous_update(...)
    end

    if state.phase == 'maintaining' then
        if state.frames >= state.next_check then
            state.next_check = state.frames + RECHECK_EVERY
            local ok = apply()
            if not ok then
                state.patched = false
                emit('recheck_failed ' .. tostring(state.last_err) .. ' -> repatching')
                if apply() then emit('repatch_ok') end
            end
        end
        if state.frames - START_FRAMES > TIMEOUT_FRAMES then
            finalize(); state.phase = 'finished'
        end
        return previous_update(...)
    end

    return previous_update(...)
end
update = my_update
M.retire_hook = function()
    M.retired = true
    if update == my_update then update = previous_update end
end
M.state = state
return M
