-- Loader API 1 + update-chain simulation, no native memory access.
local function scenario(hash_ok)
    local now,steps,forwarded,stops=100,0,0,0
    local logs={}
    local env=setmetatable({}, {__index=_G});env._G=env
    env.SPEC={module_sha256='expected'}
    env.print=function()end
    env.CowboyBingusModLoader={api=1,version=16,open_log=function(name)
        assert(name=='SupplyFRVBolter.log')
        return {write=function(self,s)logs[#logs+1]=s;return true end,flush=function()return true end,close=function()end}
    end}
    env.update=function(...)forwarded=forwarded+1;return select('#',...),... end
    env.WindowsRead=function()return {module=function()return 0x10000000 end,
        module_hash=function()return hash_ok and 'expected' or 'wrong' end,
        time=function()return now end,read=function()return nil end} end
    env.WindowsWrite=function()return function()error('unexpected write')end end
    env.WindowsRegion=function()return function()return nil end end
    env.Coordinator={new=function()return {state='locating',step=function()steps=steps+1 end,
        stop=function()stops=stops+1 end} end}
    local f=assert(io.open('supply_frv013/source/boot.lua'));local source=f:read('*a');f:close()
    local m=assert(load(source,'@boot','t',env))()
    if hash_ok then
        assert(not m.disabled)
        assert(env.update()==0 and steps==1)
        now=now+0.02
        local n,a,b=env.update('context',nil)
        assert(n==2 and a=='context' and b==nil and steps==2 and forwarded==2)
        now=401;env.update()
        assert(m.disabled and steps==2 and stops==1)
        print('PASS API 1 startup: update without dt; varargs preserved; monotonic timeout')
    else
        assert(m.disabled and steps==0)
        assert(table.concat(logs):find('unsupported_game_dll_no_write',1,true))
        print('PASS unsupported game build: no coordinator execution')
    end
end
scenario(true);scenario(false)
