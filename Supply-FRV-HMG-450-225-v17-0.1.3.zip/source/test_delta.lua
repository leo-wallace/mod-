local old=dofile('supply_frv012/source/test_module.lua').SPEC
local new=dofile('supply_frv013/source/test_module.lua').SPEC
local function final(c)
    local s=c.original
    for _,e in ipairs(c.edits) do s=s:sub(1,e.offset)..e.replacement..s:sub(e.offset+#e.replacement+1) end
    return s
end
assert(#old.components==3 and #new.components==3)
for _,i in ipairs({1,3}) do
    assert(final(old.components[i])==final(new.components[i]),'HP/ammo changed')
end
local a,b=final(old.components[2]),final(new.components[2])
for i=1,#a do
    if a:byte(i)~=b:byte(i) then
        local offset=i-1
        assert(offset>=128 and offset<136,'unrelated turret field changed')
    end
end
assert(new.module_sha256==old.module_sha256 and new.owner_rva==old.owner_rva)
assert(new.search_begin==old.search_begin and new.search_end==old.search_end)
print('PASS delta: exact HP/magazine identity, only normal/durable damage addends differ')
