-- All three records must pass preflight before the first write.
local Coordinator={}
function Coordinator.new(api,emit,spec,game,external_loaded)
    local self={state='locating',disabled=false,cores={},status=nil}
    local health=spec.components[1]
    local search_owner,search_offset,found,seen
    local ranges,range_index,range_cursor,phase,scan_bytes,last_progress
    local seen_count,matched
    local function status(s)
        if self.status~=s then self.status=s;emit(s) end
    end
    local function pointer(at)
        local b=api.read(at,8);return b and api.pointer(b) or nil
    end
    local function owner() return pointer(game+spec.owner_rva) end
    local function map_matches(at,c)
        if not at then return false end
        if c.direct then
            for _,g in ipairs(c.guards) do
                if api.read(at+g.offset,#g.bytes)~=g.bytes then return false end
            end
            return true
        end
        local p=c.map_probe_offset
        if api.read(at+p,32)~=c.hashmap:sub(p+1,p+32) then return false end
        for i=0,#c.hashmap-1,2048 do
            local chunk=c.hashmap:sub(i+1,i+2048)
            if api.read(at+i,#chunk)~=chunk then return false end
        end
        return true
    end
    for _,c in ipairs(spec.components) do
        c.game=game;c.owner_rva=spec.owner_rva
        local m=c.original
        for _,e in ipairs(c.edits) do
            m=m:sub(1,e.offset)..e.replacement..m:sub(e.offset+#e.replacement+1)
        end
        c.modified=m
    end
    function self.stop()
        local clean=true
        for i=#self.cores,1,-1 do
            local ok,result=pcall(self.cores[i].stop)
            if not ok or not result then clean=false end
        end
        self.disabled=true
        status(clean and 'stopped_owned_changes_restored' or 'stopped_restore_incomplete_context_changed')
        return clean
    end
    local function fail(reason)
        local restored=self.stop();self.state='failed';self.disabled=true
        status(reason..' cleanup_complete='..tostring(restored))
    end
    local function allocation_ranges(o)
        if not api.region then return nil,'virtual_query_unavailable' end
        -- Seed only allocations that actually contain verified component slots.
        local seeds={}
        for i=2,3 do
            local c=spec.components[i]
            local slot=o+c.candidate_slot
            if not map_matches(pointer(slot),c) then return nil,c.label..'_anchor_not_verified' end
            local r=api.region(slot)
            if not r or not r.allocation or r.allocation<65536 then return nil,'anchor_region_unavailable' end
            seeds[r.allocation]=true
        end
        local out,total={},0
        for allocation in pairs(seeds) do
            local cursor=allocation
            for j=1,4096 do
                local r=api.region(cursor)
                if not r or r.allocation~=allocation then break end
                if r.base~=cursor or r.size<=0 then return nil,'invalid_region_layout' end
                total=total+r.size
                if total>256*1024*1024 then return nil,'allocation_scan_limit_256MiB' end
                if r.readable then out[#out+1]={first=r.base,last=r.base+r.size} end
                cursor=r.base+r.size
                if j==4096 then return nil,'allocation_region_limit' end
            end
            emit(string.format('verified_component_allocation begin=0x%x end=0x%x bytes=%d',allocation,cursor,cursor-allocation))
        end
        table.sort(out,function(a,b)return a.first<b.first end)
        return out
    end
    local function inspect_block(o,address,n)
        local block=api.read(address,n)
        scan_bytes=scan_bytes+n
        if not block then return end
        for p=0,n-8,8 do
            local at=api.pointer(block:sub(p+1,p+8))
            if at and not seen[at] then
                seen[at]=true;seen_count=seen_count+1
                if seen_count>=65536 then seen={};seen_count=0 end
                if not matched[at] and map_matches(at,health) then
                    matched[at]=true
                    found[#found+1]={slot=address+p-o,table=at}
                    emit(string.format('health_map_candidate slot_delta=%d table=0x%x',address+p-o,at))
                end
            end
        end
    end
    local function finish_health(o)
        if #found>1 then fail('ambiguous_health_tables_no_write');return false end
        if #found==1 and owner()==o then
            health.candidate_slot=found[1].slot
            status(string.format('health_table_verified slot_delta=%d record_index=%d',health.candidate_slot,health.record_index))
            return true
        end
        search_owner=nil
        status('verified_allocations_scanned_health_not_found_no_write_send_log')
        return false
    end
    local function locate_health(o)
        if search_owner~=o then
            search_owner=o;search_offset=spec.search_begin;found={};seen={}
            phase='nearby';scan_bytes=0;last_progress=0;ranges=nil;seen_count=0;matched={}
            emit(string.format('health_scan_started owner=0x%x',o))
        end
        if phase=='nearby' then
            local n=math.min(4096,spec.search_end-search_offset)
            inspect_block(o,o+search_offset,n)
            search_offset=search_offset+n
            if search_offset<spec.search_end then return false end
            if #found>0 then return finish_health(o) end
            local why
            ranges,why=allocation_ranges(o)
            if not ranges then
                status('health_scan_blocked_no_write '..tostring(why));return false
            end
            phase='allocation';range_index=1;range_cursor=ranges[1] and ranges[1].first
            status('nearby_miss_scanning_verified_component_allocations_no_write')
        end
        local begin=api.time and api.time() or 0
        -- At most 64 KiB of pointer slots per callback, yielding after a page
        -- once the four-millisecond scheduling budget has been reached.
        for j=1,16 do
            local r=ranges[range_index]
            if not r then return finish_health(o) end
            local n=math.min(4096,r.last-range_cursor)
            inspect_block(o,range_cursor,n)
            range_cursor=range_cursor+n
            if range_cursor>=r.last then
                range_index=range_index+1
                range_cursor=ranges[range_index] and ranges[range_index].first
            end
            if api.time and api.time()-begin>=0.004 then break end
        end
        local now=api.time and api.time() or 0
        if now-last_progress>=5 then
            last_progress=now
            emit(string.format('health_scan_progress bytes=%d region=%d/%d matches=%d',scan_bytes,range_index,#ranges,#found))
        end
        return false
    end
    function self.step()
        if self.disabled then return end
        if self.state=='applied' then
            for _,core in ipairs(self.cores) do
                core.step()
                if core.disabled then fail('applied_context_changed_restart_required');return end
            end
            return
        end
        local o=owner()
        if not o then status('waiting_for_entity_manager_no_write');return end
        if not health.candidate_slot then
            if not locate_health(o) then return end
        end
        for _,c in ipairs(spec.components) do
            local base=c.direct and game or o
            local tab=pointer(base+c.candidate_slot)
            if not map_matches(tab,c) then
                if c==health then health.candidate_slot=nil;search_owner=nil end
                status(c.label..' waiting_for_exact_table_no_write');return
            end
            local at=c.direct and tab or tab+#c.hashmap+c.record_index*c.record_size
            local row=api.read(at,c.record_size)
            if row~=c.original and not (c.accept_preexisting and row==c.modified) then
                emit(c.label..' observed_prefix='..((row or ''):sub(1,160):gsub('.',function(ch)return string.format('%02x',ch:byte())end)))
                fail(c.label..' record_mismatch_no_write');return
            end

        end
        status('all_three_records_verified_applying')
        for _,c in ipairs(spec.components) do
            local label=c.label
            local core=Core.new(api,function(s)emit(label..' '..s)end,c)
            self.cores[#self.cores+1]=core
            core.step()
            if core.disabled or not (core.lease or core.borrowed) then
                fail(label..' apply_failed');return
            end
        end
        self.state='applied'
        status('APPLIED_READBACK_OK hull=12000 each_wheel=12000 other_parts_x5 magazine=600 hmg_projectile=275 ammo_reference=Halo_M6C direct_damage=450/225 gameplay=UNVERIFIED')
    end
    return self
end
