local key='SupplyFRVBolterEnhanced'
if rawget(_G,key) then return rawget(_G,key) end
local M={version='0.1.3-hmg-450-225',status='starting',disabled=false}
rawset(_G,key,M)
local loader=rawget(_G,'CowboyBingusModLoader')
local previous_update=rawget(_G,'update')
if type(loader)~='table' or loader.api~=1 or type(loader.open_log)~='function' or type(previous_update)~='function' then
    M.disabled=true;M.status='unsupported_loader_or_update';print('[SupplyFRVBolter] '..M.status);return M
end
local log,coordinator,api,started
local function emit(s)
    M.status=s
    if log then assert(log:write(os.date('!%Y-%m-%dT%H:%M:%SZ')..' '..s..'\n'));assert(log:flush()) end
    print('[SupplyFRVBolter] '..s)
end
local ok,why=pcall(function()
    log=assert(loader.open_log('SupplyFRVBolter.log'))
    api=WindowsRead()
    local game=assert(api.module('game.dll'),'game_dll_missing')
    assert(api.module_hash(game)==SPEC.module_sha256,'unsupported_game_dll_no_write')
    emit('loader_api='..tostring(loader.api)..' marker='..tostring(loader.version))
    emit('hash_verified build=25480438 version='..M.version..' gameplay=UNVERIFIED')
    local raw_read=api.read
    api.read=function(at,n)
        if type(at)~='number' or at<65536 or at+n>=0x800000000000 or n<=0 or n>65536 then return nil end
        local parts={}
        for i=0,n-1,2048 do
            local b=raw_read(at+i,math.min(2048,n-i));if not b then return nil end
            parts[#parts+1]=b
        end
        return table.concat(parts)
    end
    api.write=WindowsWrite(api,emit)
    api.region=WindowsRegion()
    coordinator=Coordinator.new(api,emit,SPEC,game,function()return rawget(_G,'StarmDominatorEnhanced')~=nil end)
    started=api.time()
end)
if not ok then
    M.disabled=true;pcall(emit,'startup_failed_no_write '..tostring(why))
    if log then pcall(function()log:close()end) end
    return M
end
local next_tick=0
local first_update=true
update=function(...)
    if not M.disabled then
        local success,err=pcall(function()
            if first_update then first_update=false;emit('first_update_received') end
            local now=api.time()
            if now<next_tick then return end
            next_tick=now+(coordinator.state=='applied' and 2 or 0.01)
            if coordinator.state~='applied' and now-started>300 then
                coordinator.stop();M.disabled=true;emit('preflight_timeout_no_write_send_this_log');return
            end
            coordinator.step()
            if coordinator.disabled then M.disabled=true end
        end)
        if not success then
            M.disabled=true;pcall(coordinator.stop);pcall(emit,'runtime_error '..tostring(err))
        end
    end
    return previous_update(...)
end
local previous_shutdown=rawget(_G,'shutdown')
shutdown=function(...)
    pcall(coordinator.stop);M.disabled=true
    if log then pcall(function()log:close()end) end
    if type(previous_shutdown)=='function' then return previous_shutdown(...) end
end
return M
