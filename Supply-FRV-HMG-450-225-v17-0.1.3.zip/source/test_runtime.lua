-- Uses exact extracted component maps and rows. No native APIs or game process.
local function modified(c)
    local b=c.original
    for _,e in ipairs(c.edits) do b=b:sub(1,e.offset)..e.replacement..b:sub(e.offset+#e.replacement+1) end
    return b
end
local function fixture(far_health,unreadable_gap)
    local lib=dofile('supply_frv013/source/test_module.lua')
    local spec=lib.SPEC
    local game,owner=0x10000000,0x20000000
    local regions,rows,tables,writes,logs={},{},{},{},{}
    local fail_address,external,partial=false,false,false
    local function region(at,n)
        for _,s in ipairs(regions) do if at>=s.at and at+n<=s.at+#s.b then return s end end
    end
    local function put(at,b)
        local s=region(at,#b)
        if s then local p=at-s.at;s.b=s.b:sub(1,p)..b..s.b:sub(p+#b+1)
        else regions[#regions+1]={at=at,b=b} end
    end
    put(game+spec.owner_rva,string.pack('<I8',owner))
    put(owner+spec.search_begin,string.rep('\0',spec.search_end-spec.search_begin))
    local far=owner+spec.search_begin-8192
    if far_health then put(far,string.rep('\0',4096)) end
    local api={}
    if far_health then
        function api.region(at)
            local allocation=far
            if at==far then return {base=far,size=4096,allocation=allocation,readable=true} end
            if at==far+4096 then return {base=at,size=4096,allocation=allocation,readable=false} end
            if at>=owner+spec.search_begin and at<owner+spec.search_end then
                return {base=owner+spec.search_begin,size=spec.search_end-spec.search_begin,allocation=allocation,readable=true}
            end
        end
    end
    function api.read(at,n)
        local s=region(at,n);if s then return s.b:sub(at-s.at+1,at-s.at+n) end
    end
    function api.pointer(b)
        if not b or #b<8 then return nil end
        local p=string.unpack('<I8',b)
        if p>=65536 and p<0x800000000000 then return p end
    end
    function api.write(at,b)
        writes[#writes+1]={at=at,b=b}
        if fail_address==at then
            fail_address=false
            if partial then put(at,b:sub(1,2)) end
            return false
        end
        put(at,b);return true
    end
    for i,c in ipairs(spec.components) do
        local tab=0x30000000+i*0x2000000
        tables[i]=tab
        local slot=c.candidate_slot or (far_health and far-owner or -13615000)
        put((c.direct and game or owner)+slot,string.pack('<I8',tab))
        if c.direct then
            for _,g in ipairs(c.guards) do put(tab+g.offset,g.bytes) end
            rows[i]=tab
        else
            put(tab,c.hashmap)
            rows[i]=tab+#c.hashmap+c.record_index*c.record_size
        end
        put(rows[i],c.original)
    end
    local co=lib.Coordinator.new(api,function(s)logs[#logs+1]=s end,spec,game,function()return external end)
    local function run(n) for _=1,n or 40 do co.step() end end
    return {spec=spec,game=game,owner=owner,api=api,put=put,rows=rows,tables=tables,writes=writes,logs=logs,co=co,run=run,
        set_external=function(x)external=x end,
        fail=function(at,p)fail_address=at;partial=p end}
end
local function pristine(f)
    for i,c in ipairs(f.spec.components) do assert(f.api.read(f.rows[i],c.record_size)==c.original,'not restored '..c.label) end
end
do
    local f=fixture();f.run()
    assert(f.co.state=='applied' and not f.co.disabled)
    local expected_writes=0
    for i,c in ipairs(f.spec.components) do
        assert(f.api.read(f.rows[i],c.record_size)==modified(c))
        for _,e in ipairs(c.edits) do
            expected_writes=expected_writes+1
            local w=f.writes[expected_writes]
            assert(w.at==f.rows[i]+e.offset and w.b==e.replacement,'unexpected write range')
        end
    end
    assert(#f.writes==39 and #f.writes==expected_writes)
    local function n(at) return string.unpack('<I4',f.api.read(at,4)) end
    assert(n(f.rows[1])==12000)
    for i=0,3 do assert(n(f.rows[1]+520+i*552+232)==12000) end
    assert(n(f.rows[2])==275 and n(f.rows[3]+136)==600)
    assert(string.unpack('<f',f.api.read(f.rows[2]+8,4))==640,'original sentry cadence changed')
    assert(#f.spec.components==3,'unexpected shared ammo writes')
    assert(string.unpack('<f',f.api.read(f.rows[2]+124,4))==1)
    assert(string.unpack('<f',f.api.read(f.rows[2]+128,4))==300)
    assert(string.unpack('<f',f.api.read(f.rows[2]+132,4))==190)
    assert(150+string.unpack('<f',f.api.read(f.rows[2]+128,4))==450)
    assert(35+string.unpack('<f',f.api.read(f.rows[2]+132,4))==225)
    assert(f.api.read(f.rows[2]+136,8)==string.rep('\0',8),'AP modifiers changed')
    f.run(3);assert(#f.writes==39,'duplicate write')
    assert(f.co.stop());pristine(f)
    print('PASS standalone: 39 exact writes, all HP/ammo/projectile targets, original cadence, idempotence, restore')
end
do
    local f=fixture();f.set_external(true);f.run()
    assert(f.co.state=='applied' and #f.writes==39,'unrelated Dominator mod blocked HMG')
    assert(#f.spec.components==3)
    assert(f.co.stop());pristine(f)
    print('PASS HMG independence: no Dominator shared rows or ownership dependency')
end
do
    local f=fixture();f.put(f.rows[3]+136,string.pack('<I4',121));f.run()
    assert(f.co.disabled and #f.writes==0)
    print('PASS changed target: entire group refuses all writes')
end
do
    local f=fixture();f.put(f.tables[1]+f.spec.components[1].map_probe_offset,'\255');f.run()
    assert(#f.writes==0 and f.co.state~='applied')
    print('PASS wrong health map: no speculative writes')
end
do
    local f=fixture();local second=0x50000000
    f.put(second,f.spec.components[1].hashmap)
    f.put(f.owner-13614992,string.pack('<I8',second));f.run()
    assert(f.co.disabled and #f.writes==0)
    print('PASS ambiguous health tables: no writes')
end
do
    local f=fixture();f.fail(f.rows[3]+136,true);f.run()
    assert(f.co.disabled);pristine(f)
    print('PASS partial native write failure: owned group restored')
end
do
    local f=fixture();f.run();local writes=#f.writes
    f.put(f.owner-13615000,string.pack('<I8',0x60000000));f.run(1)
    assert(f.co.disabled)
    for i=writes+1,#f.writes do assert(f.writes[i].at<f.rows[1] or f.writes[i].at>=f.rows[1]+22096,'wrote stale health record') end
    print('PASS pointer relocation: stale health allocation not written')
end
do
    local f=fixture(true);f.run(40)
    assert(f.co.state=='applied' and #f.writes==39,'failed extended allocation discovery')
    assert(f.spec.components[1].candidate_slot<f.spec.search_begin)
    assert(f.co.stop());pristine(f)
    print('PASS regression: health pointer beyond old window; unreadable gap skipped; 39 exact writes and restore')
end
print('All offline checks passed. Live gameplay remains unverified.')
