-- Read-only virtual-memory metadata; never changes permissions or bytes.
local function WindowsRegion()
    local ffi=require('ffi')
    local k=ffi.load('kernel32')
    local query=ffi.cast('size_t (*)(const void *,void *,size_t)',k.VirtualQuery)
    return function(address)
        local m=ffi.new('STARM_FOUR_MEMORY_BASIC_INFORMATION[1]')
        if tonumber(query(ffi.cast('const void *',address),m,48))~=48 then return nil end
        local protection=tonumber(m[0].Protect)
        return {base=tonumber(ffi.cast('uintptr_t',m[0].BaseAddress)),
            allocation=tonumber(ffi.cast('uintptr_t',m[0].AllocationBase)),
            size=tonumber(m[0].RegionSize),
            readable=m[0].State==0x1000 and
                (protection==2 or protection==4 or protection==8 or protection==32 or protection==64 or protection==128)}
    end
end
