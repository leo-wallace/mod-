# Supply FRV HMG 450/225 — 0.1.3 / Bingus Shared Loader v17

Changes only turret direct-damage addends relative to 0.1.2: +300 normal and +190 durable. Projectile 275 references damage 205 with base 150/35, giving nominal 450/225 before gameplay hit/distance calculations. No shared ammo/damage-table edits, no added explosion, no Halo M6C buff.

Unchanged: hull and each wheel 12000 HP; other active zones x5; magazine 600; cadence 640 RPM; projectile, speed, AP and locator.

Replace the previous Supply FRV mod, retain v17, Purge/Deploy, fully restart and spawn a new vehicle. Same GUID, module ID and SupplyFRVBolter.log. Syntax, existing offline regressions and exact record delta passed; live gameplay remains unverified. See README.zh-CN.md and source/AMMO_EVIDENCE.json.
