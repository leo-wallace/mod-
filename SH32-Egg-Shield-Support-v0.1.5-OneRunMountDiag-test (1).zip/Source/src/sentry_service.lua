-- SH-32 optional sentry servicing. Isolated from tested vehicle/mounted-weapon paths.
-- Magazine public +0x50/index*12+4 and private firing +0x48/index*16
-- are verified in Sentry Field Service 1.0.2-beta.2 (game build 25480438).
-- Exact native firing-gate signatures are mandatory; refuse to write on updates.
return function(N,W,log,C)
    local sr = {}
    local ffi = require('ffi')
    sr.catalog = {
        ['37cde43876ba26bb'] = 'Machine Gun Sentry',
        ['ef85d6cf58e31d70'] = 'Gatling Sentry',
        ['54d86057f5dacfb9'] = 'Autocannon Sentry',
        ['37079568dc86e9c6'] = 'Rocket Sentry',
        ['820cc3bafe962858'] = 'Flame Sentry',
        ['51a0812e3bce2d74'] = 'Mortar Sentry',
        ['b2053a1838092f8b'] = 'EMS Mortar Sentry',
        ['299c0d3dfd2f0994'] = 'Gas Mortar Sentry',
        ['56070f36cfffa8a8'] = 'Laser Sentry',
        ['74599e56f72f9d7e'] = 'Tesla Tower',
    }
    sr.unlimited = { ['56070f36cfffa8a8'] = true, ['74599e56f72f9d7e'] = true }
    local u32, i32, ptr = N.u32, N.i32, N.ptr
    local state = {}
    local gate, gate_checked_base, gate_checked_ready, gate_reason = false, nil, nil, nil
    local signatures = {
        {0x744D6C, '488b4d38488bdf48c1e30448035d48'},
        {0x744DAD, '833b000f9fc0'},
        {0x76E33B, '488d0452488d0c8500000000498b42504489740104'},
    }
    local function signature_bytes(hex)
        return (hex:gsub('%x%x', function(pair) return string.char(tonumber(pair, 16)) end))
    end
    for _,s in ipairs(signatures) do s[3] = signature_bytes(s[2]) end
    local function check_gate()
        if N.base == gate_checked_base and gate_checked_ready == N.weapon_ready then return gate end
        gate_checked_base, gate_checked_ready, gate, gate_reason = N.base, N.weapon_ready, false, nil
        if not (N.weapon_ready and N.win and N.win.read and N.base) then
            gate_reason = 'weapon module not verified'; return false
        end
        for _,s in ipairs(signatures) do
            local b = N.win.read(N.base + s[1], #s[3])
            if b ~= s[3] then
                gate_reason = string.format('native firing opcode mismatch at +0x%x', s[1]); return false
            end
        end
        gate = true
        log('sentry: native firing gate verified, magazine dual-counter service enabled')
        return true
    end
    local function template(g, net, offset, buckets, stride, d)
        local key = d.resource
        local reg = ptr(g:watch(net + offset, 8), 0)
        if reg == 0 then error('sentry template registry unavailable', 0) end
        local start = N.mod64hex(key, buckets)
        for probe = 0, buckets - 1 do
            local row = g:watch(reg + ((start + probe) % buckets) * 16, 16)
            local k = N.hex64(row, 0)
            if k == '0000000000000000' then break end
            if k == key then
                local idx = u32(row, 8)
                if idx >= buckets or u32(row, 12) ~= 0 then error('invalid sentry template index', 0) end
                return reg + buckets * 16 + idx * stride
            end
        end
        error('sentry resource template not found', 0)
    end
    local function capacity(g, manager, net, d)
        local cfg_idx = g:lookup(g:table(manager + 0x60), d.entity)
        local address
        if cfg_idx ~= nil then
            local p = ptr(g:watch(manager + 0xA0, 8), 0)
            if p == 0 or cfg_idx >= 16384 then error('invalid sentry magazine config array', 0) end
            address = p + cfg_idx * 160
        else address = template(g, net, 0xF124A0, 540, 160, d) end
        local b = g:watch(address + 0x88, 8)
        local magazine, spares = u32(b, 0), u32(b, 4)
        if magazine == 0 or magazine >= 1000000 or spares > 64
            or magazine * (1 + spares) >= 1000000 then error('invalid sentry capacity', 0) end
        return magazine * (1 + spares)
    end
    local function max_health(g, manager, idx, net, d)
        local s = ptr(g:watch(manager + 0x1060, 8), 0)
        local h
        if s ~= 0 then
            h = u32(g:watch(s + idx * 28 + 20, 4), 0)
            if h > 0 and h < 10000000 then return h end
        end
        h = u32(g:watch(template(g, net, 0xF12B78, 1002, 0x5650, d), 4), 0)
        if h == 0 or h >= 10000000 then error('invalid sentry max HP', 0) end
        return h
    end
    local function credit(rec, name, max, rate, dt, deficit)
        if deficit <= 0 then rec[name] = 0; return 0, 0 end
        local n = (rec[name] or 0) + max * rate * dt
        return math.min(deficit, math.floor(n)), n % 1
    end
    local function component(g, rva, d, to, dp, optional)
        local p = ptr(g:watch(N.base + rva, 8), 0)
        if p == 0 then
            if optional then return nil end
            error('sentry manager missing',0)
        end
        local i, owner = g:component(p, d.entity, to, dp)
        if i == nil then
            if optional then return nil end
            error('sentry component missing',0)
        end
        if not N.same(owner, d) then error('sentry component owner changed', 0) end
        if C.authority_only and owner.flags % 2 ~= 1 then return nil end
        return p, i
    end
    local function two_writes(at1, old1, at2, old2, new_value)
        if not W.writable(at1) or not W.writable(at2) then return false, 'counter not writable' end
        if not W.i32(at1, old1, new_value) then return false, 'first counter changed' end
        if W.i32(at2, old2, new_value) then return true end
        -- A failure must not leave the mod's first write unpaired.
        -- Do not revert somebody else's intervening update; quarantine on failure.
        if not W.i32(at1, new_value, old1) then
            return false, 'rollback FAILED; entity quarantined'
        end
        return false, 'second counter changed; rolled back'
    end
    function sr.reset()
        state = {}
        gate_checked_base, gate_checked_ready, gate, gate_reason = nil, nil, false, nil
    end
    function sr.prune(list)
        local live = {}
        for _,d in ipairs(list) do live[d.entity .. ':' .. d.goid .. ':' .. d.resource] = true end
        for k in pairs(state) do if not live[k] then state[k] = nil end end
    end
    function sr.ready()
        return check_gate(), gate_reason
    end
    function sr.step(d, dt)
        if not sr.catalog[d.resource] then return 'unknown_sentry' end
        if C.authority_only and d.flags % 2 ~= 1 then return 'not_authoritative' end
        if not C.sentry_ammo and not C.sentry_repair then return 'disabled' end
        -- The source release was tied to an exact native firing layout. Apply
        -- the same safety gate to both ammo and health writes for all sentries.
        if not check_gate() then return 'sentry_layout_not_verified: ' .. tostring(gate_reason) end
        local key = d.entity .. ':' .. d.goid .. ':' .. d.resource
        local rec = state[key] or { name = sr.catalog[d.resource] }
        state[key] = rec
        if rec.quarantined then return 'quarantined_after_rollback_failure' end
        local g = N.sample_graph()
        local net = g:root('network')
        g:roundtrip(net, d)
        local health, hi = component(g, N.roots.health, d, 0x1030, 0x1048)
        if not health then return 'no_health_authority' end
        local row = ptr(g:watch(health + 0x1058, 8), 0) + hi * 0x1B8
        local hp_at = row + 0x14
        local hp = i32(g:watch(hp_at, 4), 0)
        local dying = u32(g:watch(row + 0x19C, 4), 0)
        if hp <= 0 or dying >= 2 then return 'sentry_destroyed' end
        -- Do not revive retracting/expired sentries by refilling counters.
        local pm, pi = component(g, 0x3326560, d, 0x28, 0x40)
        if not pm then return 'payload_authority' end
        local count = u32(g:watch(pm + 0x14, 4), 0)
        if count > 16384 or pi >= count then return 'payload_index_invalid' end
        local retract = g:watch(ptr(g:watch(pm + 0x48, 8), 0) + pi * 4, 4)
        local rb = ffi.new('float[1]')
        ffi.copy(rb, retract, 4)
        if rb[0] ~= -1 then return 'sentry_retracting' end
        local life_at = ptr(g:watch(pm + 0x50, 8), 0) + pi * 8 + 4
        local life = g:watch(life_at, 4)
        ffi.copy(rb, life, 4)
        if rb[0] <= 0 or rb[0] >= 3.4e38 then return 'sentry_expired' end
        local cap, ammo, priv, pa, fa, ammo_new, ammo_rem
        local ammo_error=nil
        if C.sentry_ammo and C.ammo and not sr.unlimited[d.resource] then
            local mm, mi = component(g, 0x3326648, d, 0x20, 0x38)
            if not mm then ammo_error='magazine_authority'
            else
                pa = ptr(g:watch(mm + 0x50, 8), 0) + mi * 12 + 4
                fa = ptr(g:watch(mm + 0x48, 8), 0) + mi * 16
                ammo, priv = i32(g:watch(pa, 4), 0), i32(g:watch(fa, 4), 0)
                g:watch(fa + 4, 12)
                cap = capacity(g, mm, net, d)
                if rec.cap and rec.cap ~= cap then ammo_error='sentry_capacity_changed'
                elseif ammo < 0 or ammo > cap or priv ~= ammo then
                    ammo_error='ammo_counters_not_synchronized'
                    if not rec.reported_mismatch then
                        log('sentry ammo mismatch %s ent=%d public=%d firing=%d cap=%d (HEAL STILL ALLOWED)',
                            rec.name,d.entity,ammo,priv,cap)
                        rec.reported_mismatch=true
                    end
                else
                    rec.cap = cap
                    ammo_new, ammo_rem = credit(rec, 'ammo_credit', cap, C.ammo_rate, dt, cap-ammo)
                end
            end
        end
        local hmax, synced_at, sh, heal_n, heal_rem
        if C.sentry_repair then
            -- Optional synced-health table; never fabricate a missing row.
            local maxok, mx = pcall(max_health, g, health, hi, net, d)
            if maxok and mx >= hp then
                hmax = mx
                local sm, si = component(g, 0x3326C98, d, 0x20, 0x38, true)
                if sm then
                    synced_at = ptr(g:watch(sm + 0x50, 8), 0) + si * 16
                    sh = i32(g:watch(synced_at, 4), 0)
                    if sh <= 0 or sh > hmax or sh ~= hp then hmax = nil end
                end
                if hmax then heal_n, heal_rem = credit(rec, 'heal_credit', hmax, C.sentry_heal_rate, dt, hmax-hp) end
            end
        end
        g:validate()  -- identity, reload state, capacity and ammo counters rechecked
        local ammo_done, heal_done = false, false
        if ammo_new and ammo_new > 0 then
            local ok, reason = two_writes(fa, priv, pa, ammo, ammo + ammo_new)
            if ok then rec.ammo_credit = ammo_rem; ammo_done = true
            elseif reason:find('rollback FAILED',1,true) then rec.quarantined = true end
            if not ok then return reason end
        end
        if heal_n and heal_n > 0 then
            local ok, reason
            if synced_at then ok, reason = two_writes(hp_at, hp, synced_at, sh, hp + heal_n)
            else ok = W.i32(hp_at, hp, hp + heal_n) end
            if ok then rec.heal_credit = heal_rem; heal_done = true
            elseif reason and reason:find('rollback FAILED',1,true) then rec.quarantined = true end
            if not ok then return reason or 'health write refused' end
        end
        if (ammo_done or heal_done) and not rec.reported then
            log('sentry first service: %s ent=%d ammo=%s/%s hp=%d/%s', rec.name, d.entity,
                ammo and tostring(ammo + (ammo_done and ammo_new or 0)) or 'unlimited',
                cap and tostring(cap) or '-', hp + (heal_done and heal_n or 0), tostring(hmax or '?'))
            rec.reported = true
        end
        return ammo_done and 'ammo_replenished' or (heal_done and 'health_restored' or (ammo_error or 'no_change'))
    end
    return sr
end
