-- SH-32 experimental seated-emplacement resupply.
-- References: Reticle Ammo HUD 1.1.10 (read-only selector / magazine / rounds layout),
-- Sentry Field Service (transactional public/private magazine updates).
-- This is independently written code, not a pasted module from either reference.
-- Safety: first learn an instance only through the living SH-32 wearer's seat selector.
-- No guess-based global scan of every player's weapons and no static stat edits.
return function(N,W,log,C)
    local M={learned={}, reported={}}
    local ptr,u32,i32=N.ptr,N.u32,N.i32
    local INVALID=4294967295
    local SEL_ROOT=0x3326420
    local INV_ROOT=0x3326738
    local MAG_ROOT=0x3326648
    local ROUNDS_ROOT=0x3326CF0
    local known_elsewhere={
        ['085c1edb038ec24e']=true, ['444880f62ca7eae8']=true,
        ['d336ba1cad16769f']=true, ['8365609b35ef6672']=true,
        ['e5f64dcc3bfe9dd1']=true, ['ff9878576a4c543b']=true,
        ['08f6089289c83d22']=true, ['824b7e0c4c879eb5']=true,
        ['0736bee2d6328726']=true, ['17c5d12d8d5dee2c']=true,
        ['df51fe8d62f294be']=true,
        ['1fa1f596769225c2']=true, ['439f9e65c18567da']=true,
        ['d58ae6a04edb10de']=true, ['8aff7f0793a5bced']=true,
    }
    local function id(d) return d.entity..':'..d.goid..':'..d.resource end
    local function once(k,fmt,...)
        if M.reported[k] then return end
        M.reported[k]=true
        log(fmt,...)
    end
    function M.reset() M.learned={};M.reported={} end
    local function manager(g,rva)
        local v=ptr(g:watch(N.base+rva,8),0)
        if v==0 then return nil end
        return v
    end
    local function comp(g,p,d,to,dp,diagnostic)
        if not p then return nil end
        local j,owner=g:component(p,d.entity,to,dp)
        if j==nil or not N.same(owner,d) then return nil end
        if C.authority_only and owner.flags % 2 ~= 1 and not diagnostic then return nil end
        return j
    end
    -- Seated avatar: selector's chosen entity is distinct from all ordinary inventory slots.
    -- Learning requires a living SH-32 wearer provided by EggSupport.step, not an equipped stratagem.
    function M.observe(wearer)
        if not N.weapon_ready then return nil,'weapon_layout_not_verified' end
        local g=N.sample_graph()
        local net=g:root('network')
        g:roundtrip(net,wearer)
        local inv=manager(g,INV_ROOT)
        local ij=comp(g,inv,wearer,0x28,0x40)
        if not ij then return nil,'no_wearer_inventory' end
        local inv_state=g:watch(ptr(g:watch(inv+0x50,8),0)+ij*0x30,0x20)
        local selector=manager(g,SEL_ROOT)
        local sj=comp(g,selector,wearer,0x30,0x48)
        if not sj then return nil,'no_weapon_selector' end
        local selected=u32(g:watch(ptr(g:watch(selector+0x60,8),0)+sj*0x1D0,4),0)
        if selected==0 or selected==INVALID or selected==wearer.entity then
            once('selector-empty:'..wearer.entity,
                'mount SELECTOR wearer=%d selected=%d (no mount selected yet)',wearer.entity,selected)
            return nil,'no_seated_weapon'
        end
        for off=0,24,4 do
            if u32(inv_state,off)==selected then
                once('selector-hand:'..wearer.entity..':'..selected,
                    'mount SELECTOR wearer=%d selected=%d in_inventory=true (not a seat weapon)',wearer.entity,selected)
                return nil,'inventory_weapon_not_a_mount'
            end
        end
        local d=g:net(net,selected,true)
        if not d then
            once('selector-nonet:'..wearer.entity..':'..selected,
                'mount CANDIDATE wearer=%d selected=%d absent_from_network',wearer.entity,selected)
            return nil,'selected_entity_not_in_network'
        end
        once('candidate:'..id(d),
            'mount CANDIDATE selected=%d res=%s goid=%d unit=%d flags=%d wearer=%d',
            d.entity,d.resource,d.goid,d.unit,d.flags,wearer.entity)
        if known_elsewhere[d.resource] then return nil,'known_vehicle_weapon' end
        g:roundtrip(net,d)
        local mm=manager(g,MAG_ROOT)
        local rm=manager(g,ROUNDS_ROOT)
        local mi=comp(g,mm,d,0x20,0x38,true)
        local ri=comp(g,rm,d,0x28,0x40,true)
        if mi==nil and ri==nil then
            once('candidate-noammo:'..id(d),
                'mount CANDIDATE no supported ammo component for ent=%d res=%s (authority_or_layout_may_block)',
                d.entity,d.resource)
            return nil,'selected_has_no_supported_ammo'
        end
        -- Recorded static ID belongs only to the instance seen in the wearer's seat.
        -- Class name is a diagnostic hint until the resource hash is verified in-game.
        g:validate()
        local key=id(d)
        -- Native Seater collection is a verified avatar -> seat association.
        -- The linked descriptor may be a proxy rather than the turret hull;
        -- never claim proximity alone proves the actual parent identity.
        local relation,relation_error
        do
            local ok, value=pcall(function()
                local sg=N.sample_graph()
                return sg:relation(wearer.goid)
            end)
            if ok then relation=value else relation_error=tostring(value) end
        end
        if not M.learned[key] then
            M.learned[key]={d=d, path=mi and 'magazine' or 'rounds',
                first_entity=d.entity, seat=wearer.entity, ammo_credit=0, log_at=0}
            log('mount DISCOVER selected=%d resource=%s goid=%d unit=%d path=%s wearer=%d; E/MG-101 or E/AT-12 candidate (identity unconfirmed)',
                d.entity,d.resource,d.goid,d.unit,M.learned[key].path,wearer.entity)
        end
        local rec=M.learned[key]
        if relation and relation.status=='VEHICLE' and relation.vehicle then
            rec.seat_collection=relation.vehicle
            once('seat:'..key, 'mount SEAT weapon=%d collection_ent=%d collection_res=%s goid=%d unit=%d role=%s (native Seater link)',
                d.entity,relation.vehicle.entity,relation.vehicle.resource,
                relation.vehicle.goid,relation.vehicle.unit,tostring(relation.role))
        else
            once('seat-unavailable:'..key,
                'mount SEAT weapon=%d status=%s error=%s (seat collection not resolved)',d.entity,
                tostring(relation and relation.status or 'ERROR'),tostring(relation_error or '-'))
        end
        return rec
    end
    -- Read-only, bounded neighborhood evidence. Adjacency is NOT parenthood.
    function M.neighbors(r)
        local out={}
        local g=N.sample_graph()
        local net=g:root('network')
        for delta=-8,8 do
            if delta~=0 then
                local number=r.d.entity+delta
                if number>0 and number<4294967295 then
                    local ok,d=pcall(function() return g:net(net,number,true) end)
                    if ok and d then out[#out+1]={d=d,delta=delta} end
                end
            end
        end
        return out
    end
    function M.entries()
        local out={}
        for _,r in pairs(M.learned) do out[#out+1]=r end
        return out
    end
    function M.prune(allowed)
        for k in pairs(M.learned) do if not allowed[k] then M.learned[k]=nil end end
    end
    local function write_both(at1,v1,at2,v2,n)
        if not W.writable(at1) or not W.writable(at2) then return false,'not_writable' end
        if not W.i32(at1,v1,v1+n) then return false,'private_write_failed' end
        if W.i32(at2,v2,v2+n) then return true end
        if not W.i32(at1,v1+n,v1) then return false,'rollback_failed' end
        return false,'public_write_failed_rolled_back'
    end
    local function static_config(g,net,d,slot,count,stride)
        -- Same hash registry shape used by Sentry Field Service; no global stat edits.
        local reg=ptr(g:watch(net+slot,8),0)
        if reg==0 then return nil end
        local first=N.mod64hex(d.resource,count)
        for probe=0,count-1 do
            local pair=g:watch(reg+((first+probe)%count)*16,16)
            local key=N.hex64(pair,0)
            if key=='0000000000000000' then return nil end
            if key==d.resource then
                local idx=u32(pair,8)
                if idx>=count or u32(pair,12)~=0 then return nil end
                return reg+count*16+idx*stride
            end
        end
        return nil
    end
    local function config_address(g,mm,d,net,map_off,array_off,slot,count,stride)
        local index=g:lookup(g:table(mm+map_off),d.entity)
        if index~=nil then
            if index>=16384 then return nil end
            local p=ptr(g:watch(mm+array_off,8),0)
            return p~=0 and (p+index*stride) or nil
        end
        return static_config(g,net,d,slot,count,stride)
    end
    local function classify(cap)
        if cap>=180 and cap<=1000 then return 'E/MG-101-like (VERIFY)' end
        if cap>=8 and cap<=100 then return 'E/AT-12-like (VERIFY)' end
        return 'unknown_seat_weapon'
    end
    function M.step(r,dt,t)
        if not C.ammo or not (C.mount_ammo~=false) then return 'disabled' end
        if not N.weapon_ready then return 'weapon_layout_not_verified' end
        local authoritative=not C.authority_only or r.d.flags%2==1
        if not t or not t.allowed then return 'not_in_wearer_radius' end
        if r.quarantined then return 'quarantined_after_rollback_failure' end
        local d=r.d
        local g=N.sample_graph()
        local net=g:root('network')
        g:roundtrip(net,d)
        local n,maximum,cur,priv,pa,fa,spare,sa
        if r.path=='magazine' then
            local mm=manager(g,MAG_ROOT)
            local mi=comp(g,mm,d,0x20,0x38,true)
            if mi==nil then return 'magazine_missing_or_remote' end
            pa=ptr(g:watch(mm+0x50,8),0)+mi*12+4
            fa=ptr(g:watch(mm+0x48,8),0)+mi*16
            cur=i32(g:watch(pa,4),0)
            priv=i32(g:watch(fa,4),0)
            once('raw-mag:'..id(d),
                'mount RAW entity=%d res=%s path=magazine public=%d private=%d index=%d flags=%d',
                d.entity,d.resource,cur,priv,mi,d.flags)
            local cfgptr=config_address(g,mm,d,net,0x60,0xA0,0xF124A0,540,160)
            if not cfgptr then return 'magazine_configuration_not_found' end
            local cfg=g:watch(cfgptr+0x88,16)
            maximum=u32(cfg,0)
            spare=i32(g:watch(ptr(g:watch(mm+0x50,8),0)+mi*12,4),0)
            -- Seat guns have no spare reloadable magazines. Else diagnostic only.
            local cfgspare=u32(cfg,12)
            once('profile-mag:'..id(d),
                'mount PROFILE entity=%d res=%s path=magazine cap=%d public=%d private=%d spare=%d cfg_spares=%d',
                d.entity,d.resource,maximum,cur,priv,spare,cfgspare)
            local expected_seat=(maximum>=250 and maximum<=650) or (maximum>=25 and maximum<=40)
            if not expected_seat or cfgspare>0 or spare~=0 then
                once('cfg:'..id(d),'mount SKIP entity=%d res=%s: mag cap=%d spare=%d cfg_spares=%d (reloadable/unknown weapon)',
                    d.entity,d.resource,maximum,spare,cfgspare)
                return 'non_emplacement_magazine_profile'
            end
            if cur<0 or cur>maximum or priv<0 or priv>maximum or math.abs(cur-priv)>16 then
                once('counters:'..id(d),'mount SKIP entity=%d res=%s public=%d private=%d cap=%d',d.entity,d.resource,cur,priv,maximum)
                return 'magazine_counters_unusable'
            end
        else
            -- RoundsComponent: selected barrel magazine (0/1), +state index and reserve.
            -- This path intentionally refills reserve ONLY; don't overwrite loaded/chamber token.
            local rm=manager(g,ROUNDS_ROOT)
            local ri=comp(g,rm,d,0x28,0x40,true)
            if ri==nil then return 'rounds_missing_or_remote' end
            local cfgptr=config_address(g,rm,d,net,0x68,0xA8,0xF12820,50,0x88)
            if not cfgptr then return 'rounds_configuration_not_found' end
            maximum=u32(g:watch(cfgptr+0x50,4),0)
            sa=ptr(g:watch(rm+0x58,8),0)+ri*20
            local sel=u32(g:watch(sa+4,4),0)
            if sel>1 then return 'rounds_selected_barrel_invalid' end
            local loaded=i32(g:watch(ptr(g:watch(rm+0x50,8),0)+ri*24+4+sel*4,4),0)
            local capfloat=g:watch(cfgptr+0x48+sel*4,4)
            local ffi=require('ffi'); local fl=ffi.new('float[1]');ffi.copy(fl,capfloat,4)
            local magcap=math.floor(fl[0]+0.5)
            once('profile-rounds:'..id(d),
                'mount PROFILE entity=%d res=%s path=rounds max_reserve=%d reserve=%d loaded=%d magazine_cap=%d barrel=%d',
                d.entity,d.resource,maximum,i32(g:watch(sa,4),0),loaded,magcap,sel)
            if maximum<25 or maximum>40 or magcap<1 or magcap>100 or loaded<0 or loaded>magcap then
                return 'rounds_configuration_unverified'
            end
            cur=i32(g:watch(sa,4),0)
            if cur<0 or cur>maximum then return 'rounds_reserve_out_of_range' end
        end
        local deficit=maximum-cur
        if deficit<=0 then
            once('full:'..id(d),'mount FULL entity=%d res=%s path=%s ammo=%d/%d (nothing to refill)',
                d.entity,d.resource,r.path,cur,maximum)
            r.ammo_credit=0;return 'no_change'
        end
        local sum=(r.ammo_credit or 0)+maximum*C.ammo_rate*math.min(1,dt)
        n=math.min(deficit,math.floor(sum))
        if n<=0 then r.ammo_credit=sum;return 'no_change' end
        g:validate()
        if not authoritative then
            once('read-only-remote:'..id(d),
                'mount DIAG_ONLY entity=%d res=%s ammo=%d/%d: not authoritative; no memory write',
                d.entity,d.resource,cur,maximum)
            return 'not_authoritative'
        end
        -- Even if the native firing signature differs, still log the actual
        -- ammo layout from a seated weapon. Never write on an unverified build.
        if t.write_allowed==false then
            once('write-guard:'..id(d),
                'mount DIAG_ONLY entity=%d res=%s ammo=%d/%d: firing guard unavailable; no memory write',
                d.entity,d.resource,cur,maximum)
            return 'firing_signature_unverified'
        end
        local ok,why
        if r.path=='magazine' then ok,why=write_both(fa,priv,pa,cur,n)
        else ok=W.i32(sa,cur,cur+n);why=ok and nil or 'reserve_write_failed' end
        if not ok then
            if why=='rollback_failed' then r.quarantined=true end
            log('mount FAIL entity=%d res=%s path=%s %s',d.entity,d.resource,r.path,tostring(why))
            return why
        end
        r.ammo_credit=sum-n
        local now=(t.clock or 0)
        if not r.reported or now-(r.log_at or 0)>=3 then
            log('mount REFILL entity=%d resource=%s type=%s path=%s public_or_reserve=%d->%d private=%s cap=%d wearer=%d',
                d.entity,d.resource,classify(maximum),r.path,cur,cur+n,priv and tostring(priv+n) or '-',maximum,r.seat)
            r.reported=true;r.log_at=now
        end
        return 'ammo_replenished'
    end
    return M
end
