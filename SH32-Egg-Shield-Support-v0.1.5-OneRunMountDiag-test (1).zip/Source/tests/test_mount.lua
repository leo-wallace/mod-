-- Isolated Lua 5.4 in-memory test. Game execution is NOT simulated.
package.preload.ffi = function() return {new=function() return {[0]=0} end,
    copy=function(dst,b) dst[0]=string.unpack('<f',b) end} end
local filename=arg[1]
local maker=assert(loadfile(filename))()
local function u32(s,o) return string.unpack('<I4',s,o+1) end
local function i32(s,o) return string.unpack('<i4',s,o+1) end
local function ptr(s,o) return string.unpack('<I8',s,o+1) end
local function hex64(s,o) return string.format('%08x%08x',u32(s,o+4),u32(s,o)) end
local m={};local base=0x1000000
local function put(a,b) for j=1,#b do m[a+j-1]=b:byte(j) end end
local function get(a,n) local t={} for j=0,n-1 do t[j+1]=string.char(m[a+j] or 0) end return table.concat(t) end
local function link(a,v)put(a,string.pack('<I8',v))end
local wearer={entity=9,resource='4d1c334d294dfa97',unit=909,goid=222,flags=1}
local gun={entity=19,resource='1234567890abcdef',unit=919,goid=333,flags=1}
local seat={entity=77,resource='1111111188888888',unit=777,goid=337,flags=1}
local net,inv,selector,mag,rounds=0x200000,0x300000,0x310000,0x320000,0x330000
local isrow,selrow,magstate,magpublic,magcfg,registry=0x410000,0x420000,0x430000,0x440000,0x450000,0x460000
link(base+0x3326738,inv);link(base+0x3326420,selector);link(base+0x3326648,mag);link(base+0x3326CF0,rounds)
link(inv+0x50,isrow);link(selector+0x60,selrow)
put(isrow,string.pack('<I4I4I4I4I4I4I4I4',9,0,0,42,70,0,0,0))
put(selrow,string.pack('<I4',19))
link(mag+0x48,magstate);link(mag+0x50,magpublic);link(net+0xF124A0,registry)
local low=tonumber(gun.resource:sub(9,16),16);local high=tonumber(gun.resource:sub(1,8),16)
put(registry,string.pack('<I4I4I4I4',low,high,0,0))
put(registry+540*16+0x88,string.pack('<I4I4I4I4',300,0,0,0))
put(magstate,string.pack('<I4',260))
put(magpublic,string.pack('<i4i4',0,260))
local writes=0
local N={base=base,weapon_ready=true,u32=u32,i32=i32,ptr=ptr,hex64=hex64,
    mod64hex=function()return 0 end, same=function(a,b)
        return a.entity==b.entity and a.resource==b.resource and a.goid==b.goid and a.unit==b.unit end}
N.sample_graph=function()
    local watches={};local g={}
    function g:watch(a,n)local b=get(a,n);watches[#watches+1]={a,n,b};return b end
    function g:root(which) return which=='network' and net or 0 end
    function g:roundtrip(_,d) assert(d.entity==9 or d.entity==19) end
    function g:component(p,e)
        if p==inv or p==selector then return e==9 and 0 or nil,wearer end
        if p==mag then return e==19 and 0 or nil,gun end
        return nil
    end
    function g:net(_,e)return (e==19 and gun) or (e==9 and wearer) end
    function g:lookup()return nil end
    function g:table(a)return {p=a} end
    function g:relation(goid) assert(goid==wearer.goid);return {status='VEHICLE',vehicle=seat,role=1} end
    function g:validate()
        for _,v in ipairs(watches) do assert(get(v[1],v[2])==v[3], 'concurrent mutation') end
    end
    return g
end
local W={writable=function()return true end,
    i32=function(a,old,new)
        if i32(get(a,4),0)~=old then return false end
        put(a,string.pack('<i4',new));writes=writes+1;return true
    end}
local messages={};local log=function(fmt,...)messages[#messages+1]=string.format(fmt,...) end
local C={ammo=true,mount_ammo=true,ammo_rate=.1,authority_only=true}
local mod=maker(N,W,log,C)
local r=assert(mod.observe(wearer));assert(r.d.entity==19)
assert(r.seat_collection and r.seat_collection.entity==seat.entity)
print('PASS native Seater descriptor is attached as a verified seat link')
assert(mod.step(r,0.5,{allowed=false,clock=1})=='not_in_wearer_radius')
assert(writes==0)
assert(mod.step(r,0.5,{allowed=true,clock=2})=='ammo_replenished')
assert(i32(get(magstate,4),0)==275 and i32(get(magpublic+4,4),0)==275)
print('PASS seated observer + HMG-like 300 max, dual counter write + range condition')
put(magpublic+4,string.pack('<i4',274))
assert(mod.step(r,0.5,{allowed=true,clock=3})=='ammo_replenished')
assert(i32(get(magpublic+4,4),0)==289 and i32(get(magstate,4),0)==290)
print('PASS mismatched by 1 count remains mismatched by 1 (native firing delta preserved)')
put(selrow,string.pack('<I4',42))
assert(mod.observe(wearer)==nil,'normal inventory weapon must not learn')
print('PASS hand-held inventory selection not mistaken for mounted weapon')
-- Read-only diagnostics must not write even with a valid selected mount and below-capacity ammo.
put(selrow,string.pack('<I4',19))
local q=assert(mod.observe(wearer))
local before=writes
assert(mod.step(q,0.5,{allowed=true,clock=4,write_allowed=false})=='firing_signature_unverified')
assert(writes==before)
assert(table.concat(messages,'\n'):find('mount PROFILE',1,true))
assert(table.concat(messages,'\n'):find('mount DIAG_ONLY',1,true))
print('PASS unverified native signature still records read-only layout without writing')
assert(#messages>0)
