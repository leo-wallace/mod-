-- Isolated Lua 5.4 mock for the sentry service module. Does not emulate the actual game.
package.preload.ffi=function()
    return {new=function()return {[0]=0} end, copy=function(dst,str,n) dst[0]=string.unpack('<f',str) end}
end
local modpath=arg[1]
local make=assert(loadfile(modpath))()
local function u32(s,o) return string.unpack('<I4',s,o+1) end
local function i32(s,o) return string.unpack('<i4',s,o+1) end
local function ptr(s,o) return string.unpack('<I8',s,o+1) end
local function hex64(s,o) return string.format('%08x%08x',u32(s,o+4),u32(s,o)) end
local m={};local writes={};local failaddr=nil;local base=0x1000000
local function put(a,b) for j=1,#b do m[a+j-1]=b:byte(j) end end
local function get(a,n) local t={} for j=0,n-1 do t[j+1]=string.char(m[a+j] or 0) end return table.concat(t) end
local function write(a,old,new) if a==failaddr or i32(get(a,4),0) ~= old then return false end;put(a,string.pack('<i4',new));writes[#writes+1]=a;return true end
local d={resource='37cde43876ba26bb',entity=19,unit=5,goid=4,flags=1}
local net,hm,mag,payload,synced=0x400000,0x500000,0x600000,0x700000,0x800000
local hrec,hside,magrow,magpriv,magcfg,payloadretract,payloadlife,syncrow=0x900000,0x910000,0x920000,0x930000,0x940000,0x950000,0x960000,0x970000
local N={base=base,roots={health=0x3326688},win={},ready=true,weapon_ready=true,u32=u32,i32=i32,ptr=ptr,hex64=hex64}
N.win.read=get
N.same=function(a,b)return a.entity==b.entity and a.resource==b.resource and a.goid==b.goid and a.unit==b.unit end
N.mod64hex=function()return 0 end
local function ptrlink(at,p)put(at,string.pack('<I8',p))end
ptrlink(base+0x3326688,hm)
ptrlink(base+0x3326648,mag)
ptrlink(base+0x3326560,payload)
ptrlink(base+0x3326C98,synced)
ptrlink(hm+0x1058,hrec);ptrlink(hm+0x1060,hside)
ptrlink(mag+0x50,magrow);ptrlink(mag+0x48,magpriv);ptrlink(mag+0xA0,magcfg)
ptrlink(payload+0x48,payloadretract);ptrlink(payload+0x50,payloadlife)
ptrlink(synced+0x50,syncrow)
put(hrec+0x14,string.pack('<i4',100));put(hrec+0x19c,string.pack('<I4',0))
put(hside+20,string.pack('<I4',200))
put(magrow+4,string.pack('<i4',50));put(magpriv,string.pack('<i4',50))
put(magcfg+0x88,string.pack('<I4I4',100,0))
put(payload+0x14,string.pack('<I4',1))
put(payloadretract,string.pack('<f',-1));put(payloadlife+4,string.pack('<f',20))
put(syncrow,string.pack('<i4',100))
for _,s in ipairs({{0x744D6C,'488b4d38488bdf48c1e30448035d48'},
                   {0x744DAD,'833b000f9fc0'},
                   {0x76E33B,'488d0452488d0c8500000000498b42504489740104'}}) do
  put(base+s[1],(s[2]:gsub('%x%x',function(h)return string.char(tonumber(h,16))end)))
end
function N.sample_graph()
 local watched={};local g={}
 function g:watch(a,n)local s=get(a,n);watched[#watched+1]={a,n,s};return s end
 function g:root(name)return name=='network' and net or hm end
 function g:roundtrip(_,dd)assert(dd.entity==19)end
 function g:component(p,e,to,dp)assert(e==19);return 0,d end
 function g:table(p)return {address=p}end
 function g:lookup(t,e)return 0 end
 function g:validate() for _,v in ipairs(watched) do assert(get(v[1],v[2])==v[3],'validation failed') end end
 return g
end
local W={writable=function() return true end,i32=write}
local log={};local logger=function(...)log[#log+1]=string.format(...) end
local C={sentry_ammo=true,sentry_repair=true,ammo=true,ammo_rate=.10,sentry_heal_rate=.04,authority_only=true}
local sr=make(N,W,logger,C)
assert(sr.ready())
local a=sr.step(d,0.5)
assert(a=='ammo_replenished',tostring(a))
assert(i32(get(magrow+4,4),0)==55 and i32(get(magpriv,4),0)==55)
assert(i32(get(hrec+0x14,4),0)==104 and i32(get(syncrow,4),0)==104)
assert(#writes==4)
-- Fire between updates. New count stays synchronized.
put(magrow+4,string.pack('<i4',50));put(magpriv,string.pack('<i4',50))
assert(sr.step(d,0.5)=='ammo_replenished')
assert(i32(get(magpriv,4),0)==55 and i32(get(hrec+0x14,4),0)==108)
print('PASS sentry ammo dual-counter refill and HP + sync, firing between passes')
local prior=#writes
put(magpriv,string.pack('<i4',49))
assert(sr.step(d,0.5)=='health_restored')
assert(#writes==prior+2)
assert(i32(get(magrow+4,4),0)==55 and i32(get(magpriv,4),0)==49)
print('PASS mismatched ammo skips ammo only, permits health repair')
put(magpriv,string.pack('<i4',50));put(magrow+4,string.pack('<i4',50))
failaddr=magrow+4;prior=#writes
assert(sr.step(d,0.5):find('rolled back'))
assert(i32(get(magpriv,4),0)==50 and i32(get(magrow+4,4),0)==50)
failaddr=nil
print('PASS public write failure rolls private counter back')
put(payloadretract,string.pack('<f',0));prior=#writes
assert(sr.step(d,0.5)=='sentry_retracting' and #writes==prior)
put(payloadretract,string.pack('<f',-1))
d.flags=0;prior=#writes
assert(sr.step(d,0.5)=='not_authoritative' and #writes==prior)
d.flags=1
put(base+0x744DAD,'AAAAAA')
sr.reset();prior=#writes
assert(sr.step(d,0.5):find('sentry_layout_not_verified') and #writes==prior)
print('PASS retract, authority and opcode gate')
print('PASS all Lua 5.4 isolated tests')
