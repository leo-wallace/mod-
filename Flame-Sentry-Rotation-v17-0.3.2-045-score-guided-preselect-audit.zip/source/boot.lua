local key='CodexFlameSentryTimedRotation'
if rawget(_G,key) then return rawget(_G,key)end
local M={version='0.3.2-045-score-guided-preselect-audit',status='starting',disabled=false}
rawset(_G,key,M)
local loader=rawget(_G,'CowboyBingusModLoader')
local previous_update=rawget(_G,'update')
if type(loader)~='table' or loader.api~=1                                                       
    or type(loader.open_log)~='function' or type(previous_update)~='function' then
    M.disabled=true;M.status='requires_Shared_Loader_v17_API1'
    print('[FlameSentryRotation] '..M.status);return M
end
local api,game,log,native,snapshot,controller
local function emit(message)
    local line=os.date('!%Y-%m-%dT%H:%M:%SZ')..' '..message
    if log then assert(log:write(line..'\n'));assert(log:flush())end
    print('[FlameSentryRotation] '..message)
    M.status=message
end
local ok,why=pcall(function()
    log=assert(loader.open_log('FlameSentryRotation.log'),'log_unavailable')
    emit('START version='..M.version..' build=25480438 mode=ROTATION_045_SCORE_GUIDED_PRESELECT_AUDIT gameplay=UNVERIFIED')
    emit('POLICY lock_seconds=0.45 candidate_lease_seconds=0.25 result_window_seconds=0.80 scope=Flamethrower207 timer_basis=NATIVE_LOCK_NOT_HIT target_policy=NATIVE_SCORE_GUIDED_SINGLE_CHOICE')
    emit('STATUS_PROBE=REMOVED HEALTH_MOD=REMOVED IDENTITY_TRACE=TARGET_CHANGE_ONLY target_policy=NATIVE_SCORE_GUIDED_SINGLE_CHOICE mismatch_audit=ON preselect_audit=ON damage=UNCHANGED burning=UNCHANGED enemy_health=UNCHANGED')
    api=WindowsRead()
    game=assert(api.module('game.dll'),'game_dll_missing')
    assert(api.module_hash(game):lower()==SPEC.game_sha256,'unsupported_game_dll_no_write')
    emit('GAME_HASH_VERIFIED')
    local raw_read=api.read
    api.read=function(address,size)
        if type(address)~='number' or address%1~=0 or type(size)~='number' or size%1~=0
            or address<65536 or address+size>=0x800000000000 or size<=0 or size>16384 then return nil end
        local parts={}
        for i=0,size-1,2048 do
            local b=raw_read(address+i,math.min(2048,size-i))
            if not b then return nil end
            parts[#parts+1]=b
        end
        return table.concat(parts)
    end
    api.compare_write=MakeWriter(api)
    local reader=SnapshotFactory()
    -- Only the native reader is exposed by the modified factory; the reference
    -- installer and aim/fire/selection writers are never created or executed.
    assert(type(reader)=='table' and type(reader.snapshot)=='function','snapshot_factory_invalid')
    local count=0
    for resource,p in pairs(reader.profiles)do
        if p.behavior~=207 then reader.profiles[resource]=nil
        else count=count+1;assert(p.name=='Flamethrower' and p.fire_gate==nil,'flame_profile_changed')end
    end
    assert(count==1,'flame_profile_missing')
    snapshot=reader.snapshot
    native=Native.new(api,game)
    controller=Controller.new(api,native,emit,{dwell=0.45,lease=0.25,result_window=0.8})
    M.controller=controller
    emit('READY waiting_for_local_flame_sentry RETARGET_RESULT=NOT_YET_OBSERVED STATUS_PROBE=OFF HEALTH_MOD=OFF IDENTITY_TRACE=ON TARGET_POLICY=SCORE_GUIDED MISMATCH_AUDIT=ON PRESELECT_AUDIT=ON')
end)
if not ok then
    M.disabled=true;pcall(emit,'STARTUP_FAILED_NO_WRITE '..tostring(why))
    if log then pcall(function()log:close()end)end
    return M
end
local next_tick,next_summary=0,0
local snapshot_failures=0
local last_snapshot_error
local function tick()
    local now=api.time()
    controller.expire(now)
    if M.disabled then return end
    if controller.disabled then
        M.disabled=true;controller.stop('controller_disabled')
        emit('DISABLED inspect_log');return
    end
    if now<next_tick then return end
    next_tick=now+0.05
    local good,rows,state=pcall(snapshot,api,game)
    if not good then
        snapshot_failures=snapshot_failures+1
        if rows~=last_snapshot_error or snapshot_failures==1 or snapshot_failures%100==0 then
            emit('SNAPSHOT_UNAVAILABLE no_request count='..snapshot_failures..' reason='..tostring(rows))
            last_snapshot_error=rows
        end
        -- Mission transitions can temporarily invalidate the registry. Release
        -- only still-owned bytes; let a fresh snapshot discover new instances.
        controller.step({},now)
    else
        snapshot_failures=0;last_snapshot_error=nil
        controller.step(rows,now)
        if now>=next_summary then
            next_summary=now+10
            emit(string.format('SUMMARY local_flame_sentries=%d requests=%d confirmed_changes=%d exact=%d mismatches=%d timeouts=%d state=%s',
                #rows,controller.requests,controller.changes,controller.exact or 0,controller.mismatches or 0,controller.timeouts,tostring(state)))
        end
    end
end
update=function(...)
    local success,err=pcall(tick)
    if not success then
        M.disabled=true;pcall(controller.stop,'runtime_error')
        pcall(emit,'RUNTIME_DISABLED '..tostring(err))
    end
    return previous_update(...)
end
local previous_shutdown=rawget(_G,'shutdown')
shutdown=function(...)
    M.disabled=true
    local cleanup_ok,clean=pcall(controller.stop,'shutdown')
    pcall(emit,string.format('SHUTDOWN requests=%d confirmed_changes=%d exact=%d mismatches=%d mismatch_entity_gone=%d mismatch_not_in_cache=%d mismatch_ineligible=%d mismatch_still_eligible=%d mismatch_actual_preseen=%d mismatch_actual_not_preseen=%d timeouts=%d cleanup_ok=%s',
        controller.requests,controller.changes,controller.exact or 0,controller.mismatches or 0,controller.mismatch_entity_gone or 0,controller.mismatch_not_in_cache or 0,controller.mismatch_ineligible or 0,controller.mismatch_still_eligible or 0,controller.mismatch_actual_preseen or 0,controller.mismatch_actual_not_preseen or 0,controller.timeouts,tostring(cleanup_ok and clean)))
    if log then pcall(function()log:close()end);log=nil end
    if type(previous_shutdown)=='function' then return previous_shutdown(...)end
end
return M
