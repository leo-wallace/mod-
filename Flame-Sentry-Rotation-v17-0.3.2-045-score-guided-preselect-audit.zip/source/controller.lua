-- Timed native re-selection experiment, not a fear/status detector.
local Controller={}
function Controller.new(api,native,emit,options)
    local opt=options or {}
    local dwell=opt.dwell or 1.0
    local ttl=opt.lease or 0.25
    local result_window=opt.result_window or 0.8
    local C={records={},requests=0,changes=0,timeouts=0,disabled=false,identity_seen={},exact=0,mismatches=0,mismatch_entity_gone=0,mismatch_not_in_cache=0,mismatch_ineligible=0,mismatch_still_eligible=0,mismatch_actual_preseen=0,mismatch_actual_not_preseen=0}
    local function log(message)pcall(emit,message)end
    local function restore(record,reason)
        local lease=record.lease
        if not lease then return true end
        local keep={};local restored,skipped,conflict=0,0,0
        for i=#lease.changes,1,-1 do
            local c=lease.changes[i]
            if not native.matches(c.guards) then
                skipped=skipped+1 -- Entity/cache slot was replaced; do not touch its successor.
            else
                local current=api.read(c.address,#c.before)
                if current==c.before then
                    -- Already restored or never written.
                elseif current==c.after then
                    local ok=api.compare_write(c.address,c.after,c.before)
                    if ok then restored=restored+1 else keep[#keep+1]=c end
                elseif current and c.partial then
                    -- A reported partial write can only be undone while every byte
                    -- still belongs to this attempted before/after pair.
                    local ours=true
                    for j=1,#current do
                        local x=current:byte(j)
                        if x~=c.before:byte(j) and x~=c.after:byte(j) then ours=false end
                    end
                    if ours then
                        if api.compare_write(c.address,current,c.before) then restored=restored+1
                        else keep[#keep+1]=c end
                    else conflict=conflict+1 end
                else
                    conflict=conflict+1 -- Native engine or another mod owns the new value.
                end
            end
        end
        if #keep>0 then lease.changes=keep else record.lease=nil end
        log(string.format('LEASE_RELEASE sentry=%u reason=%s restored=%d stale=%d changed=%d pending=%d',
            record.id,reason,restored,skipped,conflict,#keep))
        return #keep==0
    end
    local function notice(r,now,reason)
        if reason~=r.notice or now>=(r.notice_at or 0)+5 then
            r.notice=reason;r.notice_at=now
            log('SKIP sentry='..r.id..' reason='..reason)
        end
    end
    local function classify(a)
        if not a then return 'audit_unavailable' end
        if not a.entity_exists then return 'entity_gone' end
        if not a.in_cache then return 'not_in_cache' end
        if not a.eligible then return 'ineligible' end
        return 'still_eligible'
    end
    local function ref_text(refs)
        if type(refs)~='table' or #refs==0 then return 'none' end
        local out={}
        for i,o in ipairs(refs)do out[i]='+'..tostring(o) end
        return table.concat(out,',')
    end
    local function audit_expected(r,s,expected,actual,phase)
        local ok,a=pcall(native.audit_target,s,expected)
        if not ok then
            log(string.format('RETARGET_MISMATCH_%s sentry=%u expected=%u actual=%u audit_error=%s',phase,r.id,expected,actual,tostring(a)))
            return 'audit_unavailable'
        end
        local state=classify(a)
        log(string.format('RETARGET_MISMATCH_%s sentry=%u expected=%u actual=%u expected_state=%s entity_exists=%s in_cache=%s eligible=%s slots=%u score=%.3f',
            phase,r.id,expected,actual,state,tostring(a.entity_exists),tostring(a.in_cache),tostring(a.eligible),a.slots or 0,a.score or -1))
        return state
    end
    local function request(r,s,now)
        local ok,plan,why=pcall(native.prepare,s,{avoid_target=r.previous_target})
        if not ok then notice(r,now,'layout_or_snapshot_rejected '..tostring(plan));r.retry=now+2;return end
        if not plan then notice(r,now,why or 'no_plan');r.retry=now+0.25;return end
        if not plan.valid() then notice(r,now,'preflight_changed');r.retry=now+0.25;return end
        log(string.format('RETARGET_PLAN sentry=%u current=%u chosen=%u chosen_score=%.3f alternatives=%d avoid_previous=%u dwell=%.2f',
            s.id,s.target,plan.chosen or 0,plan.chosen_score or -1,plan.alternatives or 0,r.previous_target or 0,dwell))
        for _,c in ipairs(plan.changes)do
            if not native.matches(c.guards) or api.read(c.address,#c.before)~=c.before then
                notice(r,now,'write_precondition_changed');r.retry=now+0.25;return
            end
        end
        r.lease={changes={},until_time=now+ttl}
        for _,c in ipairs(plan.changes)do
            if not plan.valid() or not native.matches(c.guards) then
                if not restore(r,'precondition_changed') then C.disabled=true end
                r.retry=now+0.5;return
            end
            if c.before~=c.after then
                r.lease.changes[#r.lease.changes+1]=c
                -- Register ownership before the OS call, including partial writes/errors.
                c.partial=true
                local success,write_ok,why_write=pcall(api.compare_write,c.address,c.before,c.after)
                if not success or not write_ok then
                    C.disabled=true
                    restore(r,'write_failed')
                    log('DISABLED write_failed '..tostring(why_write or write_ok))
                    return
                end
                c.partial=false
            end
        end
        C.requests=C.requests+1;r.notice=nil
        r.pending={from=s.target,expected=plan.chosen,at=now,until_time=now+result_window,samples=0,preselect_refs=plan.preselect_refs}
        r.retry=now+dwell
        log(string.format('ROTATE_REQUEST sentry=%u from=%u node=%u alternatives=%d masked_slots=%d lock_s=%.2f deadline_delta_us=%.0f request=%d',
            s.id,s.target,s.node,plan.alternatives,plan.slots,now-r.locked_since,plan.deadline_us,C.requests))
    end
    function C.expire(now)
        for _,r in pairs(C.records)do
            if r.lease and (C.disabled or now>=r.lease.until_time) then
                if not restore(r,C.disabled and 'disabled' or 'lease_timeout') then C.disabled=true end
            end
        end
    end
    function C.step(snapshots,now)
        C.expire(now)
        local seen={}
        for _,s in ipairs(snapshots)do
            if s.profile=='Flamethrower' then
                seen[s.id]=true
                local r=C.records[s.id]
                if r and (r.key~=s.key or r.behavior_address~=s.behavior_address) then
                    if not restore(r,'entity_replaced') then C.disabled=true end
                    log('ENTITY_REPLACED sentry='..s.id)
                    if r.lease then return end
                    C.records[s.id]=nil;r=nil
                end
                if not r then
                    r={id=s.id,key=s.key,behavior_address=s.behavior_address,target=0,
                        locked_since=now,retry=now,failures=0}
                    C.records[s.id]=r
                    log(string.format('SENTRY_FOUND sentry=%u behavior=207 node=%u target=%u source_flags=%u has=%s runtime_target=%u enabled=%s',
                        s.id,s.node,s.target,s.source_flags,tostring(s.has),s.runtime_target,tostring(s.enabled)))
                end
                if r.recheck and now>=r.recheck.due then
                    audit_expected(r,s,r.recheck.expected,r.recheck.actual,'RECHECK')
                    r.recheck=nil
                end
                local engaged=native.engaged(s)
                if r.pending then
                    local p=r.pending
                    if engaged and s.target~=p.from then
                        if p.candidate==s.target then p.samples=p.samples+1
                        else p.candidate=s.target;p.samples=1 end
                        if p.samples>=2 then
                            C.changes=C.changes+1;r.failures=0;r.previous_target=p.from
                            local matched=(p.expected==s.target)
                            if matched then C.exact=C.exact+1 else
                                C.mismatches=C.mismatches+1
                                local actual_refs=p.preselect_refs and p.preselect_refs[s.target] or nil
                                local expected_refs=p.preselect_refs and p.preselect_refs[p.expected or 0] or nil
                                local actual_preseen=type(actual_refs)=='table' and #actual_refs>0
                                if actual_preseen then C.mismatch_actual_preseen=C.mismatch_actual_preseen+1
                                else C.mismatch_actual_not_preseen=C.mismatch_actual_not_preseen+1 end
                                log(string.format('RETARGET_PRESELECT_AUDIT sentry=%u expected=%u actual=%u actual_seen_before_request=%s actual_offsets=%s expected_offsets=%s',
                                    s.id,p.expected or 0,s.target,tostring(actual_preseen),ref_text(actual_refs),ref_text(expected_refs)))
                                local state=audit_expected(r,s,p.expected or 0,s.target,'NOW')
                                if state=='entity_gone' then C.mismatch_entity_gone=C.mismatch_entity_gone+1
                                elseif state=='not_in_cache' then C.mismatch_not_in_cache=C.mismatch_not_in_cache+1
                                elseif state=='ineligible' then C.mismatch_ineligible=C.mismatch_ineligible+1
                                elseif state=='still_eligible' then C.mismatch_still_eligible=C.mismatch_still_eligible+1 end
                                r.recheck={expected=p.expected or 0,actual=s.target,due=now+0.10}
                            end
                            log(string.format('TARGET_CHANGED_AFTER_REQUEST sentry=%u from=%u to=%u expected=%u expected_match=%s elapsed_s=%.3f changes=%d causality=NOT_PROVEN',
                                s.id,p.from,s.target,p.expected or 0,tostring(matched),now-p.at,C.changes))
                            r.pending=nil
                            if not restore(r,'target_changed') then C.disabled=true end
                        end
                    else p.candidate=nil;p.samples=0 end
                    if r.pending and now>=p.until_time then
                        C.timeouts=C.timeouts+1;r.failures=r.failures+1
                        log(string.format('NO_CONFIRMED_CHANGE sentry=%u from=%u observed=%u has=%s timeout_s=%.2f',
                            s.id,p.from,s.target,tostring(s.has),now-p.at))
                        r.pending=nil;r.retry=now+(r.failures>=3 and 5 or 1)
                        if not restore(r,'result_timeout') then C.disabled=true end
                    end
                end
                if not engaged then
                    r.locked_since=now;r.target=0
                    notice(r,now,string.format('not_engaged node=%u target=%u runtime=%u flags=%u has=%s enabled=%s',
                        s.node,s.target,s.runtime_target,s.source_flags,tostring(s.has),tostring(s.enabled)))
                elseif r.target~=s.target or (r.last_seen and now-r.last_seen>0.3) then
                    if r.target~=s.target then
                        log(string.format('LOCK_OBSERVED sentry=%u target=%u node=%u',s.id,s.target,s.node))
                        if not C.identity_seen[s.target] then
                            C.identity_seen[s.target]=true
                            local ok_id,ident=pcall(native.enemy_identity,s.target)
                            if ok_id and ident then
                                log(string.format('TARGET_IDENTITY target=%u hash=0x%s meta=%u slot=%u source=FACTION_ENTITY_KEY',
                                    s.target,ident.hash_hex,ident.meta,ident.slot))
                            else
                                log(string.format('TARGET_IDENTITY_UNAVAILABLE target=%u reason=%s',s.target,tostring(ident)))
                            end
                        end
                    end
                    r.target=s.target;r.locked_since=now
                end
                r.last_seen=now
                if not C.disabled and engaged and not r.pending and not r.lease
                    and now>=r.retry and now-r.locked_since>=dwell then request(r,s,now)end
            end
        end
        for id,r in pairs(C.records)do
            if not seen[id] then
                if not restore(r,'sentry_missing') then C.disabled=true end
                if not r.lease then
                    if r.pending then log('REQUEST_UNRESOLVED sentry='..id..' reason=sentry_missing')end
                    log('SENTRY_REMOVED sentry='..id);C.records[id]=nil
                end
            end
        end
    end
    function C.stop(reason)
        C.disabled=true
        local all=true
        for _,r in pairs(C.records)do if not restore(r,reason or 'stop') then all=false end end
        return all
    end
    return C
end
return Controller
