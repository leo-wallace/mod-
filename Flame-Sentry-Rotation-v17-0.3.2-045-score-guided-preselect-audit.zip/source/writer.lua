-- Only 4/8-byte, naturally aligned, already-writable data. Never executable pages.
local function MakeWriter(api)
    local ffi=require('ffi')
    if not pcall(ffi.typeof,'FLAME_ROTATION_MBI') then ffi.cdef[[
        typedef struct { void *BaseAddress; void *AllocationBase;
            uint32_t AllocationProtect; uint16_t PartitionId; uint16_t Padding;
            size_t RegionSize; uint32_t State; uint32_t Protect; uint32_t Type;
        } FLAME_ROTATION_MBI;
        size_t VirtualQuery(const void *,void *,size_t);
        int WriteProcessMemory(void *,void *,const void *,size_t,size_t *);
    ]]end
    assert(ffi.sizeof('FLAME_ROTATION_MBI')==48,'unsupported_page_layout')
    local k=ffi.load('kernel32');local process=k.GetCurrentProcess()
    return function(address,before,after)
        local n=#after
        assert((n==4 or n==8) and #before==n and type(address)=='number' and address>=65536
            and address+n<0x800000000000 and address%n==0,'invalid_data_write')
        local at=ffi.cast('void *',address)
        local mbi=ffi.new('FLAME_ROTATION_MBI[1]')
        if tonumber(k.VirtualQuery(at,mbi,48))~=48 then return false,'page_query_failed' end
        local base=tonumber(ffi.cast('uintptr_t',mbi[0].BaseAddress))
        if mbi[0].State~=0x1000 or mbi[0].Protect~=0x04 or address<base
            or address+n>base+tonumber(mbi[0].RegionSize) then return false,'page_not_writable_data' end
        if api.read(address,n)~=before then return false,'compare_changed' end
        local count=ffi.new('size_t[1]')
        local ok=k.WriteProcessMemory(process,at,after,n,count)~=0
        return ok and tonumber(count[0])==n and api.read(address,n)==after,'write_or_readback_failed'
    end
end
return MakeWriter
