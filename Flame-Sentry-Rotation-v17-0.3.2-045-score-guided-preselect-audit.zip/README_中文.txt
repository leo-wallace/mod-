Flame Sentry Rotation 0.3.2

定位：0.45 秒稳定版 + 轻量预选目标审计。

- 玩法逻辑与 0.3.1 保持一致：0.45 s、Score-Guided、previous-target 防抖、candidate mask + native deadline。
- 不改血量、伤害、燃烧、敌人生命；不恢复 status/Fire_Panic 重型探针。
- 保留 mismatch audit。
- 新增 RETARGET_PRESELECT_AUDIT：仅当 actual != expected 时，检查 actual 的 target ID 是否在“发出请求之前”就已经出现在 BehaviorComponent 的未知对齐字段里。
- 该审计复用 prepare 已经读取的 160 字节 BehaviorComponent，不增加额外内存读取，不做全局扫描。

重点看：
RETARGET_PRESELECT_AUDIT ... actual_seen_before_request=true/false actual_offsets=... expected_offsets=...

如果大量 mismatch 的 actual_seen_before_request=true，说明原生 AI 很可能存在 pending/preselected target 层；如果多数为 false，则更应怀疑其他候选池/cache 更新。

日志：FlameSentryRotation.log
