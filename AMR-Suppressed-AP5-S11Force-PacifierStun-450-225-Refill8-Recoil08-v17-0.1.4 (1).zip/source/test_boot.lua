local function scenario(mode)
    local env=setmetatable({}, {__index=_G});env._G=env
    local logs,cores={},{};local now,forwarded=100,0
    env.SPEC={module_sha256='expected',owner_rva=123,components={{label='WeaponData'},{label='Magazine'},{label='Damage'}}}
    env.print=function()end
    env.CowboyBingusModLoader={api=1,open_log=function(name)
        assert(name=='AmrSuppressedStun.log')
        return {write=function(_,s)logs[#logs+1]=s;return true end,flush=function()return true end,close=function()end}
    end}
    env.WindowsRead=function()return {module=function()return 0x10000000 end,
        module_hash=function()return mode=='bad_hash' and 'wrong' or 'expected'end,
        time=function()return now end,read=function()return nil end}end
    env.WindowsWrite=function()return function()error('unexpected OS write')end end
    env.Core={new=function(_,_,s)
        local c={steps=0,stops=0}
        c.step=function()
            c.steps=c.steps+1
            if mode=='group_fail' and s.label=='Damage' then c.disabled=true;c.status='mismatch';return end
            if mode=='throws' and s.label=='Damage' then error('simulated failure')end
            if c.steps>=2 then c.lease={}end
        end
        c.stop=function()c.stops=c.stops+1 end
        cores[#cores+1]=c;return c
    end}
    env.update=function(...)forwarded=forwarded+1;return select('#',...),... end
    env.shutdown=function(...)return select('#',...),... end
    local f=assert(io.open('source/boot.lua'));local source=f:read('*a');f:close()
    local m=assert(load(source,'@boot','t',env))()
    if mode=='bad_hash' then assert(m.disabled and #cores==0);return end
    assert(env.update()==0)
    assert(cores[1].steps==1 and cores[2].steps==1 and cores[3].steps==1)
    if mode=='group_fail' or mode=='throws' then
        assert(m.disabled and cores[1].stops==1 and cores[2].stops==1 and cores[3].stops==1)
        assert(not table.concat(logs):find('APPLIED_READBACK_OK',1,true));return
    end
    assert(not table.concat(logs):find('APPLIED_READBACK_OK',1,true))
    now=now+2.1;local n,a,b=env.update('ctx',nil)
    assert(n==2 and a=='ctx' and b==nil and forwarded==2)
    for _,c in ipairs(cores)do assert(c.steps==2)end
    assert(table.concat(logs):find('APPLIED_READBACK_OK',1,true))
    assert(table.concat(logs):find('normal=450 durable=225',1,true))
    assert(table.concat(logs):find('magazines_refill=8 magazines_max=8',1,true))
    assert(table.concat(logs):find('recoil_horizontal=0.08 recoil_vertical=0.08',1,true))
    local count,value,empty=env.shutdown('ctx',nil)
    assert(count==2 and value=='ctx' and empty==nil and m.disabled)
    for _,c in ipairs(cores)do assert(c.stops==1)end
end
scenario('normal');scenario('bad_hash');scenario('group_fail');scenario('throws')
print('PASS API1 update forwarding, success reporting, bad build refusal and full rollback across all three records')
