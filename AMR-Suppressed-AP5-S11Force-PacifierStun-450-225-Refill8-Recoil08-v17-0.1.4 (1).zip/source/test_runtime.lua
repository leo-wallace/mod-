local function fixture(which,mode)
    local lib=dofile('source/test_spec.lua')
    local s=lib.SPEC.components[which]
    s.game=0x10000000;s.owner_rva=lib.SPEC.owner_rva
    local owner=0x20000000;local tab=0x30000000
    local row=s.direct and tab or tab+#s.hashmap+s.record_index*s.record_size
    local slot=tab;local data=s.original
    if mode=='old_mod' and which==3 then data=data:sub(1,8)..string.pack('<I4',450)..data:sub(13)end
    if mode=='conflict' then data=data:sub(1,4)..'\255'..data:sub(6)end
    local allowed,expected={},s.original
    for _,e in ipairs(s.edits)do
        allowed[row+e.offset]=#e.replacement
        expected=expected:sub(1,e.offset)..e.replacement..expected:sub(e.offset+#e.replacement+1)
    end
    local writes,logs={},{};local fail=mode=='partial';local api={}
    function api.pointer(bytes)if bytes then return string.unpack('<I8',bytes)end end
    function api.read(at,n)
        if not s.direct and at==s.game+s.owner_rva and n==8 then return string.pack('<I8',owner)end
        if at==(s.direct and s.game or owner)+s.candidate_slot and n==8 then return string.pack('<I8',slot)end
        if s.direct then
            for i,g in ipairs(s.guards)do
                if at==tab+g.offset and n==#g.bytes then
                    if mode=='guard_mismatch' and i==1 then return '\255'..g.bytes:sub(2)end
                    return g.bytes
                end
            end
        elseif at>=tab and at+n<=tab+#s.hashmap then
            local bytes=s.hashmap:sub(at-tab+1,at-tab+n)
            if mode=='guard_mismatch' and at==tab then bytes='\255'..bytes:sub(2)end
            return bytes
        end
        if at>=row and at+n<=row+#data then return data:sub(at-row+1,at-row+n)end
    end
    function api.write(at,bytes)
        assert(allowed[at]==#bytes,'unexpected address or write size')
        writes[#writes+1]={at=at,bytes=bytes};local off=at-row
        if fail and which==3 and off==44 then
            fail=false;data=data:sub(1,off)..bytes:sub(1,4)..data:sub(off+5);return false
        end
        data=data:sub(1,off)..bytes..data:sub(off+#bytes+1);return true
    end
    return {core=lib.Core.new(api,function(s)logs[#logs+1]=s end,s),spec=s,data=function()return data end,
        expected=expected,writes=writes,relocate=function()slot=0x50000000 end}
end
for which=1,3 do
    local f=fixture(which);f.core.step()
    assert(f.core.lease and not f.core.disabled and f.data()==f.expected and #f.writes==#f.spec.edits)
    if which==1 then
        assert(math.abs(string.unpack('<f',f.data(),61)-0.08)<0.000001 and math.abs(string.unpack('<f',f.data(),65)-0.08)<0.000001)
        assert(f.data():byte(113)==1 and string.unpack('<I4',f.data(),133)==12)
        print('PASS AMR recoil multipliers 0.08; suppression/noise retained')
    elseif which==2 then
        assert(string.unpack('<I4',f.data(),137)==7 and string.unpack('<I4',f.data(),141)==5)
        assert(string.unpack('<I4',f.data(),145)==8 and string.unpack('<I4',f.data(),149)==8)
        print('PASS AMR magazine refill 8; capacity 7, starting 5, maximum 8 retained')
    else
        assert(string.unpack('<I4',f.data())==206)
        assert(string.unpack('<i4',f.data(),5)==450 and string.unpack('<i4',f.data(),9)==225)
        for _,p in ipairs({13,17,21})do assert(string.unpack('<I4',f.data(),p)==5)end
        assert(string.unpack('<I4',f.data(),25)==0)
        assert(string.unpack('<I4',f.data(),33)==80 and string.unpack('<I4',f.data(),37)==35)
        assert(string.unpack('<I4',f.data(),45)==39 and string.unpack('<f',f.data(),49)==5)
        print('PASS AMR damage450/225, AP5, force80/35, Pacifier StunLarge39 strength5 unchanged')
    end
    f.core.step();assert(#f.writes==#f.spec.edits)
    assert(f.core.stop() and f.data()==f.spec.original and #f.writes==2*#f.spec.edits)
    assert(f.core.stop() and #f.writes==2*#f.spec.edits)
    local bad=fixture(which,'conflict');bad.core.step();assert(bad.core.disabled and #bad.writes==0)
    local guard=fixture(which,'guard_mismatch');guard.core.step();assert(not guard.core.lease and #guard.writes==0)
    local stale=fixture(which);stale.core.step();stale.relocate();stale.core.step()
    assert(stale.core.disabled and not stale.core.stop() and #stale.writes==#stale.spec.edits)
end
local old=fixture(3,'old_mod');old.core.step();assert(old.core.disabled and #old.writes==0)
local partial=fixture(3,'partial');partial.core.step()
assert(partial.core.disabled and partial.data()==partial.spec.original and not partial.core.lease)
print('PASS exact lease restore, idempotence, map/record mismatch refusal, old damage conflict and partial-write rollback')
