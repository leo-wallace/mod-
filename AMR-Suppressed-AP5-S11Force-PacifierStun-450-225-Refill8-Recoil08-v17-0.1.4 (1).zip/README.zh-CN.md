# 反器材：补给 8 + 低后坐力 — 0.1.4

基于你提供的 0.1.2 包，只调整弹匣补给量和后坐力；不增加伤害。

- 普通/耐久伤害：原版 450/225，保持不变
- 穿甲：AP5（角度档位 5/5/5/0），保持不变
- 消音：保持不变
- S-11 受力参数：ForceStrength 80、ForceImpulse 35，保持不变
- 安抚者眩晕：StunLarge（类型39），强度5，保持不变
- 弹匣容量：7，保持不变
- 补给弹匣数：4 → 8
- 弹匣上限：8，保持不变
- 水平和垂直后坐力乘数：1.0 → 0.08（降低92%）

后坐力乘数来自 AMR 的 `WeaponDataComponent`。这个字段对所有姿势生效，因此站立和蹲姿也会明显降低后坐力；游戏自身的俯卧姿势效果仍会叠加。当前没有使用未经验证的姿势检测/条件写入。0.08 是保留少量余量的近零设置，方便实测后再微调。

## 安装

停用旧版同身份 AMR 数值包，只启用本包；Shared Loader v17/API1 用法不变。Purge / Deploy 后完全重启游戏。这个包复用原 MOD 的模块身份，请勿与旧版同时启用。

日志：`%LOCALAPPDATA%\CowboyBingus\Helldivers2\Logs\AmrSuppressedStun.log`。成功行应包含 `normal=450 durable=225`、`magazines_refill=8 magazines_max=8` 和 `recoil_horizontal=0.08 recoil_vertical=0.08`。该日志表示内存写入并回读通过，不等于游戏内手感已经验证。

目标构建与哈希守卫沿用 0.1.2：build 25480438。数据表使用完整 map、目标记录和模块 SHA-256 校验；离线测试通过。没有在游戏进程中实测。
