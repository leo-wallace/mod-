# AMR Refill 8 + Low Recoil — 0.1.4

Based on the supplied 0.1.2 package. The original 450/225 damage, AP5, suppression, S-11 force settings, and Pacifier stun remain unchanged. Magazine refill changes from 4 to 8; maximum magazines stays 8. Horizontal and vertical recoil multipliers are set to 0.08.

The recoil multipliers apply in every stance, so standing and crouched recoil are reduced too. The game's native prone modifier still applies. The multiplier is not posture-specific. Build 25480438 and the original Shared Loader v17/API1 package structure are retained. Gameplay feel remains unverified in-game.
