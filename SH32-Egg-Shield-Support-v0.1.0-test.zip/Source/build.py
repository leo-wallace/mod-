from pathlib import Path
import importlib.util, json, uuid, zipfile

ROOT = Path(__file__).resolve().parent
def build():
    src=ROOT/'src'
    def read(n): return (src/n).read_text(encoding='utf-8')
    chunks=['-- HD2-Addon: mods/leo_wallace/egg_shield_support',
            '-- Egg Shield Support 0.1.0-test; see README.md and CREDITS.md',
            'local N=(function()',read('vendor/native_hud.lua'),'end)()',
            'do local ptr,u32,i32,same=N.ptr,N.u32,N.i32,N.same',
            'local G=getmetatable(N.graph(function() end,0)).__index',
            read('vendor/weapon_driverhud.lua'),'end']
    for name,file in [('RepairNative','repair_native.lua'),('WeaponFault','weapon_fault.lua'),
                      ('TyreFault','tyre_fault.lua'),('EggSupport','egg_support.lua')]:
        chunks += ['local '+name+'=(function()',read(file),'end)()']
    chunks += [read('body.lua')]
    lua='\n'.join(chunks).encode()
    dist=ROOT/'dist';dist.mkdir(exist_ok=True)
    (dist/'egg_shield_support.lua').write_bytes(lua)
    spec=importlib.util.spec_from_file_location('pack',ROOT/'tools/pack_patch.py')
    pack=importlib.util.module_from_spec(spec);spec.loader.exec_module(pack)
    patch,_=pack.build_patch([lua])
    out=ROOT.parent.parent/'output/SH32-Egg-Shield-Support-v0.1.0-test.zip'
    out.parent.mkdir(exist_ok=True)
    manifest={'Version':1,'Guid':str(uuid.uuid5(uuid.NAMESPACE_URL,'leo-wallace/sh32-egg-support')),
        'Name':'SH-32 Egg Shield Support 0.1.0 TEST',
        'Description':'Bingus Shared Loader v17+ required. No HD2Runtime dependency. Wearer 160 max HP / 3 HP per sec; moving 14.5m vehicle repair and resupply. Not game-tested. See README.',
        'Options':[{'Name':'SH-32 Support','Description':'Enable backpack support','Include':['data']} ]}
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
        z.writestr('data/9ba626afa44a3aa3.patch_0',patch)
        z.writestr('data/9ba626afa44a3aa3.patch_0.stream',b'')
        z.writestr('data/9ba626afa44a3aa3.patch_0.gpu_resources',b'')
        for name in ['README.md','CREDITS.md','LICENSE','VALIDATION.md']:
            if (ROOT/name).exists():z.write(ROOT/name,name)
        z.writestr('Source/dist/egg_shield_support.lua',lua)
        for folder in ['src','tools','tests','third_party']:
            for p in sorted((ROOT/folder).rglob('*')):
                if p.is_file() and '__pycache__' not in p.parts and not any(x.startswith('.run') for x in p.parts):
                    z.write(p,'Source/'+str(p.relative_to(ROOT)))
        z.write(ROOT/'build.py','Source/build.py')
    print(out)
    return out,lua

if __name__=='__main__':build()
