-- SH-32 support: independent inventory reader and live per-entity health lease.
-- Uses research from HD2Runtime by SkyeShade (see CREDITS.md).
-- No HD2Runtime module is loaded. Shield state is intentionally never read.
return function(N,W,log,scan_index,repair)
    local E={leases={},reported={},max_health=160,regen=3}
    local ptr,u32,i32=N.ptr,N.u32,N.i32
    local INVENTORY=53634872
    local SH32='12c8d71ac3897a5c'
    local PLAYER='4d1c334d294dfa97'
    local pins={
        {10132699,'4c8b1d56ca9702'}, {10132708,'458b5330'},
        {10132715,'418b5b38'}, {10132732,'498b7b28'},
        {10132736,'418b7334'}, {10132834,'498b4350'},
        {10132838,'4803c9'}, {10132841,'8b4cc80c'},
        {10148678,'488b4740'},
        {9557549,'486be91c'}, {9557574,'4803af60100000'},
        {9557652,'8b4514'}, {9557662,'41894514'},
    }
    local function bytes(h)
        return (h:gsub('..',function(v)return string.char(tonumber(v,16))end))
    end
    local function key(d)
        return d.entity..':'..d.goid..':'..d.unit..':'..d.resource
    end
    local function report(s)
        if not E.reported[s] then E.reported[s]=true;log('egg: %s',s) end
    end
    function E.prove()
        if E.proven==N.base then return end
        for _,pin in ipairs(pins) do
            local want=bytes(pin[2])
            assert(N.win.read(N.base+pin[1],#want)==want,'unsupported inventory layout')
        end
        E.proven=N.base
    end
    -- The HealthExt maximum belongs to one live entity. Shared player templates
    -- and all stim-related fields remain untouched.
    function E.health(d)
        local g=N.sample_graph()
        local net,hm=g:root('network'),g:root('health')
        local now=g:net(net,d.entity,true)
        if not N.same(now,d) then g:validate();return {gone=true} end
        g:roundtrip(net,d)
        local idx,owner=g:component(hm,d.entity,0x1030,0x1048)
        if not idx or not N.same(owner,d) then error('player health identity changed') end
        local rec=ptr(g:watch(hm+0x1058,8),0)+idx*0x1B8
        local hp=i32(g:watch(rec+0x14,4),0)
        local dead=u32(g:watch(rec+0x19C,4),0)
        local ext=ptr(g:watch(hm+0x1060,8),0)+idx*0x1C+0x14
        local maximum=i32(g:watch(ext,4),0)
        assert(maximum>0 and maximum<=100000,'invalid player maximum health')
        g:validate()
        return {cfg=ext,maximum=maximum,hp=hp,manager=hm,
            alive=hp>0 and dead==0,owned=owner.flags%2==1}
    end

    function E.wearers()
        E.prove()
        local g=N.sample_graph()
        local net=g:root('network')
        local mgr=ptr(g:watch(N.base+INVENTORY,8),0)
        local t=g:table(mgr+0x28)
        local entities,indices,n=scan_index(t,65536,'inventory index bound')
        local result={}
        for k=1,n do
            local d=g:net(net,entities[k],true)
            if d and d.resource==PLAYER then
                local j,owner=g:component(mgr,d.entity,0x28,0x40)
                assert(j==indices[k] and N.same(owner,d),'inventory owner changed')
                local base=ptr(g:watch(mgr+0x50,8),0)
                local backpack=u32(g:watch(base+j*0x30+0x0C,4),0)
                if backpack~=0 and backpack~=4294967295 then
                    local pack=g:net(net,backpack,true)
                    if pack and pack.resource==SH32 then
                        g:roundtrip(net,d);g:roundtrip(net,pack)
                        local h=E.health(d)
                        if h.alive then result[#result+1]={d=d,pack=pack,health=h} end
                    end
                end
            end
        end
        g:validate()
        return result
    end
    -- Only fields actually written by this mod are restored, and only while the
    -- original entity still owns that instance record. Failed restores retry.
    local function release(k,e)
        local ok,h=pcall(E.health,e.d)
        if not ok then report('health restore pending: '..tostring(h));return false end
        if h.gone or h.manager~=e.manager then E.leases[k]=nil;return true end
        e.cfg=h.cfg -- track dense-array relocation through the same entity
        local pending=false
        for off,f in pairs(e.fields) do
            local cur=N.win.read(e.cfg+off,#f.after)
            if cur==f.after then
                if W.raw(e.cfg+off,#cur,cur,f.before) then e.fields[off]=nil
                else pending=true end
            else
                -- Another writer changed this field; do not overwrite its value.
                e.fields[off]=nil
            end
        end
        if not pending then E.leases[k]=nil end
        return not pending
    end
    function E.close()
        for k,e in pairs(E.leases) do
            local ok,err=pcall(release,k,e)
            if not ok then report('health restore pending: '..tostring(err)) end
        end
    end
    local function apply(w,dt)
        local d,h=w.d,w.health
        if not h.owned then return end
        local k=key(d)
        local e=E.leases[k]
        -- Dense arrays can move: the same entity's extension is freshly resolved.
        if e and e.manager~=h.manager then E.leases[k]=nil;e=nil end
        if not e then e={d=d,cfg=h.cfg,manager=h.manager,fields={},credit=0};E.leases[k]=e end
        e.cfg=h.cfg
        local function ubytes(n)
            return string.char(n%256,math.floor(n/256)%256,math.floor(n/65536)%256,math.floor(n/16777216)%256)
        end
        local f=e.fields[0]
        local cur=N.win.read(h.cfg,4)
        if not f and h.maximum<E.max_health then
            f={before=cur,after=ubytes(E.max_health)};e.fields[0]=f
        end
        if f then
            if cur==f.before then
                if not W.raw(h.cfg,4,cur,f.after) then
                    release(k,e);error('wearer maximum-health write failed')
                end
            elseif cur~=f.after then
                report('wearer maximum-health conflict; buff paused')
                return
            end
        end
        -- Accumulate whole HP to avoid losing fractions to the engine's integer
        -- health storage. Nothing is granted merely by picking up the backpack.
        e.credit=math.min(3,e.credit+E.regen*math.min(dt or 0,0.25))
        local amount=math.floor(e.credit)
        if amount<1 then return end
        local fresh=E.health(d)
        if not fresh.alive or not fresh.owned then return end
        if fresh.hp>=fresh.maximum then e.credit=0;return end
        amount=math.min(amount,fresh.maximum-fresh.hp)
        assert(repair.health and repair.health.fn==N.base+9562400,'player heal entry unavailable')
        local done,why=repair.heal(d,amount/fresh.maximum,false)
        if done then e.credit=e.credit-amount else report('player regen: '..tostring(why)) end
    end
    function E.step(enabled,dt)
        if not enabled then E.close();return {} end
        local ok,list=pcall(E.wearers)
        if not ok then report(tostring(list));E.close();return {} end
        local present,centers={},{}
        for _,w in ipairs(list) do
            present[key(w.d)]=true
            centers[#centers+1]=w.d
            local good,err=pcall(apply,w,dt)
            if not good then report(tostring(err)) end
        end
        for k,e in pairs(E.leases) do if not present[k] then
            local good,err=pcall(release,k,e)
            if not good then report(tostring(err)) end
        end end
        return centers
    end
    return E
end
