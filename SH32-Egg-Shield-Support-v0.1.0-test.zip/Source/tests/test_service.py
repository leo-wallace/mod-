"""Actual service loop with mocked engine coordinates/equipment and process RAM.
Uses the original MIT Shield Vehicle Resupply memory harness.
"""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
src=(root/'tests/fixtures/vehicle_harness.py.txt').read_text()
src=src.replace('__SVR_TEST=function(N,W,S,C)','__SVR_TEST=function(N,W,S,C,R,F,T,E)')
src=src.replace('_G.SVR={N=N,W=W,S=S,C=C}',r'''
  C.test=false; C.heal='native'; C.part_repair=false; C.tires=false
  C.native_zone=0; C.exo_weapon_guard=false; C.exo_shield_guard=false; C.frv_tire_guard=false
  C.roster_every=100
  W.raw=function(p,n,o,v)
    if N.win.read(p,n)~=o then return false end
    pywrite(p,v); return true
  end
  W.raw4=function(p,o,v)return W.raw(p,4,o,v)end
  W.raw1=function(p,o,v)return W.raw(p,1,o,v)end
  R.ensure=function()return false end
  F.step=function(v)guard_count=#v end; T.step=function(v)tyre_count=#v end
  F.close=function()guard_count=0 end; T.close=function()tyre_count=0 end
  F.blocked=function()return false end
  wearing=true;center_x=0;vehicle_x=1;vehicle_z=0;shield_broken=false
  E.step=function()
    if wearing then return {{entity=999,unit=99,goid=99,resource='player'}} end
    return {}
  end
  stingray.GameSession.unit_synchronizer=function()return 'sync'end
  stingray.GameSession.game_object_exists=function()return true end
  stingray.UnitSynchronizer.game_object_id_to_unit=function(s,g)return g end
  stingray.UnitSynchronizer.unit_to_game_object_id=function(s,u)return u end
  stingray.Unit.alive=function()return true end
  stingray.Unit.world_position=function(u)
    if u==99 then return {center_x,0,0} end
    return {vehicle_x,0,vehicle_z}
  end
  stingray.Vector3.to_elements=function(v)return unpack(v)end
  _G.SVR={N=N,W=W,S=S,C=C}
''')
exec(compile(src,str(__file__),'exec'))
run=lambda n:L.execute(('for i=1,%d do update(0.1) end'%n).encode())
rate=lambda:struct.unpack('<f',M.r(cfg+4,4))[0]
run(10)
assert L.eval(b'SVR.S.errors') is None
assert rate()==900 and L.globals().guard_count==1
L.execute(b'vehicle_x=14.6');run(6)
assert rate()==0 and L.globals().guard_count==0
L.execute(b'center_x=10; shield_broken=true');run(6)
assert rate()==900 and L.globals().guard_count==1
L.execute(b'wearing=false');run(2)
assert rate()==0 and L.globals().guard_count==0
L.execute(b'wearing=true; vehicle_z=14.6');run(6);assert rate()==0
L.execute(b'vehicle_z=0');run(6);assert rate()==900
L.execute(b'SVR.C.enabled=false');run(2);assert rate()==0
assert L.eval(b'SVR.S.errors') is None
print('PASS actual service loop: moving 14.5m boundary, height, broken shield, removal, guard closure, disable')

# Supply an authoritative magazine owner to the actual refill routine, within
# the existing vehicle network descriptor (mock composition, not a new game claim).
mag=0x50000000;arr=0x51003000
M.w(base+0x3326648,Q(mag));table(mag+0x20,0x51000000,[(ent,0)])
M.w(mag+0x38,Q(0x51002000));M.w(0x51002000,Q(desc));M.w(mag+0x50,Q(arr))
M.w(arr,I(1)+I(1)+I(0))
L.execute(b'''
 SVR.C.enabled=true
 SVR.S.weapons={{d=SVR.S.vehicles[1].d,owner=SVR.S.vehicles[1],
   comp={name='mag',root=0x3326648,to=0x20,dp=0x38,arr=0x50,stride=12,
         fields={{'reserve',0},{'current',4}}}}}
 SVR.C.ammo_max[SVR.S.vehicles[1].d.resource..':magreserve']=10
 SVR.C.ammo_max[SVR.S.vehicles[1].d.resource..':magcurrent']=10
''')
run(20)
assert struct.unpack('<i',M.r(arr,4))[0]>1
before=M.r(arr,8);L.execute(b'wearing=false');run(10);assert M.r(arr,8)==before
assert L.eval(b'SVR.S.errors') is None
print('PASS actual refill: adds ammo while in range; stops when backpack center removed')
