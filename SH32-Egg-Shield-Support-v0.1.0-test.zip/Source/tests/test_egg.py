"""Run the actual inventory/health Lua against isolated synthetic process memory.
No claims about actual engine effects are made by this test.
"""
from pathlib import Path
import struct, json, zipfile, sys
from lupa import luajit21

ROOT=Path(__file__).resolve().parents[1]
U=lambda n:struct.pack('<I',n)
Q=lambda n:struct.pack('<Q',n)
BASE=0x140000000;NET=0x20000000;HM=0x30000000;IM=0x40000000
REC=0x31003000;EXT=0x31005000;INV=0x41003000
PLAYER=int('4d1c334d294dfa97',16);SH32=int('12c8d71ac3897a5c',16)

class Memory:
    def __init__(self):self.m={};self.writes=[];self.fail=False
    def put(self,a,b):
        for i,v in enumerate(b):self.m[a+i]=v
    def read(self,a,n):
        a,n=int(a),int(n)
        return bytes(self.m.get(a+i,0) for i in range(n))
    def write(self,a,n,old,new):
        a,n=int(a),int(n)
        if self.fail or self.read(a,n)!=old:return False
        self.put(a,new);self.writes.append((a,new));return True
    def u(self,a):return struct.unpack('<I',self.read(a,4))[0]

def setup():
    m=Memory();L=luajit21.LuaRuntime(encoding=None)
    def table(at,entries,pairs,cap=16):
        m.put(at,Q(entries)+U(cap)+U(0xffffffff)+U(1))
        m.put(entries,(U(0xffffffff)*2)*cap)
        for k,j in pairs:
            slot=k%cap
            while m.u(entries+slot*8)!=0xffffffff:slot=(slot+1)%cap
            m.put(entries+slot*8,U(k)+U(j))
    m.put(BASE+0x346bf98,Q(NET));m.put(BASE+0x3326688,Q(HM));m.put(BASE+53634872,Q(IM))
    ds=[(PLAYER,100,7,50),(SH32,101,8,51),(PLAYER,102,9,52),(SH32,103,10,53),(123456,104,11,54)]
    for idx,(typ,e,u,g) in enumerate(ds):m.put(NET+0xf32f18+idx*24,Q(typ)+U(e)+U(u)+U(g)+U(1))
    table(NET+0xf1aeb0,0x21000000,[(d[1],i) for i,d in enumerate(ds)])
    table(NET+0xf22ec8,0x21001000,[(d[3],i) for i,d in enumerate(ds)])
    for mgr,offset,entries in [(HM,0x1030,0x31000000),(IM,0x28,0x41000000)]:table(mgr+offset,entries,[(100,0),(102,1)])
    for mgr,off,arr in [(HM,0x1048,0x31002000),(IM,0x40,0x41002000)]:
        m.put(mgr+off,Q(arr));m.put(arr,Q(NET+0xf32f18)+Q(NET+0xf32f18+48))
    m.put(HM+0x1058,Q(REC));m.put(HM+0x1060,Q(EXT));m.put(IM+0x50,Q(INV))
    for i in range(2):m.put(REC+i*0x1b8+0x14,U(100));m.put(EXT+i*28+20,U(125))
    m.put(INV+12,U(101));m.put(INV+48+12,U(0))
    L.globals().pyread=m.read;L.globals().pywrite=m.write
    N=L.execute((ROOT/'src/vendor/native_hud.lua').read_bytes());L.globals().N=N
    N[b'base']=BASE;N[b'ready']=True
    L.execute(b'''N.win={read=pyread,begin_sample=function()end}
      W={raw=function(a,n,o,v)return pywrite(a,n,o,v)end}
      reports={};logger=function(f,s)reports[#reports+1]=s end
      scan=function(t)
        local es,js,n={},{},0
        for i=0,t.capacity-1 do
          local b=pyread(t.entries+i*8,8);local e,j=N.u32(b,0),N.u32(b,4)
          if e~=t.empty and j~=4294967295 then n=n+1;es[n]=e;js[n]=j end
        end
        return es,js,n
      end
      calls=0
      repair={health={fn=N.base+9562400},heal=function(d,f)
        calls=calls+1;last_entity=d.entity;last_fraction=f
        return true
      end}
    ''')
    # Only the precise source-provided pins are provisioned; any unintended
    # shield-state or Runtime access has no fixture/API to satisfy it.
    import re
    source=(ROOT/'src/egg_support.lua').read_bytes()
    for rva,h in re.findall(rb"\{(\d+),'([0-9a-f]+)'\}",source):m.put(BASE+int(rva),bytes.fromhex(h.decode()))
    factory=L.execute(source);E=factory(N,L.globals().W,L.globals().logger,L.globals().scan,L.globals().repair)
    return m,L,E

def tick(E,n=10):
    for _ in range(n):centers=E.step(True,0.1)
    return centers

m,L,E=setup()
assert len(tick(E))==1 and m.u(EXT+20)==160 and m.u(EXT+48)==125
assert L.globals().calls==3 and abs(L.globals().last_fraction-1/160)<1e-9
assert m.u(REC+20)==100, 'must not overwrite live HP'
assert {a for a,_ in m.writes}=={EXT+20}, 'no stim/template/other-person writes'
m.put(INV+12,U(0));assert len(tick(E,1))==0 and m.u(EXT+20)==125
old=L.globals().calls;tick(E);assert L.globals().calls==old
print('PASS wear, wearer-only cap, 3 HP/s requests, no direct HP/stim writes, drop')

for replacement in [104,0]:
    m,L,E=setup();tick(E);m.put(INV+12,U(replacement));tick(E,1)
    assert m.u(EXT+20)==125
for life in [1,2]:
    m,L,E=setup();tick(E);m.put(REC+0x19c,U(life))
    assert len(tick(E,1))==0 and m.u(EXT+20)==125
print('PASS swap, empty slot, downed, death')

m,L,E=setup();m.put(INV+48+12,U(103));assert len(tick(E))==2
assert m.u(EXT+20)==m.u(EXT+48)==160
m.put(INV+12,U(0));assert len(tick(E,1))==1
assert m.u(EXT+20)==125 and m.u(EXT+48)==160
E.close();assert m.u(EXT+48)==125
print('PASS multiple wearers and independent removal')

m,L,E=setup();tick(E);m.put(EXT+20,U(200));m.put(INV+12,U(0));tick(E,1)
assert m.u(EXT+20)==200
m,L,E=setup();m.put(EXT+20,U(200));tick(E);E.close();assert m.u(EXT+20)==200
print('PASS competing writer and pre-existing higher cap preservation')

m,L,E=setup();tick(E);m.fail=True;m.put(INV+12,U(0));tick(E,1)
assert m.u(EXT+20)==160
m.fail=False;tick(E,1);assert m.u(EXT+20)==125
m,L,E=setup();tick(E);new=0x32000000;m.put(new,m.read(EXT,56));m.put(HM+0x1060,Q(new))
m.put(INV+12,U(0));tick(E,1);assert m.u(new+20)==125
print('PASS restoration retry and HealthExt array relocation')

m,L,E=setup();tick(E);m.put(NET+0xf32f18+12,U(999));m.put(INV+12,U(0))
before=len(m.writes);tick(E,1);assert len(m.writes)==before
m,L,E=setup();m.put(BASE+10132699,b'BADPIN!');assert len(tick(E,1))==0 and not m.writes
print('PASS recycled identity rejection and incompatible build refusal')

# Compile the final concatenated addon with the same LuaJIT family as Bingus.
sys.path.insert(0,str(ROOT));from build import build
out,lua=build();L=luajit21.LuaRuntime(encoding=None)
assert L.eval(b'function(s)local f,e=loadstring(s);assert(f,e);return true end')(lua)
assert b"require('mods/skyeshade/hd2runtime')" not in lua
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    b=z.read('data/9ba626afa44a3aa3.patch_0')
    assert struct.unpack_from('<III',b)==(0xf0000011,1,1)
    row=struct.unpack_from('<7Q6I',b,104)
    assert b[row[2]+8:row[2]+row[7]]==lua
print('PASS LuaJIT syntax, ZIP/archive round trip, no Runtime import')
